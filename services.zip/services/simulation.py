"""
Transaction Simulation Service
Simulates transactions before execution to validate profitability and catch errors.
Uses Solana RPC simulation with full commitment checks.
"""
import json
from typing import Dict, Optional, Any, Tuple
from dataclasses import dataclass
import httpx


@dataclass
class SimulationResult:
    """Result of transaction simulation."""
    success: bool
    error: Optional[str] = None
    logs: list = None
    compute_units_consumed: int = 0
    fee_lamports: int = 0
    pre_balance: int = 0
    post_balance: int = 0
    balance_change: int = 0
    inner_instructions: list = None
    raw_response: Dict = None


class SimulationService:
    """Simulates Solana transactions before execution."""
    
    def __init__(self, rpc_url: str):
        self.rpc_url = rpc_url
        self._client: Optional[httpx.AsyncClient] = None
    
    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create HTTP client."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=10.0)
        return self._client
    
    async def simulate_transaction(
        self,
        serialized_transaction: str,  # base64 encoded
        sender_pubkey: str,
        replace_blockhash: bool = True,
        commitment: str = "processed",
        sig_verify: bool = False
    ) -> SimulationResult:
        """
        Simulate transaction via Solana RPC.
        
        Args:
            serialized_transaction: Base64-encoded transaction
            sender_pubkey: Transaction sender (for balance tracking)
            replace_blockhash: Use recent blockhash (recommended)
            commitment: Simulation commitment level
            sig_verify: Verify signatures (false for sim with placeholder sigs)
        
        Returns:
            SimulationResult with detailed outcome
        """
        try:
            client = await self._get_client()
            
            payload = {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "simulateTransaction",
                "params": [
                    serialized_transaction,
                    {
                        "replaceRecentBlockhash": replace_blockhash,
                        "commitment": commitment,
                        "sigVerify": sig_verify,
                        "encoding": "base64"
                    }
                ]
            }
            
            response = await client.post(
                self.rpc_url,
                json=payload,
                timeout=10.0
            )
            response.raise_for_status()
            data = response.json()
            
            if "error" in data:
                return SimulationResult(
                    success=False,
                    error=str(data["error"]),
                    raw_response=data
                )
            
            result = data.get("result", {})
            value = result.get("value", {})
            
            # Parse simulation outcome
            err = value.get("err")
            logs = value.get("logs", [])
            compute_units = value.get("unitsConsumed", 0)
            
            # Extract balance changes
            accounts = value.get("accounts", [])
            pre_balance = 0
            post_balance = 0
            
            if accounts:
                # First account is usually the fee payer
                first_account = accounts[0]
                pre_balance = first_account.get("lamports", 0)
                post_balance = first_account.get("lamports", 0)  # Same in sim unless modified
            
            # Check for inner instructions (swap details)
            inner_ix = value.get("innerInstructions", [])
            
            # Calculate fee from logs if available
            fee = 0
            for log in logs:
                if "fee" in log.lower():
                    try:
                        # Parse fee from log
                        parts = log.split()
                        for i, part in enumerate(parts):
                            if "fee" in part.lower() and i + 1 < len(parts):
                                fee = int(parts[i + 1])
                                break
                    except:
                        pass
            
            return SimulationResult(
                success=err is None,
                error=str(err) if err else None,
                logs=logs,
                compute_units_consumed=compute_units,
                fee_lamports=fee,
                pre_balance=pre_balance,
                post_balance=post_balance,
                balance_change=post_balance - pre_balance,
                inner_instructions=inner_ix,
                raw_response=data
            )
            
        except Exception as e:
            return SimulationResult(
                success=False,
                error=f"Simulation failed: {str(e)}"
            )
    
    async def validate_arbitrage_simulation(
        self,
        sim_result: SimulationResult,
        min_expected_profit_lamports: int = 0,
        max_acceptable_slippage_bps: int = 100
    ) -> Tuple[bool, str]:
        """
        Validate if simulation result meets arbitrage criteria.
        
        Returns:
            (is_valid, reason)
        """
        if not sim_result.success:
            return False, f"Simulation failed: {sim_result.error}"
        
        if sim_result.error:
            return False, f"Transaction error: {sim_result.error}"
        
        # Check compute units
        if sim_result.compute_units_consumed > 400_000:
            return False, f"Compute units exceeded: {sim_result.compute_units_consumed}"
        
        # Check logs for swap success indicators
        logs = " ".join(sim_result.logs or [])
        
        # Look for error patterns
        error_patterns = [
            "insufficient funds",
            "slippage exceeded",
            "math overflow",
            "invalid account",
            "program error"
        ]
        
        for pattern in error_patterns:
            if pattern in logs.lower():
                return False, f"Error pattern in logs: {pattern}"
        
        # Check for success indicators
        success_indicators = [
            "swap",
            "transfer",
            "success"
        ]
        
        has_success = any(ind in logs.lower() for ind in success_indicators)
        if not has_success:
            return False, "No success indicators in transaction logs"
        
        return True, "Simulation passed"
    
    async def estimate_transaction_fee(
        self,
        priority_fee_micro_lamports: int,
        compute_unit_limit: int = 200_000
    ) -> int:
        """Estimate total transaction fee in lamports."""
        # Base fee: 5000 lamports
        # Priority fee: micro_lamports * compute_units / 1_000_000
        base_fee = 5000
        priority_fee = (priority_fee_micro_lamports * compute_unit_limit) // 1_000_000
        return base_fee + priority_fee
    
    async def close(self):
        """Close HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()


# Singleton
_simulator: Optional[SimulationService] = None


def get_simulation_service(
    rpc_url: str = "https://api.mainnet-beta.solana.com"
) -> SimulationService:
    """Get simulation service singleton."""
    global _simulator
    if _simulator is None:
        _simulator = SimulationService(rpc_url)
    return _simulator
