"""
Profit Verification Ledger
Records every arbitrage opportunity as verifiable proof.
"""

import json
import hashlib
from datetime import datetime
from decimal import Decimal
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from pathlib import Path
import aiohttp


@dataclass
class ArbitrageProof:
    """
    Complete proof of arbitrage opportunity and execution.
    
    This is the ledger entry format requested.
    """
    # Identity
    opportunity_id: str
    timestamp_utc: str
    
    # Tokens
    input_mint: str
    intermediate_mint: str
    output_mint: str  # Should equal input_mint for circular arb
    
    # Routes
    route_a: str  # "Jupiter/Raydium/Orca"
    route_b: str  # "Jupiter/Raydium/Orca"
    route_a_pools: List[str]
    route_b_pools: List[str]
    
    # Economics (Expected)
    input_amount_lamports: int
    expected_output_lamports: int
    expected_profit_lamports: int
    expected_profit_usd: Decimal
    expected_profit_pct: Decimal
    
    # Simulation
    simulated: bool
    simulated_profit_usd: Decimal
    simulation_cu_consumed: Optional[int]
    simulation_error: Optional[str]
    
    # Execution
    executed: bool
    tx_signatures: List[str]
    bundle_uuid: Optional[str]
    slot: Optional[int]
    execution_latency_ms: Optional[int]
    
    # On-chain verification
    pre_balances: Dict[str, int]  # mint -> lamports
    post_balances: Dict[str, int]
    realized_profit_lamports: int
    realized_profit_usd: Decimal
    
    # Fees paid
    fees_total_lamports: int
    fees_jupiter_bps: int
    fees_pool_bps: int
    fees_priority_lamports: int
    fees_jito_tip_lamports: int
    fees_total_usd: Decimal
    
    # Verification status
    verified: bool
    verification_error: Optional[str]
    profit_variance_pct: Optional[Decimal]  # (realized - expected) / expected
    
    # Proof hash
    proof_hash: str  # SHA256 of canonical JSON
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        return {
            "opportunity_id": self.opportunity_id,
            "timestamp_utc": self.timestamp_utc,
            "input_mint": self.input_mint,
            "intermediate_mint": self.intermediate_mint,
            "output_mint": self.output_mint,
            "route_a": self.route_a,
            "route_b": self.route_b,
            "route_a_pools": self.route_a_pools,
            "route_b_pools": self.route_b_pools,
            "input_amount_lamports": self.input_amount_lamports,
            "expected_output_lamports": self.expected_output_lamports,
            "expected_profit_lamports": self.expected_profit_lamports,
            "expected_profit_usd": str(self.expected_profit_usd),
            "expected_profit_pct": str(self.expected_profit_pct),
            "simulated": self.simulated,
            "simulated_profit_usd": str(self.simulated_profit_usd),
            "simulation_cu_consumed": self.simulation_cu_consumed,
            "simulation_error": self.simulation_error,
            "executed": self.executed,
            "tx_signatures": self.tx_signatures,
            "bundle_uuid": self.bundle_uuid,
            "slot": self.slot,
            "execution_latency_ms": self.execution_latency_ms,
            "pre_balances": self.pre_balances,
            "post_balances": self.post_balances,
            "realized_profit_lamports": self.realized_profit_lamports,
            "realized_profit_usd": str(self.realized_profit_usd),
            "fees_total_lamports": self.fees_total_lamports,
            "fees_jupiter_bps": self.fees_jupiter_bps,
            "fees_pool_bps": self.fees_pool_bps,
            "fees_priority_lamports": self.fees_priority_lamports,
            "fees_jito_tip_lamports": self.fees_jito_tip_lamports,
            "fees_total_usd": str(self.fees_total_usd),
            "verified": self.verified,
            "verification_error": self.verification_error,
            "profit_variance_pct": str(self.profit_variance_pct) if self.profit_variance_pct else None,
            "proof_hash": self.proof_hash
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ArbitrageProof":
        """Reconstruct from dictionary"""
        return cls(
            opportunity_id=data["opportunity_id"],
            timestamp_utc=data["timestamp_utc"],
            input_mint=data["input_mint"],
            intermediate_mint=data["intermediate_mint"],
            output_mint=data["output_mint"],
            route_a=data["route_a"],
            route_b=data["route_b"],
            route_a_pools=data["route_a_pools"],
            route_b_pools=data["route_b_pools"],
            input_amount_lamports=data["input_amount_lamports"],
            expected_output_lamports=data["expected_output_lamports"],
            expected_profit_lamports=data["expected_profit_lamports"],
            expected_profit_usd=Decimal(data["expected_profit_usd"]),
            expected_profit_pct=Decimal(data["expected_profit_pct"]),
            simulated=data["simulated"],
            simulated_profit_usd=Decimal(data["simulated_profit_usd"]),
            simulation_cu_consumed=data.get("simulation_cu_consumed"),
            simulation_error=data.get("simulation_error"),
            executed=data["executed"],
            tx_signatures=data["tx_signatures"],
            bundle_uuid=data.get("bundle_uuid"),
            slot=data.get("slot"),
            execution_latency_ms=data.get("execution_latency_ms"),
            pre_balances=data["pre_balances"],
            post_balances=data["post_balances"],
            realized_profit_lamports=data["realized_profit_lamports"],
            realized_profit_usd=Decimal(data["realized_profit_usd"]),
            fees_total_lamports=data["fees_total_lamports"],
            fees_jupiter_bps=data["fees_jupiter_bps"],
            fees_pool_bps=data["fees_pool_bps"],
            fees_priority_lamports=data["fees_priority_lamports"],
            fees_jito_tip_lamports=data["fees_jito_tip_lamports"],
            fees_total_usd=Decimal(data["fees_total_usd"]),
            verified=data["verified"],
            verification_error=data.get("verification_error"),
            profit_variance_pct=Decimal(data["profit_variance_pct"]) if data.get("profit_variance_pct") else None,
            proof_hash=data["proof_hash"]
        )


class ProfitLedger:
    """
    Immutable profit verification ledger.
    
    Every opportunity is recorded with:
    - Full economic breakdown
    - Execution proof (tx signatures)
    - On-chain verification
    - Deterministic hash
    
    This creates a trustless record of arbitrage performance.
    """
    
    def __init__(
        self,
        ledger_dir: str = "./data/ledger",
        helius_rpc: Optional[str] = None
    ):
        self.ledger_dir = Path(ledger_dir)
        self.ledger_dir.mkdir(parents=True, exist_ok=True)
        self.helius_rpc = helius_rpc
        self.entries: List[ArbitrageProof] = []
    
    def _generate_id(
        self,
        input_mint: str,
        intermediate_mint: str,
        timestamp: datetime
    ) -> str:
        """Generate deterministic opportunity ID"""
        data = f"{input_mint}:{intermediate_mint}:{timestamp.isoformat()}"
        return hashlib.sha256(data.encode()).hexdigest()[:16]
    
    def _calculate_hash(self, proof: ArbitrageProof) -> str:
        """Calculate proof hash (excluding the hash field itself)"""
        data = proof.to_dict()
        del data["proof_hash"]  # Remove existing hash
        
        # Canonical JSON serialization
        canonical = json.dumps(data, sort_keys=True, separators=(',', ':'))
        return hashlib.sha256(canonical.encode()).hexdigest()
    
    def create_opportunity_record(
        self,
        input_mint: str,
        intermediate_mint: str,
        input_amount_lamports: int,
        route_a: str,
        route_b: str,
        route_a_pools: List[str],
        route_b_pools: List[str],
        expected_output_lamports: int,
        expected_profit_lamports: int,
        expected_profit_usd: Decimal,
        expected_profit_pct: Decimal,
        fees_jupiter_bps: int = 10,
        fees_pool_bps: int = 50,
        fees_priority_lamports: int = 5000,
        fees_jito_tip_lamports: int = 10000
    ) -> ArbitrageProof:
        """
        Create a new ledger entry for an identified opportunity.
        
        This is called when an opportunity is detected but not yet executed.
        """
        timestamp = datetime.utcnow()
        opportunity_id = self._generate_id(input_mint, intermediate_mint, timestamp)
        
        # Calculate total fees
        fees_total_lamports = fees_priority_lamports + fees_jito_tip_lamports
        
        proof = ArbitrageProof(
            opportunity_id=opportunity_id,
            timestamp_utc=timestamp.isoformat(),
            input_mint=input_mint,
            intermediate_mint=intermediate_mint,
            output_mint=input_mint,  # Circular arb
            route_a=route_a,
            route_b=route_b,
            route_a_pools=route_a_pools,
            route_b_pools=route_b_pools,
            input_amount_lamports=input_amount_lamports,
            expected_output_lamports=expected_output_lamports,
            expected_profit_lamports=expected_profit_lamports,
            expected_profit_usd=expected_profit_usd,
            expected_profit_pct=expected_profit_pct,
            simulated=False,
            simulated_profit_usd=Decimal("0"),
            simulation_cu_consumed=None,
            simulation_error=None,
            executed=False,
            tx_signatures=[],
            bundle_uuid=None,
            slot=None,
            execution_latency_ms=None,
            pre_balances={},
            post_balances={},
            realized_profit_lamports=0,
            realized_profit_usd=Decimal("0"),
            fees_total_lamports=fees_total_lamports,
            fees_jupiter_bps=fees_jupiter_bps,
            fees_pool_bps=fees_pool_bps,
            fees_priority_lamports=fees_priority_lamports,
            fees_jito_tip_lamports=fees_jito_tip_lamports,
            fees_total_usd=Decimal("0"),  # Will be calculated
            verified=False,
            verification_error=None,
            profit_variance_pct=None,
            proof_hash=""  # Will be calculated
        )
        
        # Calculate hash
        proof.proof_hash = self._calculate_hash(proof)
        
        return proof
    
    def record_simulation(
        self,
        proof: ArbitrageProof,
        success: bool,
        simulated_profit_usd: Decimal,
        cu_consumed: Optional[int] = None,
        error: Optional[str] = None
    ) -> ArbitrageProof:
        """Update record with simulation results"""
        proof.simulated = success
        proof.simulated_profit_usd = simulated_profit_usd
        proof.simulation_cu_consumed = cu_consumed
        proof.simulation_error = error
        
        # Recalculate hash
        proof.proof_hash = self._calculate_hash(proof)
        
        return proof
    
    def record_execution(
        self,
        proof: ArbitrageProof,
        tx_signatures: List[str],
        bundle_uuid: Optional[str],
        slot: int,
        latency_ms: int,
        pre_balances: Dict[str, int],
        post_balances: Dict[str, int]
    ) -> ArbitrageProof:
        """Update record with execution details"""
        proof.executed = True
        proof.tx_signatures = tx_signatures
        proof.bundle_uuid = bundle_uuid
        proof.slot = slot
        proof.execution_latency_ms = latency_ms
        proof.pre_balances = pre_balances
        proof.post_balances = post_balances
        
        # Calculate realized profit
        input_mint = proof.input_mint
        pre = pre_balances.get(input_mint, 0)
        post = post_balances.get(input_mint, 0)
        proof.realized_profit_lamports = post - pre - proof.fees_total_lamports
        
        # Recalculate hash
        proof.proof_hash = self._calculate_hash(proof)
        
        return proof
    
    async def verify_on_chain(
        self,
        proof: ArbitrageProof,
        helius_rpc: Optional[str] = None
    ) -> ArbitrageProof:
        """
        Verify execution by checking on-chain state.
        
        Fetches transaction status and confirms profit.
        """
        rpc = helius_rpc or self.helius_rpc
        
        if not rpc:
            proof.verified = False
            proof.verification_error = "No RPC endpoint configured"
            return proof
        
        if not proof.tx_signatures:
            proof.verified = False
            proof.verification_error = "No transactions to verify"
            return proof
        
        try:
            async with aiohttp.ClientSession() as session:
                # Check first transaction status
                payload = {
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "getSignatureStatuses",
                    "params": [[proof.tx_signatures[0]], {"searchTransactionHistory": True}]
                }
                
                async with session.post(rpc, json=payload) as resp:
                    data = await resp.json()
                    
                    if "result" in data and data["result"]["value"]:
                        status = data["result"]["value"][0]
                        
                        if status and status.get("confirmationStatus") == "confirmed":
                            proof.verified = True
                            proof.verification_error = None
                            
                            # Calculate profit variance
                            if proof.expected_profit_usd > 0:
                                variance = (
                                    (proof.realized_profit_usd - proof.expected_profit_usd)
                                    / proof.expected_profit_usd
                                ) * 100
                                proof.profit_variance_pct = variance
                        else:
                            proof.verified = False
                            proof.verification_error = f"Status: {status}"
                    else:
                        proof.verified = False
                        proof.verification_error = "Could not fetch status"
                        
        except Exception as e:
            proof.verified = False
            proof.verification_error = str(e)
        
        # Recalculate hash
        proof.proof_hash = self._calculate_hash(proof)
        
        return proof
    
    def save(self, proof: ArbitrageProof):
        """Save proof to disk"""
        filename = f"{proof.opportunity_id}_{proof.timestamp_utc[:10]}.json"
        filepath = self.ledger_dir / filename
        
        with open(filepath, 'w') as f:
            json.dump(proof.to_dict(), f, indent=2)
        
        self.entries.append(proof)
        
        return filepath
    
    def load_all(self) -> List[ArbitrageProof]:
        """Load all ledger entries from disk"""
        self.entries = []
        
        for filepath in self.ledger_dir.glob("*.json"):
            with open(filepath, 'r') as f:
                data = json.load(f)
                self.entries.append(ArbitrageProof.from_dict(data))
        
        return self.entries
    
    def get_stats(self) -> Dict:
        """Calculate ledger statistics"""
        if not self.entries:
            self.load_all()
        
        executed = [e for e in self.entries if e.executed]
        verified = [e for e in self.entries if e.verified]
        profitable = [e for e in self.entries if e.realized_profit_usd > 0]
        
        total_profit = sum(e.realized_profit_usd for e in profitable)
        total_fees = sum(e.fees_total_usd for e in self.entries)
        
        return {
            "total_opportunities": len(self.entries),
            "executed": len(executed),
            "verified": len(verified),
            "profitable": len(profitable),
            "total_realized_profit_usd": str(total_profit),
            "total_fees_paid_usd": str(total_fees),
            "net_pnl_usd": str(total_profit - total_fees),
            "avg_profit_per_trade_usd": str(
                total_profit / len(profitable) if profitable else 0
            )
        }
    
    def verify_proof_hash(self, proof: ArbitrageProof) -> bool:
        """Verify that a proof's hash is valid"""
        calculated = self._calculate_hash(proof)
        return calculated == proof.proof_hash


# Example usage
async def example_ledger():
    """Example of full ledger flow"""
    
    ledger = ProfitLedger()
    
    # 1. Create opportunity record
    proof = ledger.create_opportunity_record(
        input_mint="So11111111111111111111111111111111111111112",  # SOL
        intermediate_mint="EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",  # USDC
        input_amount_lamports=100_000_000,  # 0.1 SOL
        route_a="Jupiter",
        route_b="Jupiter",
        route_a_pools=["jupiter_agg"],
        route_b_pools=["jupiter_agg"],
        expected_output_lamports=105_000_000,
        expected_profit_lamports=5_000_000,
        expected_profit_usd=Decimal("0.75"),
        expected_profit_pct=Decimal("5.0")
    )
    
    print(f"Created opportunity: {proof.opportunity_id}")
    print(f"Proof hash: {proof.proof_hash}")
    
    # 2. Record simulation
    proof = ledger.record_simulation(
        proof,
        success=True,
        simulated_profit_usd=Decimal("0.73"),
        cu_consumed=150000
    )
    
    # 3. Record execution (placeholder)
    proof = ledger.record_execution(
        proof,
        tx_signatures=["5KtPn..."],
        bundle_uuid="bundle_123",
        slot=123456789,
        latency_ms=150,
        pre_balances={proof.input_mint: 100_000_000},
        post_balances={proof.input_mint: 104_800_000}
    )
    
    # 4. Save
    filepath = ledger.save(proof)
    print(f"Saved to: {filepath}")
    
    # 5. Stats
    stats = ledger.get_stats()
    print(f"\nLedger stats: {json.dumps(stats, indent=2)}")


if __name__ == "__main__":
    import asyncio
    asyncio.run(example_ledger())
