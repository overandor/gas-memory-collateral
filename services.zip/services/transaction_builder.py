"""
Transaction Builder Service
Constructs executable Solana transactions for arbitrage execution.
Uses Jupiter swap-instructions as primary path with optional manual DEX instructions.
"""
import base64
import json
from typing import List, Dict, Optional, Any, Tuple
from dataclasses import dataclass
import httpx

from solders.transaction import VersionedTransaction
from solders.message import MessageV0
from solders.instruction import Instruction
from solders.pubkey import Pubkey
from solders.compute_budget import set_compute_unit_limit, set_compute_unit_price


@dataclass
class SwapRoute:
    """Normalized swap route from any source."""
    source: str  # "jupiter", "raydium", "orca"
    input_mint: str
    output_mint: str
    in_amount: int
    out_amount: int
    price_impact_pct: float
    instructions: List[Dict]  # Raw instructions to execute
    raw_response: Dict


@dataclass
class TransactionPlan:
    """Complete transaction plan with all instructions."""
    instructions: List[Instruction]
    signers: List[str]  # Required signer pubkeys
    expected_input: int
    expected_output: int
    priority_fee_micro_lamports: int
    compute_unit_limit: int
    jito_tip_lamports: int
    total_fees_lamports: int
    net_profit_lamports: int
    simulation_result: Optional[Dict] = None


class TransactionBuilder:
    """Builds executable Solana transactions for arbitrage."""
    
    # Default compute settings
    DEFAULT_COMPUTE_UNITS = 400_000
    DEFAULT_PRIORITY_FEE_MICRO_LAMPORTS = 10_000  # 0.01 lamports/CU
    DEFAULT_JITO_TIP_LAMPORTS = 1_000  # 0.000001 SOL
    
    # Fee estimation (lamports)
    BASE_TX_FEE = 5_000
    RENT_EXEMPTION = 2_039_280  # If creating token accounts
    
    def __init__(self, rpc_url: str, jito_url: str):
        self.rpc_url = rpc_url
        self.jito_url = jito_url
        self._client: Optional[httpx.AsyncClient] = None
    
    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create HTTP client."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=10.0)
        return self._client
    
    async def fetch_jupiter_quote(
        self,
        input_mint: str,
        output_mint: str,
        amount: int,
        slippage_bps: int = 50,
        only_direct_routes: bool = False
    ) -> Optional[Dict]:
        """Fetch quote from Jupiter API."""
        try:
            client = await self._get_client()
            url = "https://api.jup.ag/swap/v1/quote"
            
            params = {
                "inputMint": input_mint,
                "outputMint": output_mint,
                "amount": str(amount),
                "slippageBps": slippage_bps,
                "onlyDirectRoutes": str(only_direct_routes).lower(),
                "asLegacyTransaction": "false"
            }
            
            response = await client.get(url, params=params, timeout=5.0)
            response.raise_for_status()
            return response.json()
            
        except Exception as e:
            print(f"[TxBuilder] Jupiter quote error: {e}")
            return None
    
    async def fetch_jupiter_swap_instructions(
        self,
        quote_response: Dict,
        user_public_key: str,
        wrap_unwrap_sol: bool = True,
        use_shared_accounts: bool = True
    ) -> Optional[Dict]:
        """Fetch executable swap instructions from Jupiter."""
        try:
            client = await self._get_client()
            url = "https://api.jup.ag/swap/v1/swap-instructions"
            
            payload = {
                "quoteResponse": quote_response,
                "userPublicKey": user_public_key,
                "wrapAndUnwrapSol": wrap_unwrap_sol,
                "useSharedAccounts": use_shared_accounts,
                "computeUnitPriceMicroLamports": self.DEFAULT_PRIORITY_FEE_MICRO_LAMPORTS,
                "asLegacyTransaction": False
            }
            
            response = await client.post(url, json=payload, timeout=5.0)
            response.raise_for_status()
            return response.json()
            
        except Exception as e:
            print(f"[TxBuilder] Jupiter instructions error: {e}")
            return None
    
    def _deserialize_instruction(self, ix_data: Dict) -> Instruction:
        """Deserialize instruction from Jupiter/API format."""
        program_id = Pubkey.from_string(ix_data["programId"])
        accounts = []
        
        for acc in ix_data.get("accounts", []):
            accounts.append({
                "pubkey": Pubkey.from_string(acc["pubkey"]),
                "is_signer": acc.get("isSigner", False),
                "is_writable": acc.get("isWritable", False)
            })
        
        data = base64.b64decode(ix_data["data"]) if "data" in ix_data else b""
        
        return Instruction(
            program_id=program_id,
            data=data,
            accounts=accounts
        )
    
    def _add_compute_budget_instructions(
        self,
        instructions: List[Instruction],
        compute_unit_limit: int = None,
        priority_fee_micro_lamports: int = None
    ) -> List[Instruction]:
        """Add compute budget and priority fee instructions."""
        if compute_unit_limit is None:
            compute_unit_limit = self.DEFAULT_COMPUTE_UNITS
        if priority_fee_micro_lamports is None:
            priority_fee_micro_lamports = self.DEFAULT_PRIORITY_FEE_MICRO_LAMPORTS
        
        # Compute unit limit instruction
        cu_limit_ix = set_compute_unit_limit(compute_unit_limit)
        
        # Priority fee instruction
        cu_price_ix = set_compute_unit_price(priority_fee_micro_lamports)
        
        # Prepend to instructions
        return [cu_limit_ix, cu_price_ix] + instructions
    
    async def get_recent_blockhash(self) -> Optional[str]:
        """Fetch recent blockhash from RPC."""
        try:
            client = await self._get_client()
            payload = {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "getLatestBlockhash",
                "params": [{"commitment": "processed"}]
            }
            
            response = await client.post(self.rpc_url, json=payload, timeout=5.0)
            data = response.json()
            
            if "result" in data and "value" in data["result"]:
                return data["result"]["value"]["blockhash"]
            return None
            
        except Exception as e:
            print(f"[TxBuilder] Blockhash fetch error: {e}")
            return None
    
    async def serialize_and_sign_transaction(
        self,
        plan: TransactionPlan,
        signer_pubkey: str
    ) -> Optional[str]:
        """
        Serialize and sign transaction using the signer service.
        
        Returns base64-encoded signed transaction ready for RPC submission.
        """
        from app.services.solana_signer import get_signer
        
        signer = get_signer()
        if not signer.is_ready:
            print("[TxBuilder] Signer not available")
            return None
        
        # Get recent blockhash
        recent_blockhash = await self.get_recent_blockhash()
        if not recent_blockhash:
            return None
        
        # Sign the transaction
        signed_tx = signer.sign_and_encode(
            plan.instructions,
            recent_blockhash
        )
        
        return signed_tx
    
    async def build_arbitrage_transaction(
        self,
        route_a: SwapRoute,
        route_b: SwapRoute,
        user_public_key: str,
        priority_fee_micro_lamports: int = None,
        jito_tip_lamports: int = None,
        compute_unit_limit: int = None
    ) -> Optional[TransactionPlan]:
        """
        Build complete arbitrage transaction (Route A -> Route B).
        
        Args:
            route_a: First leg (buy)
            route_b: Second leg (sell)
            user_public_key: Trader's wallet
            priority_fee_micro_lamports: Priority fee
            jito_tip_lamports: Jito bundle tip
            compute_unit_limit: Max compute units
        
        Returns:
            TransactionPlan ready for simulation and execution
        """
        instructions = []
        
        # Build instructions from routes
        # Note: For Jupiter, we need to fetch swap instructions
        # For manual DEX, we build from SDK
        
        if route_a.source == "jupiter":
            # Fetch Jupiter swap instructions for route A
            jupiter_ix = await self.fetch_jupiter_swap_instructions(
                route_a.raw_response,
                user_public_key
            )
            if jupiter_ix:
                # Deserialize instructions
                for ix_data in jupiter_ix.get("swapInstruction", []):
                    instructions.append(self._deserialize_instruction(ix_data))
                for ix_data in jupiter_ix.get("setupInstructions", []):
                    instructions.append(self._deserialize_instruction(ix_data))
        else:
            # Manual DEX instructions (Raydium/Orca SDK)
            print(f"[TxBuilder] Manual DEX instructions for {route_a.source} not yet implemented")
            return None
        
        if route_b.source == "jupiter":
            jupiter_ix = await self.fetch_jupiter_swap_instructions(
                route_b.raw_response,
                user_public_key
            )
            if jupiter_ix:
                for ix_data in jupiter_ix.get("swapInstruction", []):
                    instructions.append(self._deserialize_instruction(ix_data))
        else:
            print(f"[TxBuilder] Manual DEX instructions for {route_b.source} not yet implemented")
            return None
        
        # Add compute budget and priority fee
        instructions = self._add_compute_budget_instructions(
            instructions,
            compute_unit_limit,
            priority_fee_micro_lamports
        )
        
        # Add Jito tip (done later during signing with actual sender key)
        # Tip instruction is added by signer since it needs the sender's pubkey
        pass  # Tip will be added during sign_and_serialize
        
        # Calculate expected PnL
        fees_lamports = (
            self.BASE_TX_FEE +
            (priority_fee_micro_lamports or self.DEFAULT_PRIORITY_FEE_MICRO_LAMPORTS) * (compute_unit_limit or self.DEFAULT_COMPUTE_UNITS) // 1_000_000 +
            (jito_tip_lamports or self.DEFAULT_JITO_TIP_LAMPORTS)
        )
        
        net_profit_lamports = (
            route_b.out_amount -  # What we get from selling
            route_a.in_amount -   # What we spent buying
            fees_lamports
        )
        
        return TransactionPlan(
            instructions=instructions,
            signers=[user_public_key],
            expected_input=route_a.in_amount,
            expected_output=route_b.out_amount,
            priority_fee_micro_lamports=priority_fee_micro_lamports or self.DEFAULT_PRIORITY_FEE_MICRO_LAMPORTS,
            compute_unit_limit=compute_unit_limit or self.DEFAULT_COMPUTE_UNITS,
            jito_tip_lamports=jito_tip_lamports or self.DEFAULT_JITO_TIP_LAMPORTS,
            total_fees_lamports=fees_lamports,
            net_profit_lamports=net_profit_lamports
        )
    
    async def close(self):
        """Close HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()


# Singleton
_builder: Optional[TransactionBuilder] = None


def get_transaction_builder(
    rpc_url: str = "https://api.mainnet-beta.solana.com",
    jito_url: str = "https://mainnet.block-engine.jito.wtf/api/v1"
) -> TransactionBuilder:
    """Get transaction builder singleton."""
    global _builder
    if _builder is None:
        _builder = TransactionBuilder(rpc_url, jito_url)
    return _builder
