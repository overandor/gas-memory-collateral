"""
End-to-End Gas Memory Pipeline

Orchestrates the complete flow: collect → verify → summarize → store
Transforms live Solana transaction fee observations into endpointless provenance APIs.
"""
import asyncio
import uuid
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
import json

from app.models.provenance import (
    GasMemoryCollection, FeeSample, VerificationProof, 
    GasMemoryArtifact, CollectionStatus
)
from app.models.gas_memory_post import GasMemoryPost
from app.services.solana_collector_v2 import get_solana_collector_v2, CollectionConfig
from app.services.canonical_artifact import get_canonical_artifact_builder
from app.services.persistent_storage import get_persistent_storage_manager
from app.services.rpc_provider_pool import get_provider_pool
from app.utils.config import settings

class GasMemoryPipeline:
    """
    End-to-end pipeline for Gas Memory Post creation.
    
    Pipeline stages:
    1. Collect - Gather live Solana transaction fee data
    2. Verify - Cryptographically verify signatures across providers
    3. Summarize - Generate fee curves and temporal surfaces
    4. Store - Persist to IPFS/Arweave with content addressing
    """
    
    def __init__(self):
        self.collector = get_solana_collector_v2()
        self.artifact_builder = get_canonical_artifact_builder()
        self.storage_manager = get_persistent_storage_manager()
        self.provider_pool = get_provider_pool()
        
        # Pipeline configuration
        self.default_config = CollectionConfig()
    
    async def run_complete_pipeline(
        self,
        tx_family: str = "jupiter_swap",
        program_ids: Optional[List[str]] = None,
        time_window_seconds: int = 3600,
        sample_limit: int = 10000,
        min_samples: int = 100,
        store_to_ipfs: bool = True,
        store_to_arweave: bool = False,
        include_llm_insights: bool = True
    ) -> Dict[str, Any]:
        """
        Run the complete end-to-end pipeline.
        
        Returns:
            Complete pipeline results with artifact and verification data
        """
        # Generate collection ID
        collection_id = uuid.uuid4().hex[:16]
        
        pipeline_result = {
            "collection_id": collection_id,
            "started_at": datetime.utcnow().isoformat(),
            "config": {
                "tx_family": tx_family,
                "program_ids": program_ids or self.default_config.program_ids,
                "time_window_seconds": time_window_seconds,
                "sample_limit": sample_limit,
                "min_samples": min_samples,
                "store_to_ipfs": store_to_ipfs,
                "store_to_arweave": store_to_arweave,
                "include_llm_insights": include_llm_insights
            },
            "stages": {},
            "artifact": None,
            "success": False,
            "error": None
        }
        
        try:
            # Stage 1: Collect
            pipeline_result["stages"]["collect"] = await self._stage_collect(
                tx_family, program_ids, time_window_seconds, sample_limit, min_samples, collection_id
            )
            
            if not pipeline_result["stages"]["collect"]["success"]:
                raise Exception(f"Collection failed: {pipeline_result['stages']['collect'].get('error')}")
            
            # Stage 2: Verify
            pipeline_result["stages"]["verify"] = await self._stage_verify(
                pipeline_result["stages"]["collect"]["samples"]
            )
            
            # Stage 3: Summarize
            pipeline_result["stages"]["summarize"] = await self._stage_summarize(
                collection_id,
                tx_family,
                program_ids or self.default_config.program_ids,
                time_window_seconds,
                pipeline_result["stages"]["collect"]["samples"],
                pipeline_result["stages"]["verify"]["verification_proofs"],
                include_llm_insights
            )
            
            # Stage 4: Store
            pipeline_result["stages"]["store"] = await self._stage_store(
                pipeline_result["stages"]["summarize"]["artifact"],
                store_to_ipfs,
                store_to_arweave
            )
            
            # Final result
            pipeline_result["artifact"] = {
                "content_hash": pipeline_result["stages"]["summarize"]["artifact"].canonical_sha256,
                "ipfs_cid": pipeline_result["stages"]["store"].get("ipfs_cid"),
                "arweave_txid": pipeline_result["stages"]["store"].get("arweave_txid"),
                "gateway_urls": pipeline_result["stages"]["store"].get("gateway_urls"),
                "provenance_status": pipeline_result["stages"]["summarize"]["artifact"].provenance_status.value,
                "verification_summary": {
                    "samples_collected": len(pipeline_result["stages"]["collect"]["samples"]),
                    "samples_verified": pipeline_result["stages"]["verify"]["verified_count"],
                    "verification_proofs": len(pipeline_result["stages"]["verify"]["verification_proofs"]),
                    "storage_networks": list(pipeline_result["stages"]["store"].get("storage_results", {}).keys())
                }
            }
            
            pipeline_result["success"] = True
            pipeline_result["completed_at"] = datetime.utcnow().isoformat()
            
            return pipeline_result
            
        except Exception as e:
            pipeline_result["error"] = str(e)
            pipeline_result["failed_at"] = datetime.utcnow().isoformat()
            raise
    
    async def _stage_collect(
        self,
        tx_family: str,
        program_ids: Optional[List[str]],
        time_window_seconds: int,
        sample_limit: int,
        min_samples: int,
        collection_id: str
    ) -> Dict[str, Any]:
        """Stage 1: Collect fee samples from Solana."""
        stage_result = {
            "stage": "collect",
            "started_at": datetime.utcnow().isoformat(),
            "success": False,
            "samples": [],
            "metadata": {}
        }
        
        try:
            # Build collection config
            config = CollectionConfig(
                tx_family=tx_family,
                program_ids=program_ids or self.default_config.program_ids,
                time_window_seconds=time_window_seconds,
                sample_limit=sample_limit,
                min_samples=min_samples
            )
            
            # Collect samples
            samples, metadata = await self.collector.collect_fee_samples(config, collection_id)
            
            # Validate minimum samples
            if len(samples) < min_samples:
                raise Exception(f"Insufficient samples collected: {len(samples)} < {min_samples}")
            
            stage_result.update({
                "success": True,
                "samples": samples,
                "metadata": metadata,
                "completed_at": datetime.utcnow().isoformat()
            })
            
        except Exception as e:
            stage_result["error"] = str(e)
            stage_result["failed_at"] = datetime.utcnow().isoformat()
        
        return stage_result
    
    async def _stage_verify(self, samples: List[FeeSample]) -> Dict[str, Any]:
        """Stage 2: Verify signatures with fallback across providers."""
        stage_result = {
            "stage": "verify",
            "started_at": datetime.utcnow().isoformat(),
            "success": False,
            "verified_count": 0,
            "verification_proofs": [],
            "metadata": {}
        }
        
        try:
            # Extract signatures
            signatures = [s.signature for s in samples]
            
            # Filter valid signatures (88 characters for Solana)
            valid_signatures = [sig for sig in signatures if len(sig) == 88]
            rejected_count = len(signatures) - len(valid_signatures)
            
            if rejected_count > 0:
                print(f"[Verify] Rejected {rejected_count} malformed signatures")
            
            # Verify in batches
            batch_size = 25
            verification_proofs = []
            verified_count = 0
            
            for i in range(0, len(valid_signatures), batch_size):
                batch = valid_signatures[i:i + batch_size]
                
                try:
                    # Use provider pool for verification
                    results, provider_name, metadata = await self.collector.verify_signatures(
                        batch, search_transaction_history=True
                    )
                    
                    # Process verification results
                    for result in results:
                        if result["verified"] and result["status"]:
                            verified_count += 1
                            
                            # Build verification proof
                            proof = {
                                "signature": result["signature"],
                                "slot": result["status"].get("slot"),
                                "confirmationStatus": result["status"].get("confirmationStatus"),
                                "err": result["status"].get("err"),
                                "provider": provider_name,
                                "verified": True,
                                "method": "getSignatureStatuses",
                                "timestamp": datetime.utcnow().isoformat()
                            }
                            verification_proofs.append(proof)
                        else:
                            # Try fallback to getTransaction
                            try:
                                tx_data, tx_provider, tx_metadata = await self.collector.get_transaction_with_fallback(result["signature"])
                                
                                if tx_data and "result" in tx_data and tx_data["result"]:
                                    verified_count += 1
                                    tx_result = tx_data["result"]
                                    meta = tx_result.get("meta", {})
                                    
                                    proof = {
                                        "signature": result["signature"],
                                        "slot": tx_result.get("slot"),
                                        "confirmationStatus": "confirmed",
                                        "err": meta.get("err"),
                                        "provider": tx_provider,
                                        "verified": True,
                                        "method": "getTransaction",
                                        "fallback": True,
                                        "timestamp": datetime.utcnow().isoformat()
                                    }
                                    verification_proofs.append(proof)
                                else:
                                    proof = {
                                        "signature": result["signature"],
                                        "provider": provider_name,
                                        "verified": False,
                                        "error": "Not found on chain",
                                        "timestamp": datetime.utcnow().isoformat()
                                    }
                                    verification_proofs.append(proof)
                            except Exception as fallback_error:
                                proof = {
                                    "signature": result["signature"],
                                    "provider": provider_name,
                                    "verified": False,
                                    "error": f"Fallback failed: {str(fallback_error)}",
                                    "timestamp": datetime.utcnow().isoformat()
                                }
                                verification_proofs.append(proof)
                    
                    # Rate limiting delay
                    await asyncio.sleep(0.3)
                    
                except Exception as e:
                    print(f"[Verify] Batch {i//batch_size} failed: {str(e)}")
                    continue
            
            stage_result.update({
                "success": True,
                "verified_count": verified_count,
                "verification_proofs": verification_proofs,
                "metadata": {
                    "total_signatures": len(signatures),
                    "valid_signatures": len(valid_signatures),
                    "rejected_signatures": rejected_count,
                    "verification_rate": verified_count / len(valid_signatures) if valid_signatures else 0
                },
                "completed_at": datetime.utcnow().isoformat()
            })
            
        except Exception as e:
            stage_result["error"] = str(e)
            stage_result["failed_at"] = datetime.utcnow().isoformat()
        
        return stage_result
    
    async def _stage_summarize(
        self,
        collection_id: str,
        tx_family: str,
        program_ids: List[str],
        time_window_seconds: int,
        samples: List[FeeSample],
        verification_proofs: List[Dict[str, Any]],
        include_llm_insights: bool
    ) -> Dict[str, Any]:
        """Stage 3: Summarize data and build canonical artifact."""
        stage_result = {
            "stage": "summarize",
            "started_at": datetime.utcnow().isoformat(),
            "success": False,
            "artifact": None,
            "metadata": {}
        }
        
        try:
            # Build canonical artifact
            artifact = self.artifact_builder.build_artifact(
                collection_id=collection_id,
                chain="solana",
                network="mainnet-beta",
                tx_family=tx_family,
                program_ids=program_ids,
                time_window_seconds=time_window_seconds,
                samples=samples,
                verification_proofs=verification_proofs,
                include_llm_insights=include_llm_insights
            )
            
            stage_result.update({
                "success": True,
                "artifact": artifact,
                "metadata": {
                    "content_hash": artifact.canonical_sha256,
                    "sample_count": artifact.fee_statistics.sample_count,
                    "verified_samples": artifact.fee_statistics.verified_samples,
                    "success_rate": artifact.fee_statistics.success_rate,
                    "temporal_surface_points": len(artifact.temporal_surface) if hasattr(artifact, 'temporal_surface') else 0
                },
                "completed_at": datetime.utcnow().isoformat()
            })
            
        except Exception as e:
            stage_result["error"] = str(e)
            stage_result["failed_at"] = datetime.utcnow().isoformat()
        
        return stage_result
    
    async def _stage_store(
        self,
        artifact: GasMemoryPost,
        store_to_ipfs: bool,
        store_to_arweave: bool
    ) -> Dict[str, Any]:
        """Stage 4: Store artifact to persistent storage networks."""
        stage_result = {
            "stage": "store",
            "started_at": datetime.utcnow().isoformat(),
            "success": False,
            "storage_results": {},
            "verification": {},
            "metadata": {}
        }
        
        try:
            # Serialize artifact to canonical JSON
            from app.services.canonical_artifact import CanonicalJSONSerializer
            serializer = CanonicalJSONSerializer()
            canonical_json = serializer.serialize(artifact.model_dump())
            content_bytes = canonical_json.encode('utf-8')
            
            # Determine target networks
            networks = []
            if store_to_ipfs:
                networks.append("ipfs")
            if store_to_arweave:
                networks.append("arweave")
            
            # Store to networks
            storage_results = await self.storage_manager.store_artifact(
                content_bytes,
                f"{artifact.canonical_sha256}.json",
                networks
            )
            
            stage_result["storage_results"] = {
                network: {
                    "success": result.success,
                    "identifier": result.identifier,
                    "gateway_url": result.gateway_url,
                    "error": result.error
                }
                for network, result in storage_results.items()
            }
            
            # Verify cross-network integrity
            verification = await self.storage_manager.verify_cross_network(
                content_bytes, storage_results
            )
            stage_result["verification"] = verification
            
            # Extract storage references
            storage_refs = self.storage_manager.build_storage_references(storage_results)
            
            stage_result.update({
                "success": verification["overall_verified"],
                "ipfs_cid": storage_refs.ipfs_cid,
                "arweave_txid": storage_refs.arweave_txid,
                "gateway_urls": storage_refs.gateway_urls,
                "storage_type": storage_refs.storage_type,
                "metadata": {
                    "networks_used": list(storage_results.keys()),
                    "content_hash": artifact.canonical_sha256,
                    "storage_verified": verification["overall_verified"]
                },
                "completed_at": datetime.utcnow().isoformat()
            })
            
        except Exception as e:
            stage_result["error"] = str(e)
            stage_result["failed_at"] = datetime.utcnow().isoformat()
        
        return stage_result
    
    async def get_pipeline_status(self) -> Dict[str, Any]:
        """Get current pipeline and system status."""
        return {
            "pipeline": "Gas Memory Pipeline",
            "version": "1.0",
            "components": {
                "collector": {
                    "status": "ready",
                    "provider_pool": self.provider_pool.get_provider_stats()
                },
                "artifact_builder": {
                    "status": "ready"
                },
                "storage_manager": {
                    "status": "ready",
                    "health": await self.storage_manager.get_storage_health()
                }
            },
            "supported_networks": {
                "storage": ["ipfs", "arweave"],
                "blockchain": ["solana"]
            },
            "capabilities": {
                "live_collection": True,
                "signature_verification": True,
                "canonical_hashing": True,
                "cross_network_storage": True,
                "content_addressing": True
            }
        }
    
    async def close(self):
        """Close all services."""
        await self.collector.close()
        await self.storage_manager.close()

# Factory function
def get_gas_memory_pipeline() -> GasMemoryPipeline:
    """Get gas memory pipeline instance."""
    return GasMemoryPipeline()
