"""
Replay Engine - Fee Strategy Simulation
Uses historical data to simulate optimal fee strategies
"""
import random
from typing import Dict, List, Optional
from dataclasses import dataclass
from datetime import datetime


@dataclass
class SimulationResult:
    """Result of a fee strategy simulation."""
    strategy_name: str
    compute_unit_price: int
    success_rate: float
    avg_landed_slot: float
    total_fees_lamports: int
    missed_opportunities: int
    fee_efficiency_score: float
    overall_score: float


class ReplayEngine:
    """
    Simulate fee strategies against historical data.
    
    Key insight: "What would have happened if I used X fee?"
    """
    
    def __init__(self):
        self.strategies = {
            "cheap": {
                "description": "Use p50 fee, accept higher latency",
                "percentile": 0.5,
                "multiplier": 1.0
            },
            "balanced": {
                "description": "Use p75 fee for reliable landing",
                "percentile": 0.75,
                "multiplier": 1.0
            },
            "urgent": {
                "description": "Use p90 fee for fast landing",
                "percentile": 0.9,
                "multiplier": 1.0
            },
            "aggressive": {
                "description": "Use p95+ fee for guaranteed landing",
                "percentile": 0.95,
                "multiplier": 1.2
            },
            "adaptive": {
                "description": "Adjust based on congestion",
                "percentile": 0.75,
                "multiplier": 1.0,
                "adaptive": True
            }
        }
    
    def simulate_strategy(
        self,
        historical_fees: List[int],
        historical_latencies: List[int],
        strategy_name: str,
        compute_unit_limit: int = 200000,
        sample_count: int = 1000
    ) -> SimulationResult:
        """
        Simulate a fee strategy against historical data.
        
        Args:
            historical_fees: List of historical priority fees (micro-lamports/CU)
            historical_latencies: List of confirmation latencies (slots)
            strategy_name: Which strategy to test
            compute_unit_limit: CU limit for the transaction
            sample_count: How many historical points to simulate
            
        Returns:
            SimulationResult with success metrics
        """
        if not historical_fees or not historical_latencies:
            return SimulationResult(
                strategy_name=strategy_name,
                compute_unit_price=0,
                success_rate=0.0,
                avg_landed_slot=999,
                total_fees_lamports=0,
                missed_opportunities=sample_count,
                fee_efficiency_score=0.0,
                overall_score=0.0
            )
        
        strategy = self.strategies.get(strategy_name, self.strategies["balanced"])
        
        # Calculate target fee from percentile
        sorted_fees = sorted(historical_fees)
        percentile_idx = int(len(sorted_fees) * strategy["percentile"])
        target_fee = sorted_fees[min(percentile_idx, len(sorted_fees)-1)]
        target_fee = int(target_fee * strategy.get("multiplier", 1.0))
        
        # Run simulation
        landed = 0
        total_latency = 0
        total_fees = 0
        missed = 0
        
        # Sample from history
        sample_indices = random.choices(range(len(historical_fees)), k=min(sample_count, len(historical_fees)))
        
        for idx in sample_indices:
            market_fee = historical_fees[idx]
            market_latency = historical_latencies[idx]
            
            # Determine if our fee would land
            # Simple model: higher fee = higher chance, but market conditions matter
            fee_ratio = target_fee / max(market_fee, 1)
            
            # Landing probability increases with fee ratio
            if fee_ratio >= 1.5:
                land_probability = 0.95  # Very likely
            elif fee_ratio >= 1.0:
                land_probability = 0.85  # Likely
            elif fee_ratio >= 0.8:
                land_probability = 0.60  # Maybe
            else:
                land_probability = 0.30  # Unlikely
            
            # Simulate
            if random.random() < land_probability:
                landed += 1
                # Latency improves with higher fees
                latency_multiplier = max(0.5, 1.0 - (fee_ratio - 1.0) * 0.3)
                actual_latency = max(1, int(market_latency * latency_multiplier))
                total_latency += actual_latency
                total_fees += target_fee * compute_unit_limit // 1000000
            else:
                missed += 1
        
        # Calculate metrics
        success_rate = landed / sample_count if sample_count > 0 else 0
        avg_latency = total_latency / landed if landed > 0 else 999
        
        # Fee efficiency: success per lamport spent
        avg_fee_per_tx = total_fees / landed if landed > 0 else 999999999
        fee_efficiency = success_rate / (avg_fee_per_tx / 1000000) if avg_fee_per_tx > 0 else 0
        
        # Overall score balances success and efficiency
        overall = (success_rate * 0.6) + (min(fee_efficiency / 10, 1.0) * 0.4)
        
        return SimulationResult(
            strategy_name=strategy_name,
            compute_unit_price=target_fee,
            success_rate=round(success_rate, 3),
            avg_landed_slot=round(avg_latency, 1),
            total_fees_lamports=total_fees,
            missed_opportunities=missed,
            fee_efficiency_score=round(fee_efficiency, 3),
            overall_score=round(overall, 3)
        )
    
    def compare_strategies(
        self,
        historical_fees: List[int],
        historical_latencies: List[int],
        compute_unit_limit: int = 200000,
        sample_count: int = 1000
    ) -> Dict:
        """
        Compare all strategies and recommend the best.
        """
        results = {}
        
        for name in self.strategies.keys():
            result = self.simulate_strategy(
                historical_fees=historical_fees,
                historical_latencies=historical_latencies,
                strategy_name=name,
                compute_unit_limit=compute_unit_limit,
                sample_count=sample_count
            )
            results[name] = {
                "compute_unit_price": result.compute_unit_price,
                "success_rate": result.success_rate,
                "avg_landed_slot": result.avg_landed_slot,
                "total_fees_sol": round(result.total_fees_lamports / 1e9, 6),
                "missed_opportunities": result.missed_opportunities,
                "fee_efficiency": result.fee_efficiency_score,
                "overall_score": result.overall_score
            }
        
        # Find best strategy
        best = max(results.items(), key=lambda x: x[1]["overall_score"])
        
        return {
            "comparison": results,
            "recommended": best[0],
            "recommendation_reason": self._get_recommendation_reason(best[0], best[1]),
            "historical_sample_size": len(historical_fees),
            "simulation_timestamp": datetime.utcnow().isoformat()
        }
    
    def _get_recommendation_reason(self, strategy: str, metrics: Dict) -> str:
        """Generate human-readable recommendation."""
        success_rate = metrics["success_rate"]
        avg_slot = metrics["avg_landed_slot"]
        fees_sol = metrics["total_fees_sol"]
        
        if strategy == "cheap":
            return f"CHEAP strategy optimal: {success_rate:.1%} success, {fees_sol:.6f} SOL total cost. Best for non-urgent transactions."
        elif strategy == "balanced":
            return f"BALANCED strategy optimal: {success_rate:.1%} success, {avg_slot:.1f} slot avg latency. Good default choice."
        elif strategy == "urgent":
            return f"URGENT strategy optimal: {success_rate:.1%} success, {avg_slot:.1f} slot avg latency. Pay more for speed."
        elif strategy == "aggressive":
            return f"AGGRESSIVE strategy optimal: {success_rate:.1%} success. High cost ({fees_sol:.6f} SOL) but reliable."
        else:
            return f"ADAPTIVE strategy optimal: {success_rate:.1%} success. Adjusts to market conditions."
    
    def optimize_for_target(
        self,
        historical_fees: List[int],
        historical_latencies: List[int],
        target_success_rate: float = 0.95,
        max_acceptable_fee_sol: float = 0.01,
        compute_unit_limit: int = 200000
    ) -> Dict:
        """
        Find optimal fee for specific constraints.
        
        Args:
            target_success_rate: Minimum acceptable success rate
            max_acceptable_fee_sol: Maximum fee willing to pay
            
        Returns:
            Optimal fee recommendation
        """
        sorted_fees = sorted(historical_fees)
        max_fee_micro_lamports = int(max_acceptable_fee_sol * 1e9 * 1000000 / compute_unit_limit)
        
        # Binary search for optimal fee
        low = 0
        high = len(sorted_fees) - 1
        optimal_idx = high  # Default to highest
        
        while low <= high:
            mid = (low + high) // 2
            test_fee = sorted_fees[mid]
            
            # Simulate with this fee
            result = self.simulate_strategy(
                historical_fees=historical_fees,
                historical_latencies=historical_latencies,
                strategy_name="custom",
                compute_unit_limit=compute_unit_limit,
                sample_count=min(500, len(historical_fees))
            )
            
            if result.success_rate >= target_success_rate and test_fee <= max_fee_micro_lamports:
                optimal_idx = mid
                high = mid - 1  # Try lower
            else:
                low = mid + 1  # Need higher fee
        
        optimal_fee = sorted_fees[optimal_idx]
        
        return {
            "optimal_compute_unit_price": optimal_fee,
            "estimated_success_rate": target_success_rate,
            "estimated_fee_sol": round(optimal_fee * compute_unit_limit / 1e9 / 1000000, 6),
            "target_success_rate": target_success_rate,
            "max_fee_constraint_sol": max_acceptable_fee_sol,
            "confidence": "medium" if len(historical_fees) > 100 else "low"
        }


# Global engine
_engine: Optional[ReplayEngine] = None


def get_replay_engine() -> ReplayEngine:
    """Get or create replay engine."""
    global _engine
    if _engine is None:
        _engine = ReplayEngine()
    return _engine
