"""
Solana Transaction Builder
Real tx construction using Jupiter swap instructions + Jito bundles
"""

from typing import List, Dict, Optional, Any
from dataclasses import dataclass
import aiohttp
import asyncio


@dataclass
class SwapRoute:
    """Represents a single swap step"""
    amm_key: str
    input_mint: str
    output_mint: str
    in_amount: int
    out_amount: int
    fee_amount: int
    fee_mint: str


@dataclass
class JupiterQuote:
    """Jupiter quote response"""
    input_mint: str
    output_mint: str
    in_amount: int
    out_amount: int
    other_amount_threshold: int
    swap_mode: str
    slippage_bps: int
    price_impact_pct: str
    route_plan: List[SwapRoute]
    context_slot: int
    time_taken: float


@dataclass
class SwapInstructions:
    """Serialized swap instructions from Jupiter"""
    token_ledger_instruction: Optional[Dict]
    compute_budget_instructions: List[Dict]
    setup_instructions: List[Dict]
    swap_instruction: Dict
    cleanup_instruction: Optional[Dict]
    address_lookup_table_addresses: List[str]
    prioritization_fee_lamports: int


class SolanaTransactionBuilder:
    """
    Builds real Solana transactions for arbitrage execution.
    Uses Jupiter swap instructions + Jito bundles for MEV protection.
    """
    
    def __init__(
        self,
        jupiter_api: str = "https://api.jup.ag/swap/v1",
        jito_api: str = "https://mainnet.block-engine.jito.wtf/api/v1",
        helius_rpc: Optional[str] = None,
        wallet_keypair: Optional[str] = None
    ):
        self.jupiter_api = jupiter_api
        self.jito_api = jito_api
        self.helius_rpc = helius_rpc
        self.wallet_keypair = wallet_keypair
        self.session: Optional[aiohttp.ClientSession] = None
    
    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self
    
    async def __aexit__(self, *args):
        if self.session:
            await self.session.close()
    
    async def get_jupiter_quote(
        self,
        input_mint: str,
        output_mint: str,
        amount: int,
        slippage_bps: int = 50,
        only_direct_routes: bool = False
    ) -> Optional[JupiterQuote]:
        """
        Get Jupiter quote for a swap.
        
        Args:
            input_mint: Input token mint address (e.g., "So11111111111111111111111111111111111111112" for SOL)
            output_mint: Output token mint address
            amount: Amount in input token's smallest unit (lamports for SOL)
            slippage_bps: Slippage tolerance in basis points (50 = 0.5%)
            only_direct_routes: If True, only direct routes (no hops)
        """
        url = f"{self.jupiter_api}/quote"
        params = {
            "inputMint": input_mint,
            "outputMint": output_mint,
            "amount": str(amount),
            "slippageBps": slippage_bps,
            "onlyDirectRoutes": str(only_direct_routes).lower(),
            "asLegacyTransaction": "false"
        }
        
        async with self.session.get(url, params=params) as resp:
            if resp.status != 200:
                error_text = await resp.text()
                print(f"Jupiter quote error: {error_text}")
                return None
            
            data = await resp.json()
            
            return JupiterQuote(
                input_mint=data["inputMint"],
                output_mint=data["outputMint"],
                in_amount=int(data["inAmount"]),
                out_amount=int(data["outAmount"]),
                other_amount_threshold=int(data["otherAmountThreshold"]),
                swap_mode=data["swapMode"],
                slippage_bps=data["slippageBps"],
                price_impact_pct=data["priceImpactPct"],
                route_plan=[],  # Parse if needed
                context_slot=data.get("contextSlot", 0),
                time_taken=data.get("timeTaken", 0.0)
            )
    
    async def get_swap_instructions(
        self,
        user_public_key: str,
        quote: JupiterQuote,
        wrap_unwrap_sol: bool = True,
        use_shared_accounts: bool = True,
        prioritization_fee_lamports: int = 5000
    ) -> Optional[SwapInstructions]:
        """
        Get serialized swap instructions from Jupiter.
        
        Args:
            user_public_key: User's wallet public key
            quote: JupiterQuote from get_jupiter_quote()
            wrap_unwrap_sol: Auto wrap/unwrap SOL
            use_shared_accounts: Use shared accounts for cheaper txs
            prioritization_fee_lamports: Priority fee in lamports
        """
        url = f"{self.jupiter_api}/swap-instructions"
        
        payload = {
            "userPublicKey": user_public_key,
            "quoteResponse": {
                "inputMint": quote.input_mint,
                "outputMint": quote.output_mint,
                "inAmount": str(quote.in_amount),
                "outAmount": str(quote.out_amount),
                "otherAmountThreshold": str(quote.other_amount_threshold),
                "swapMode": quote.swap_mode,
                "slippageBps": quote.slippage_bps,
                "priceImpactPct": quote.price_impact_pct
            },
            "wrapAndUnwrapSol": wrap_unwrap_sol,
            "useSharedAccounts": use_shared_accounts,
            "prioritizationFeeLamports": prioritization_fee_lamports
        }
        
        async with self.session.post(url, json=payload) as resp:
            if resp.status != 200:
                error_text = await resp.text()
                print(f"Swap instructions error: {error_text}")
                return None
            
            data = await resp.json()
            
            return SwapInstructions(
                token_ledger_instruction=data.get("tokenLedgerInstruction"),
                compute_budget_instructions=data.get("computeBudgetInstructions", []),
                setup_instructions=data.get("setupInstructions", []),
                swap_instruction=data["swapInstruction"],
                cleanup_instruction=data.get("cleanupInstruction"),
                address_lookup_table_addresses=data.get("addressLookupTableAddresses", []),
                prioritization_fee_lamports=data.get("prioritizationFeeLamports", 0)
            )
    
    def build_transaction_from_instructions(
        self,
        instructions: SwapInstructions,
        recent_blockhash: str,
        signer_public_key: str
    ) -> Dict[str, Any]:
        """
        Build a complete transaction from Jupiter swap instructions.
        
        Returns a transaction object ready for signing and submission.
        """
        all_instructions = []
        
        # Add compute budget instructions (priority fee)
        all_instructions.extend(instructions.compute_budget_instructions)
        
        # Add token ledger instruction if present
        if instructions.token_ledger_instruction:
            all_instructions.append(instructions.token_ledger_instruction)
        
        # Add setup instructions (ATA creation, etc.)
        all_instructions.extend(instructions.setup_instructions)
        
        # Main swap instruction
        all_instructions.append(instructions.swap_instruction)
        
        # Cleanup instruction if present
        if instructions.cleanup_instruction:
            all_instructions.append(instructions.cleanup_instruction)
        
        transaction = {
            "recentBlockhash": recent_blockhash,
            "feePayer": signer_public_key,
            "instructions": all_instructions,
            "addressLookupTableAccounts": [
                {"key": addr} for addr in instructions.address_lookup_table_addresses
            ]
        }
        
        return transaction
    
    async def submit_jito_bundle(
        self,
        transactions: List[str],
        jito_auth_key: Optional[str] = None
    ) -> Optional[str]:
        """
        Submit transaction bundle to Jito for MEV protection.
        
        Args:
            transactions: List of base64-encoded signed transactions
            jito_auth_key: Optional Jito authentication key
        
        Returns:
            Bundle UUID if successful
        """
        url = f"{self.jito_api}/bundles"
        
        headers = {
            "Content-Type": "application/json"
        }
        if jito_auth_key:
            headers["Authorization"] = f"Bearer {jito_auth_key}"
        
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "sendBundle",
            "params": [transactions]
        }
        
        async with self.session.post(url, json=payload, headers=headers) as resp:
            if resp.status != 200:
                error_text = await resp.text()
                print(f"Jito bundle error: {error_text}")
                return None
            
            data = await resp.json()
            
            if "result" in data:
                return data["result"]  # Bundle UUID
            elif "error" in data:
                print(f"Jito error: {data['error']}")
                return None
            
            return None
    
    async def check_bundle_status(self, bundle_uuid: str) -> Dict[str, Any]:
        """Check status of submitted Jito bundle"""
        url = f"{self.jito_api}/bundles"
        
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "getBundleStatuses",
            "params": [[bundle_uuid]]
        }
        
        async with self.session.post(url, json=payload) as resp:
            data = await resp.json()
            return data.get("result", {}).get("value", [{}])[0]
    
    async def get_recent_blockhash(self) -> Optional[str]:
        """Get recent blockhash from Helius RPC"""
        if not self.helius_rpc:
            return None
        
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "getLatestBlockhash",
            "params": [{"commitment": "processed"}]
        }
        
        async with self.session.post(self.helius_rpc, json=payload) as resp:
            data = await resp.json()
            if "result" in data:
                return data["result"]["value"]["blockhash"]
            return None
    
    def calculate_profit_lamports(
        self,
        input_amount: int,
        expected_output: int,
        jupiter_fee_bps: int = 10,  # 0.1%
        jito_tip_lamports: int = 10000
    ) -> int:
        """
        Calculate expected profit in lamports after all fees.
        
        Returns:
            Net profit (can be negative for loss)
        """
        # Jupiter platform fee (0.1% default)
        jupiter_fee = (input_amount * jupiter_fee_bps) // 10000
        
        # Jito tip for bundle inclusion
        jito_tip = jito_tip_lamports
        
        # Network fee (approximate)
        network_fee = 5000
        
        total_costs = jupiter_fee + jito_tip + network_fee
        
        # Profit = output - input - costs
        # For circular arb: profit = final_output - initial_input - costs
        profit = expected_output - input_amount - total_costs
        
        return profit


# Token mint addresses (mainnet)
TOKENS = {
    "SOL": "So11111111111111111111111111111111111111112",
    "USDC": "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
    "USDT": "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",
    "BONK": "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",
    "JUP": "JUPyiwrYJFskUPiHa7hkeRQoUfXogLLgM3PR8zK3N8R",
    "RAY": "4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R",
    "ORCA": "orcaEKTdK7LKz57vaAYr9QeNsVEPfiu6QeMU1kektZE"
}


# Example usage
async def example():
    """Example: Build a swap transaction"""
    
    builder = SolanaTransactionBuilder(
        helius_rpc="https://rpc.helius.xyz/?api-key=YOUR_KEY"
    )
    
    async with builder:
        # Get quote: 0.1 SOL → USDC
        quote = await builder.get_jupiter_quote(
            input_mint=TOKENS["SOL"],
            output_mint=TOKENS["USDC"],
            amount=100_000_000,  # 0.1 SOL in lamports
            slippage_bps=50
        )
        
        if not quote:
            print("Failed to get quote")
            return
        
        print(f"Quote: {quote.in_amount} → {quote.out_amount}")
        print(f"Price impact: {quote.price_impact_pct}%")
        
        # Get swap instructions
        wallet_pubkey = "YOUR_WALLET_PUBLIC_KEY"
        instructions = await builder.get_swap_instructions(
            user_public_key=wallet_pubkey,
            quote=quote,
            prioritization_fee_lamports=5000
        )
        
        if not instructions:
            print("Failed to get swap instructions")
            return
        
        # Build transaction
        recent_blockhash = await builder.get_recent_blockhash()
        transaction = builder.build_transaction_from_instructions(
            instructions=instructions,
            recent_blockhash=recent_blockhash,
            signer_public_key=wallet_pubkey
        )
        
        print(f"Transaction built with {len(transaction['instructions'])} instructions")
        
        # Calculate profit if this was part of arb
        profit = builder.calculate_profit_lamports(
            input_amount=quote.in_amount,
            expected_output=quote.out_amount,
            jito_tip_lamports=10000
        )
        
        print(f"Estimated profit: {profit} lamports ({profit / 1e9} SOL)")


if __name__ == "__main__":
    asyncio.run(example())
