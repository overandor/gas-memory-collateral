"""
LLM Interpreter for Gas Memory Collateral
Uses Hugging Face Transformers (local models) - NO API KEY REQUIRED!
"""
import json
import hashlib
import re
from typing import Dict, List, Optional, Any
from datetime import datetime

from app.models.schemas import (
    FeeSample, SamplesSummary, LLMInterpretation,
    LLMPolicy, FeeCurves, FeeCurve, GasMemoryBundle,
    TransactionScope, ChainInfo, VerificationInfo, CollateralLogic
)
from app.utils.config import settings


class LLMInterpreter:
    """
    Interprets fee memory data using local Hugging Face models.
    No API key required - runs entirely locally!
    """

    # Default policy structure
    DEFAULT_POLICY = {
        "recommended_policy": {"cheap": "p50", "balanced": "p75", "urgent": "p90"},
        "reason": "Based on historical fee analysis",
        "confidence_score": 0.75,
        "risk_assessment": "Standard market conditions",
        "anomalies_detected": []
    }

    def __init__(self):
        self.provider = settings.LLM_PROVIDER
        self.model_name = settings.HF_MODEL_NAME if self.provider == "hf-local" else settings.OPENAI_MODEL
        self.device = settings.HF_DEVICE
        self.max_length = settings.HF_MAX_LENGTH
        self.temperature = settings.HF_TEMPERATURE

        # Lazy load the model
        self._pipeline = None
        self._tokenizer = None
        self._model = None

    def _load_model(self):
        """Lazy load Hugging Face model."""
        if self._pipeline is None and self.provider == "hf-local":
            try:
                from transformers import pipeline, AutoTokenizer, AutoModelForCausalLM
                import torch

                print(f"[LLM] Loading Hugging Face model: {self.model_name}")

                # Load tokenizer and model
                self._tokenizer = AutoTokenizer.from_pretrained(self.model_name)
                self._model = AutoModelForCausalLM.from_pretrained(
                    self.model_name,
                    torch_dtype=torch.float32,  # Use float32 for CPU compatibility
                    device_map="auto" if self.device == "cuda" else None,
                    low_cpu_mem_usage=True
                )

                if self.device == "cpu":
                    self._model = self._model.to("cpu")

                # Create pipeline for text generation
                self._pipeline = pipeline(
                    "text-generation",
                    model=self._model,
                    tokenizer=self._tokenizer,
                    device=0 if self.device == "cuda" else -1,
                    max_length=self.max_length,
                    temperature=self.temperature,
                    do_sample=True,
                    pad_token_id=self._tokenizer.eos_token_id
                )

                print(f"[LLM] Model loaded successfully on {self.device}")

            except Exception as e:
                print(f"[LLM] Warning: Could not load HF model: {e}")
                print("[LLM] Falling back to rule-based interpretation")
                self._pipeline = None

    async def interpret_samples(
        self,
        samples: List[FeeSample],
        summary: SamplesSummary,
        scope: TransactionScope,
        chain: ChainInfo,
        custom_prompt: Optional[str] = None
    ) -> LLMInterpretation:
        """
        Interpret fee samples using local LLM or fallback rules.

        Args:
            samples: List of fee samples
            summary: Statistical summary
            scope: Transaction scope
            chain: Chain information
            custom_prompt: Optional custom prompt

        Returns:
            LLMInterpretation with recommendations
        """
        # Build context
        context = self._build_context(samples, summary, scope, chain)

        if self.provider == "hf-local":
            result = await self._call_hf_local(context, custom_prompt)
        elif self.provider == "openai":
            result = await self._call_openai(context, custom_prompt)
        else:
            # Fallback to rule-based
            result = self._rule_based_interpretation(summary)

        return LLMInterpretation(
            model=self.model_name,
            recommended_policy=LLMPolicy(
                cheap=result.get("recommended_policy", {}).get("cheap", "p50"),
                balanced=result.get("recommended_policy", {}).get("balanced", "p75"),
                urgent=result.get("recommended_policy", {}).get("urgent", "p90")
            ),
            reason=result.get("reason", "Based on historical fee analysis"),
            confidence_score=result.get("confidence_score", 0.75),
            risk_assessment=result.get("risk_assessment"),
            anomalies_detected=result.get("anomalies_detected", [])
        )

    def _build_context(
        self,
        samples: List[FeeSample],
        summary: SamplesSummary,
        scope: TransactionScope,
        chain: ChainInfo
    ) -> str:
        """Build context string for LLM prompt."""

        # Calculate additional metrics
        normal_samples = [s for s in samples if s.compute_unit_price_micro_lamports < 50000]
        congested_samples = [s for s in samples if s.compute_unit_price_micro_lamports >= 50000]

        context = f"""TRANSACTION FEE MEMORY ANALYSIS

Chain: {chain.name} ({chain.network})
Transaction Family: {scope.tx_family}
Time Window: {scope.time_window}

SAMPLE STATISTICS:
- Total Samples: {summary.sample_count}
- Success Rate: {summary.success_rate:.2%}
- Median Latency: {summary.median_latency_slots} slots

FEE PERCENTILES (micro-lamports per CU):
- p50: {summary.p50_micro_lamports_per_cu}
- p75: {summary.p75_micro_lamports_per_cu}
- p90: {summary.p90_micro_lamports_per_cu}

NETWORK CONDITIONS:
- Normal regime samples: {len(normal_samples)}
- Congested regime samples: {len(congested_samples)}

LATENCY vs FEE CORRELATION:
- Success at p50: {self._calc_success_at_level(samples, summary.p50_micro_lamports_per_cu):.1%}
- Success at p75: {self._calc_success_at_level(samples, summary.p75_micro_lamports_per_cu):.1%}
- Success at p90: {self._calc_success_at_level(samples, summary.p90_micro_lamports_per_cu):.1%}

Analyze this data and recommend optimal fee policies.

Recommended output format:
{{
  "recommended_policy": {{"cheap": "p50", "balanced": "p75", "urgent": "p90"}},
  "reason": "explanation here",
  "confidence_score": 0.0-1.0,
  "risk_assessment": "brief description",
  "anomalies_detected": []
}}"""
        return context

    def _calc_success_at_level(
        self,
        samples: List[FeeSample],
        level: int,
        tolerance: float = 0.1
    ) -> float:
        """Calculate success rate at a given fee level."""
        matching = [
            s for s in samples
            if abs(s.compute_unit_price_micro_lamports - level) <= level * tolerance
        ]
        if not matching:
            return 0.0
        successful = sum(1 for s in matching if s.success)
        return successful / len(matching)

    async def _call_hf_local(self, context: str, custom_prompt: Optional[str] = None) -> Dict[str, Any]:
        """Call local Hugging Face model."""
        self._load_model()

        if self._pipeline is None:
            # Fallback to rule-based if model failed to load
            return self._rule_based_interpretation_from_context(context)

        try:
            prompt = custom_prompt or context

            # Generate response
            outputs = self._pipeline(
                prompt,
                max_new_tokens=256,
                num_return_sequences=1,
                temperature=self.temperature,
                do_sample=True,
                pad_token_id=self._tokenizer.eos_token_id
            )

            generated_text = outputs[0]["generated_text"]

            # Extract JSON from response
            result = self._extract_json_from_text(generated_text)

            if result:
                return result
            else:
                # Fallback to rule-based if JSON extraction fails
                return self._rule_based_interpretation_from_context(context)

        except Exception as e:
            print(f"[LLM] HF model error: {e}")
            return self._rule_based_interpretation_from_context(context)

    def _extract_json_from_text(self, text: str) -> Optional[Dict]:
        """Extract JSON object from generated text."""
        try:
            # Look for JSON pattern
            json_match = re.search(r'\{[^}]*"recommended_policy"[^}]*\}', text, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())

            # Try to find any JSON object
            json_match = re.search(r'\{.*\}', text, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())

        except json.JSONDecodeError:
            pass

        return None

    def _rule_based_interpretation_from_context(self, context: str) -> Dict[str, Any]:
        """Rule-based interpretation when LLM fails."""
        # Extract key metrics from context using simple parsing
        success_rate = 0.75  # Default
        sample_count = 100  # Default

        # Try to extract actual values
        if "Success Rate:" in context:
            try:
                rate_str = context.split("Success Rate:")[1].split("%")[0].strip()
                success_rate = float(rate_str) / 100
            except:
                pass

        if "Total Samples:" in context:
            try:
                count_str = context.split("Total Samples:")[1].split("\n")[0].strip()
                sample_count = int(count_str)
            except:
                pass

        return self._rule_based_interpretation_from_metrics(success_rate, sample_count)

    def _rule_based_interpretation(self, summary: SamplesSummary) -> Dict[str, Any]:
        """Rule-based interpretation from summary stats."""
        return self._rule_based_interpretation_from_metrics(summary.success_rate, summary.sample_count)

    def _rule_based_interpretation_from_metrics(self, success_rate: float, sample_count: int) -> Dict[str, Any]:
        """Generate interpretation based on success rate and sample count."""
        confidence = min(0.95, max(0.5, success_rate * (min(sample_count, 1000) / 1000)))

        if success_rate > 0.9:
            reason = f"Historical data shows excellent success rate of {success_rate:.1%} with sufficient samples. p75 offers optimal cost-speed balance."
            risk = "Low risk - high confidence in historical patterns"
        elif success_rate > 0.75:
            reason = f"Success rate of {success_rate:.1%} indicates reliable execution. p75 recommended for balanced approach."
            risk = "Moderate risk - acceptable for most transactions"
        else:
            reason = f"Success rate of {success_rate:.1%} suggests higher volatility. Consider p90 for critical transactions."
            risk = "Higher risk - consider market conditions"

        return {
            "recommended_policy": {"cheap": "p50", "balanced": "p75", "urgent": "p90"},
            "reason": reason,
            "confidence_score": round(confidence, 2),
            "risk_assessment": risk,
            "anomalies_detected": []
        }

    async def _call_openai(self, context: str, custom_prompt: Optional[str] = None) -> Dict[str, Any]:
        """Call OpenAI API (legacy fallback)."""
        import httpx

        messages = [
            {"role": "system", "content": "You are a Gas Memory Collateral interpreter."},
            {"role": "user", "content": custom_prompt or context}
        ]

        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    "https://api.openai.com/v1/chat/completions",
                    headers={"Authorization": f"Bearer {settings.OPENAI_API_KEY}"},
                    json={
                        "model": settings.OPENAI_MODEL,
                        "messages": messages,
                        "temperature": 0.1,
                        "response_format": {"type": "json_object"}
                    }
                )

                data = response.json()
                content = data["choices"][0]["message"]["content"]
                return json.loads(content)

        except Exception as e:
            print(f"[LLM] OpenAI error: {e}")
            return self._rule_based_interpretation_from_context(context)

    def calculate_summary_stats(self, samples: List[FeeSample]) -> SamplesSummary:
        """Calculate statistical summary from fee samples."""
        if not samples:
            raise ValueError("Cannot calculate stats from empty sample set")

        # Sort by compute unit price for percentiles
        sorted_samples = sorted(samples, key=lambda s: s.compute_unit_price_micro_lamports)
        n = len(sorted_samples)

        def percentile(p: float) -> int:
            idx = int(n * p / 100)
            return sorted_samples[max(0, min(idx, n - 1))].compute_unit_price_micro_lamports

        # Calculate success rate
        successful = sum(1 for s in samples if s.success)
        success_rate = successful / n

        # Calculate median latency
        latencies = sorted([s.confirmation_latency_slots for s in samples])
        median_latency = latencies[n // 2] if n > 0 else 0

        return SamplesSummary(
            sample_count=n,
            success_rate=success_rate,
            median_latency_slots=median_latency,
            p50_micro_lamports_per_cu=percentile(50),
            p75_micro_lamports_per_cu=percentile(75),
            p90_micro_lamports_per_cu=percentile(90),
            min_micro_lamports_per_cu=sorted_samples[0].compute_unit_price_micro_lamports,
            max_micro_lamports_per_cu=sorted_samples[-1].compute_unit_price_micro_lamports
        )

    def calculate_fee_curves(
        self,
        samples: List[FeeSample],
        congestion_threshold: int = 50000
    ) -> FeeCurves:
        """Calculate fee curves for normal and congested regimes."""
        normal = [s for s in samples if s.compute_unit_price_micro_lamports < congestion_threshold]
        congested = [s for s in samples if s.compute_unit_price_micro_lamports >= congestion_threshold]

        def curve_from_samples(s: List[FeeSample]) -> FeeCurve:
            if not s:
                return FeeCurve(p50_micro_lamports_per_cu=0, p75_micro_lamports_per_cu=0, p90_micro_lamports_per_cu=0)
            sorted_s = sorted(s, key=lambda x: x.compute_unit_price_micro_lamports)
            n = len(sorted_s)

            def p(pct: float) -> int:
                idx = int(n * pct / 100)
                return sorted_s[max(0, min(idx, n - 1))].compute_unit_price_micro_lamports

            return FeeCurve(
                p50_micro_lamports_per_cu=p(50),
                p75_micro_lamports_per_cu=p(75),
                p90_micro_lamports_per_cu=p(90)
            )

        return FeeCurves(
            normal=curve_from_samples(normal),
            congested=curve_from_samples(congested) if congested else None
        )

    async def generate_estimate(
        self,
        bundle: GasMemoryBundle,
        compute_unit_limit: int,
        risk_mode: str,
        target_latency: Optional[int] = None
    ) -> Dict[str, Any]:
        """Generate fee estimate from a memory bundle."""
        # Get recommended price from policy
        policy = bundle.llm_interpretation.recommended_policy

        if risk_mode == "cheap":
            price_field = policy.cheap
        elif risk_mode == "urgent":
            price_field = policy.urgent
        else:
            price_field = policy.balanced

        # Map pXX to actual value
        summary = bundle.samples_summary
        price_map = {
            "p50": summary.p50_micro_lamports_per_cu,
            "p75": summary.p75_micro_lamports_per_cu,
            "p90": summary.p90_micro_lamports_per_cu
        }

        micro_lamports_per_cu = price_map.get(price_field, summary.p75_micro_lamports_per_cu)

        # Calculate priority fee
        priority_fee_lamports = (micro_lamports_per_cu * compute_unit_limit) // 1_000_000

        # Base fee for Solana
        base_fee = 5000

        return {
            "recommended_compute_unit_price_micro_lamports": micro_lamports_per_cu,
            "estimated_priority_fee_lamports": priority_fee_lamports,
            "estimated_total_fee_lamports": base_fee + priority_fee_lamports,
            "confidence": bundle.llm_interpretation.confidence_score,
            "basis": {
                "memory_cid": "bundle_loaded",
                "matched_samples": summary.sample_count,
                "success_rate": summary.success_rate,
                "median_latency_slots": summary.median_latency_slots,
                "policy": price_field
            },
            "reasoning": bundle.llm_interpretation.reason,
            "risk_mode": risk_mode
        }

    def generate_claim(self, scope: TransactionScope, summary: SamplesSummary, curves: FeeCurves) -> str:
        """Generate human-readable claim for the bundle."""
        return (
            f"For {scope.tx_family} transactions on {scope.time_window} window, "
            f"{summary.p75_micro_lamports_per_cu // 1000}k micro-lamports/CU (p75) "
            f"historically achieved {summary.success_rate:.0%} success rate "
            f"with {summary.median_latency_slots:.0f} slot median latency."
        )

    def create_verification_info(self, samples: List[FeeSample], summary: SamplesSummary) -> VerificationInfo:
        """Create verification metadata."""
        # Calculate hashes
        sample_data = json.dumps([s.model_dump(mode='json') for s in samples], sort_keys=True)
        summary_data = summary.model_dump_json()

        return VerificationInfo(
            source="solana_rpc",
            methods=["getTransaction", "getSignatureStatuses", "getRecentPrioritizationFees"],
            dataset_sha256=hashlib.sha256(sample_data.encode()).hexdigest(),
            summary_sha256=hashlib.sha256(summary_data.encode()).hexdigest(),
            verification_timestamp=datetime.utcnow()
        )

    async def close(self):
        """Cleanup - nothing needed for HF local models."""
        pass


# Global instance
_interpreter: Optional[LLMInterpreter] = None


async def get_interpreter() -> LLMInterpreter:
    """Get or create interpreter instance."""
    global _interpreter
    if _interpreter is None:
        _interpreter = LLMInterpreter()
    return _interpreter
