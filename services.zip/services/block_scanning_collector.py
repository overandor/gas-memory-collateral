"""
Block Scanning Collector

Comprehensive collection using getBlock/getBlocksWithLimit.
Scans transactions and filters by programId in instructions.
This is the correct but heavier approach.
"""
import asyncio
import time
from typing import List, Dict, Optional, Any, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
import httpx

from app.services.rpc_provider_pool import get_provider_pool
from app.models.provenance import FeeSample
from app.services.dex_account_surfaces import get_dex_account_surfaces

@dataclass
class BlockScanConfig:
    """Configuration for block scanning."""
    chain: str = "solana"
    network: str = "mainnet-beta"
    tx_family: str = "jupiter_swap"
    target_program_ids: List[str] = None
    time_window_seconds: int = 3600
    sample_limit: int = 10000
    min_samples: int = 100
    max_blocks_to_scan: int = 100
    scan_batch_size: int = 10

class BlockScanningCollector:
    """
    Block scanning collector for comprehensive data collection.
    
    This is the correct approach:
    1. Get recent blocks
    2. Scan all transactions
    3. Filter by programId in instructions
    4. Extract fee data from verified transactions
    """
    
    def __init__(self):
        self.provider_pool = get_provider_pool()
        self.client = httpx.AsyncClient(timeout=30.0)
        self.dex_surfaces = get_dex_account_surfaces()
    
    async def collect_fee_samples_block_scanning(
        self,
        config: BlockScanConfig,
        collection_id: str
    ) -> Tuple[List[FeeSample], Dict[str, Any]]:
        """Collect fee samples using block scanning."""
        start_time = time.time()
        metadata = {
            "collection_id": collection_id,
            "config": config.__dict__,
            "started_at": datetime.utcnow().isoformat(),
            "method": "block_scanning",
            "blocks_scanned": 0,
            "transactions_scanned": 0,
            "samples_collected": 0,
            "verification_status": "pending"
        }
        
        try:
            # Get target program IDs for the DEX
            target_program_ids = config.target_program_ids or self._get_target_program_ids(config.tx_family)
            
            # Get recent blocks to scan
            blocks_to_scan = await self._get_blocks_to_scan(config)
            metadata["blocks_to_scan"] = len(blocks_to_scan)
            
            if not blocks_to_scan:
                return [], metadata
            
            # Scan blocks for transactions
            samples = await self._scan_blocks_for_samples(blocks_to_scan, target_program_ids, config, metadata)
            metadata["samples_collected"] = len(samples)
            
            # Update metadata
            metadata["completed_at"] = datetime.utcnow().isoformat()
            metadata["duration_seconds"] = time.time() - start_time
            
            return samples, metadata
            
        except Exception as e:
            metadata["error"] = str(e)
            metadata["failed_at"] = datetime.utcnow().isoformat()
            raise
    
    def _get_target_program_ids(self, tx_family: str) -> List[str]:
        """Get target program IDs for the transaction family."""
        # Get high-confidence surfaces for the DEX
        surfaces = self.dex_surfaces.get_high_confidence_surfaces(tx_family, min_confidence=0.8)
        
        # Extract unique program IDs
        program_ids = set()
        for surface in surfaces:
            if surface.surface_type in ["program", "router", "aggregator"]:
                program_ids.add(surface.address)
        
        # Add fallback surfaces if none found
        if not program_ids:
            fallback_addresses = self.dex_surfaces.get_fallback_addresses()
            program_ids.update(fallback_addresses)
        
        return list(program_ids)
    
    async def _get_blocks_to_scan(self, config: BlockScanConfig) -> List[int]:
        """Get recent block slots to scan."""
        try:
            provider = self.provider_pool.get_healthy_provider()
            if not provider:
                raise Exception("No healthy providers available")
            
            # Get current slot
            payload = {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "getSlot"
            }
            
            response = await self.client.post(
                provider.url,
                json=payload,
                headers={"Content-Type": "application/json"}
            )
            
            data = response.json()
            if "error" in data:
                raise Exception(f"RPC error getting slot: {data['error']}")
            
            current_slot = data.get("result", 0)
            
            # Calculate slots to scan (based on time window)
            # Solana average block time: ~400ms
            slots_per_second = 2.5
            slots_in_window = int(config.time_window_seconds * slots_per_second)
            slots_to_scan = min(slots_in_window, config.max_blocks_to_scan)
            
            # Generate recent block slots
            latest_blocks = []
            for i in range(slots_to_scan):
                block_slot = current_slot - i
                latest_blocks.append(block_slot)
            
            return latest_blocks
            
        except Exception as e:
            print(f"[BlockScanner] Error getting blocks to scan: {str(e)}")
            return []
    
    async def _scan_blocks_for_samples(
        self,
        block_slots: List[int],
        target_program_ids: List[str],
        config: BlockScanConfig,
        metadata: Dict[str, Any]
    ) -> List[FeeSample]:
        """Scan blocks for relevant transactions."""
        samples = []
        
        # Process blocks in batches
        batch_size = config.scan_batch_size
        
        for i in range(0, len(block_slots), batch_size):
            batch = block_slots[i:i + batch_size]
            
            try:
                batch_samples = await self._scan_block_batch(batch, target_program_ids, config)
                samples.extend(batch_samples)
                
                metadata["blocks_scanned"] += len(batch)
                metadata["transactions_scanned"] += sum(len(s) for s in batch_samples)  # This is approximate
                
                # Check if we have enough samples
                if len(samples) >= config.sample_limit:
                    samples = samples[:config.sample_limit]
                    break
                
                # Rate limiting
                await asyncio.sleep(0.2)
                
            except Exception as e:
                print(f"[BlockScanner] Error scanning batch {i//batch_size}: {str(e)}")
                continue
        
        return samples
    
    async def _scan_block_batch(
        self,
        block_slots: List[int],
        target_program_ids: List[str],
        config: BlockScanConfig
    ) -> List[FeeSample]:
        """Scan a batch of blocks for relevant transactions."""
        samples = []
        
        provider = self.provider_pool.get_healthy_provider()
        if not provider:
            raise Exception("No healthy providers available")
        
        for block_slot in block_slots:
            try:
                # Get block with transactions
                block_samples = await self._scan_single_block(block_slot, target_program_ids, provider, config)
                samples.extend(block_samples)
                
            except Exception as e:
                print(f"[BlockScanner] Error scanning block {block_slot}: {str(e)}")
                continue
        
        return samples
    
    async def _scan_single_block(
        self,
        block_slot: int,
        target_program_ids: List[str],
        provider,
        config: BlockScanConfig
    ) -> List[FeeSample]:
        """Scan a single block for relevant transactions."""
        try:
            # Get block with transactions
            payload = {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "getBlock",
                "params": [block_slot, {"encoding": "jsonParsed", "transactionDetails": "full", "rewards": False, "maxSupportedTransactionVersion": 0}]
            }
            
            response = await self.client.post(
                provider.url,
                json=payload,
                headers={"Content-Type": "application/json"}
            )
            
            data = response.json()
            if "error" in data:
                return []
            
            block_data = data.get("result")
            if not block_data:
                return []
            
            # Extract transactions from block
            transactions = block_data.get("transactions", [])
            block_time = block_data.get("blockTime")
            
            # Filter transactions by target program IDs
            relevant_transactions = []
            
            for tx in transactions:
                if self._transaction_contains_target_program(tx, target_program_ids):
                    relevant_transactions.append(tx)
            
            # Convert relevant transactions to fee samples
            samples = []
            for tx in relevant_transactions:
                sample = self._convert_transaction_to_sample(tx, block_slot, block_time, config)
                if sample:
                    samples.append(sample)
            
            return samples
            
        except Exception as e:
            print(f"[BlockScanner] Error scanning block {block_slot}: {str(e)}")
            return []
    
    def _transaction_contains_target_program(self, transaction: Dict[str, Any], target_program_ids: List[str]) -> bool:
        """Check if transaction contains any target program IDs."""
        try:
            # Get transaction message
            message = transaction.get("transaction", {}).get("message", {})
            
            # Check account keys (direct program calls)
            account_keys = message.get("accountKeys", [])
            for account_key in account_keys:
                if account_key in target_program_ids:
                    return True
            
            # Check instructions (programIdIndex)
            instructions = message.get("instructions", [])
            for instruction in instructions:
                if "programIdIndex" in instruction:
                    program_id_index = instruction["programIdIndex"]
                    if program_id_index < len(account_keys):
                        program_id = account_keys[program_id_index]
                        if program_id in target_program_ids:
                            return True
            
            # Check inner instructions (for complex programs)
            meta = transaction.get("meta", {})
            inner_instructions = meta.get("innerInstructions", [])
            for inner_group in inner_instructions:
                inner_instructions_list = inner_group.get("instructions", [])
                for inner_instruction in inner_instructions_list:
                    if "programIdIndex" in inner_instruction:
                        program_id_index = inner_instruction["programIdIndex"]
                        if program_id_index < len(account_keys):
                            program_id = account_keys[program_id_index]
                            if program_id in target_program_ids:
                                return True
            
            return False
            
        except Exception as e:
            print(f"[BlockScanner] Error checking transaction: {str(e)}")
            return False
    
    def _convert_transaction_to_sample(
        self,
        transaction: Dict[str, Any],
        block_slot: int,
        block_time: Optional[int],
        config: BlockScanConfig
    ) -> Optional[FeeSample]:
        """Convert transaction to fee sample."""
        try:
            # Get transaction metadata
            meta = transaction.get("meta", {})
            message = transaction.get("transaction", {}).get("message", {})
            
            # Extract fee information
            total_fee_lamports = meta.get("fee", 0)
            compute_units_consumed = meta.get("computeUnitsConsumed", 0)
            err = meta.get("err")
            success = err is None
            
            # Extract program IDs
            program_ids = []
            account_keys = message.get("accountKeys", [])
            instructions = message.get("instructions", [])
            
            for instruction in instructions:
                if "programIdIndex" in instruction:
                    program_id_index = instruction["programIdIndex"]
                    if program_id_index < len(account_keys):
                        program_id = account_keys[program_id_index]
                        program_ids.append(program_id)
            
            # Calculate fee per compute unit
            fee_per_cu_micro_lamports = 0
            if compute_units_consumed > 0:
                fee_per_cu_micro_lamports = (total_fee_lamports * 1_000_000) // compute_units_consumed
            
            # Get transaction signature
            signature = transaction.get("signature", [])
            if isinstance(signature, list):
                signature_str = "".join([str(s) for s in signature])
            else:
                signature_str = str(signature)
            
            # Create sample
            sample = FeeSample(
                signature=signature_str,
                slot=block_slot,
                block_time=datetime.fromtimestamp(block_time) if block_time else datetime.utcnow(),
                compute_units_consumed=compute_units_consumed,
                compute_unit_limit=0,  # Not easily available from block
                compute_unit_price_micro_lamports=fee_per_cu_micro_lamports,
                priority_fee_lamports=0,  # Hard to extract from block data
                base_fee_lamports=total_fee_lamports,
                total_fee_lamports=total_fee_lamports,
                confirmation_latency_slots=0,  # Can't calculate from block
                success=success,
                program_ids=program_ids,
                transaction_type=config.tx_family,
                verified=True,  # From block = verified
                source_provider="block_scanning",
                collected_at=datetime.utcnow()
            )
            
            return sample
            
        except Exception as e:
            print(f"[BlockScanner] Error converting transaction to sample: {str(e)}")
            return None
    
    async def get_collection_stats(self) -> Dict[str, Any]:
        """Get collection statistics."""
        return {
            "method": "block_scanning",
            "supported_dexes": self.dex_surfaces.get_supported_dexes(),
            "provider_pool_stats": self.provider_pool.get_provider_stats(),
            "capabilities": {
                "comprehensive_scanning": True,
                "instruction_level_filtering": True,
                "fallback_to_account_surfaces": True,
                "rate_limiting": True
            }
        }
    
    async def close(self):
        """Close HTTP client."""
        await self.client.aclose()

# Factory function
def get_block_scanning_collector() -> BlockScanningCollector:
    """Get block scanning collector instance."""
    return BlockScanningCollector()
