"""
SQLite Database Service for Gas Memory Collateral
Persists collections, samples, commits, and outcomes.
"""
import json
import sqlite3
import hashlib
from datetime import datetime
from typing import Optional, List, Dict, Any
from contextlib import contextmanager
from pathlib import Path

from app.models.schemas import FeeSample, GasMemoryBundle, CollectResponse
from app.utils.config import settings


class DatabaseService:
    """SQLite database for persisting gas memory data."""
    
    def __init__(self, db_path: str = "./data/gas_memory.db"):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()
    
    def _init_db(self):
        """Initialize database tables."""
        with self._get_conn() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS collections (
                    collection_id TEXT PRIMARY KEY,
                    tx_family TEXT NOT NULL,
                    chain TEXT NOT NULL,
                    time_window TEXT NOT NULL,
                    status TEXT DEFAULT 'collected',
                    samples_count INTEGER DEFAULT 0,
                    slot_start INTEGER,
                    slot_end INTEGER,
                    dataset_hash TEXT,
                    verification_hash TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
                
                CREATE TABLE IF NOT EXISTS samples (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    collection_id TEXT NOT NULL,
                    signature TEXT UNIQUE NOT NULL,
                    slot INTEGER NOT NULL,
                    timestamp TIMESTAMP,
                    compute_units_consumed INTEGER,
                    compute_unit_limit INTEGER,
                    compute_unit_price_micro_lamports INTEGER,
                    priority_fee_lamports INTEGER,
                    base_fee_lamports INTEGER,
                    total_fee_lamports INTEGER,
                    confirmation_latency_slots INTEGER,
                    success BOOLEAN,
                    program_ids TEXT,  -- JSON array
                    transaction_type TEXT,
                    source TEXT DEFAULT 'solana_rpc',
                    verified BOOLEAN DEFAULT FALSE,
                    FOREIGN KEY (collection_id) REFERENCES collections(collection_id)
                );
                
                CREATE TABLE IF NOT EXISTS bundles (
                    cid TEXT PRIMARY KEY,
                    collection_id TEXT NOT NULL,
                    bundle_json TEXT NOT NULL,  -- Full bundle JSON
                    summary_hash TEXT,
                    sample_count INTEGER,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (collection_id) REFERENCES collections(collection_id)
                );
                
                CREATE TABLE IF NOT EXISTS commits (
                    commit_hash TEXT PRIMARY KEY,
                    previous_hash TEXT,
                    chain_id TEXT,
                    task TEXT,
                    llm_model TEXT,
                    llm_output TEXT,  -- JSON
                    chain_data TEXT,  -- JSON
                    fee_context TEXT,  -- JSON
                    memory_refs TEXT,  -- JSON array
                    ipfs_cid TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
                
                CREATE TABLE IF NOT EXISTS outcomes (
                    outcome_hash TEXT PRIMARY KEY,
                    decision_hash TEXT NOT NULL,
                    signature TEXT NOT NULL,
                    landed BOOLEAN,
                    success BOOLEAN,
                    confirmation_latency_slots INTEGER,
                    compute_units_consumed INTEGER,
                    actual_fee_lamports INTEGER,
                    outcome_json TEXT,  -- Full outcome data
                    verified BOOLEAN DEFAULT FALSE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (decision_hash) REFERENCES commits(commit_hash)
                );
                
                CREATE INDEX IF NOT EXISTS idx_samples_collection ON samples(collection_id);
                CREATE INDEX IF NOT EXISTS idx_samples_signature ON samples(signature);
                CREATE INDEX IF NOT EXISTS idx_outcomes_decision ON outcomes(decision_hash);
                
                -- Arbitrage opportunities table
                CREATE TABLE IF NOT EXISTS arbitrage_opportunities (
                    scan_id TEXT PRIMARY KEY,
                    token_pair TEXT NOT NULL,
                    spread_bps INTEGER NOT NULL,
                    best_bid_dex TEXT NOT NULL,
                    best_ask_dex TEXT NOT NULL,
                    quotes_json TEXT NOT NULL,  -- JSON array of PriceQuote
                    artifact_id TEXT,
                    ipfs_cid TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
                
                CREATE INDEX IF NOT EXISTS idx_arb_spread ON arbitrage_opportunities(spread_bps);
                CREATE INDEX IF NOT EXISTS idx_arb_token_pair ON arbitrage_opportunities(token_pair);
                CREATE INDEX IF NOT EXISTS idx_arb_created ON arbitrage_opportunities(created_at);
            """)
            conn.commit()
    
    @contextmanager
    def _get_conn(self):
        """Get database connection."""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
        finally:
            conn.close()
    
    def save_collection(self, collection_id: str, tx_family: str, chain: str,
                       time_window: str, slot_start: int, slot_end: int,
                       samples_count: int = 0) -> bool:
        """Save collection metadata."""
        with self._get_conn() as conn:
            conn.execute("""
                INSERT OR REPLACE INTO collections 
                (collection_id, tx_family, chain, time_window, slot_start, slot_end, samples_count, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'collected')
            """, (collection_id, tx_family, chain, time_window, slot_start, slot_end, samples_count))
            conn.commit()
        return True
    
    def update_collection_status(self, collection_id: str, status: str,
                                  dataset_hash: Optional[str] = None,
                                  verification_hash: Optional[str] = None):
        """Update collection status and hashes."""
        with self._get_conn() as conn:
            conn.execute("""
                UPDATE collections 
                SET status = ?, dataset_hash = ?, verification_hash = ?, updated_at = CURRENT_TIMESTAMP
                WHERE collection_id = ?
            """, (status, dataset_hash, verification_hash, collection_id))
            conn.commit()
    
    def save_sample(self, collection_id: str, sample: FeeSample) -> bool:
        """Save a fee sample."""
        import sqlite3
        
        # Validate required fields
        if not sample.signature or len(sample.signature) < 10:
            print(f"[DB ERROR] Invalid signature for sample: {sample.signature}")
            return False
        if sample.slot is None or sample.slot < 0:
            print(f"[DB ERROR] Invalid slot for sample: {sample.signature[:20]}...")
            return False
        
        with self._get_conn() as conn:
            try:
                cursor = conn.execute("""
                    INSERT INTO samples
                    (collection_id, signature, slot, timestamp, compute_units_consumed,
                     compute_unit_limit, compute_unit_price_micro_lamports, priority_fee_lamports,
                     base_fee_lamports, total_fee_lamports, confirmation_latency_slots,
                     success, program_ids, transaction_type, source, verified)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    collection_id, 
                    sample.signature, 
                    sample.slot, 
                    sample.timestamp.isoformat() if sample.timestamp else datetime.utcnow().isoformat(),
                    sample.compute_units_consumed or 0, 
                    sample.compute_unit_limit or 200000,
                    sample.compute_unit_price_micro_lamports or 0, 
                    sample.priority_fee_lamports or 0,
                    sample.base_fee_lamports or 5000, 
                    sample.total_fee_lamports or 0,
                    sample.confirmation_latency_slots or 0, 
                    bool(sample.success),
                    json.dumps(sample.program_ids or []), 
                    sample.transaction_type or 'unknown',
                    getattr(sample, 'source', 'solana_rpc'), 
                    bool(getattr(sample, 'verified', False))
                ))
                conn.commit()
                return cursor.rowcount > 0
            except sqlite3.IntegrityError as e:
                print(f"[DB WARNING] Duplicate signature: {sample.signature[:40]}...")
                return False
            except Exception as e:
                print(f"[DB ERROR] Failed to insert sample: {e}")
                print(f"  Signature: {sample.signature[:40]}...")
                print(f"  Slot: {sample.slot}, Fee: {sample.total_fee_lamports}")
                return False
    
    def save_samples_batch(self, collection_id: str, samples: List[FeeSample]) -> int:
        """Save multiple samples with verification."""
        if not samples:
            print(f"[DB ERROR] No samples provided for collection {collection_id}")
            return 0
            
        count = 0
        errors = 0
        for sample in samples:
            if self.save_sample(collection_id, sample):
                count += 1
            else:
                errors += 1
        
        if errors > 0:
            print(f"[DB WARNING] {errors} samples failed to insert")
        
        # Verify actual count in database
        with self._get_conn() as conn:
            # Update collection count
            conn.execute("""
                UPDATE collections SET samples_count = samples_count + ?
                WHERE collection_id = ?
            """, (count, collection_id))
            conn.commit()
            
            # Verify actual rows inserted
            actual_count = conn.execute(
                "SELECT COUNT(*) FROM samples WHERE collection_id = ?",
                (collection_id,)
            ).fetchone()[0]
            
            if actual_count == 0 and count > 0:
                print(f"[DB CRITICAL] Insert claimed {count} samples but DB shows 0!")
                raise RuntimeError(f"Database insert failed: claimed {count} inserts but count is 0")
        
        print(f"[DB] Verified {actual_count} samples in database for {collection_id}")
        return count
    
    def get_samples(self, collection_id: str, verified_only: bool = False) -> List[FeeSample]:
        """Get samples for a collection."""
        with self._get_conn() as conn:
            query = "SELECT * FROM samples WHERE collection_id = ?"
            params = [collection_id]
            if verified_only:
                query += " AND verified = TRUE"
            
            rows = conn.execute(query, params).fetchall()
            
            samples = []
            for row in rows:
                samples.append(FeeSample(
                    signature=row['signature'],
                    timestamp=datetime.fromisoformat(row['timestamp']),
                    slot=row['slot'],
                    compute_units_consumed=row['compute_units_consumed'],
                    compute_unit_limit=row['compute_unit_limit'],
                    compute_unit_price_micro_lamports=row['compute_unit_price_micro_lamports'],
                    priority_fee_lamports=row['priority_fee_lamports'],
                    base_fee_lamports=row['base_fee_lamports'],
                    total_fee_lamports=row['total_fee_lamports'],
                    confirmation_latency_slots=row['confirmation_latency_slots'],
                    success=bool(row['success']),
                    program_ids=json.loads(row['program_ids']) if row['program_ids'] else [],
                    transaction_type=row['transaction_type'],
                    recent_priority_fees_context=None
                ))
            return samples
    
    def get_collection(self, collection_id: str) -> Optional[Dict]:
        """Get collection metadata."""
        with self._get_conn() as conn:
            row = conn.execute(
                "SELECT * FROM collections WHERE collection_id = ?",
                (collection_id,)
            ).fetchone()
            
            if row:
                return dict(row)
            return None
    
    def save_bundle(self, cid: str, collection_id: str, bundle: GasMemoryBundle):
        """Save bundle to database."""
        with self._get_conn() as conn:
            conn.execute("""
                INSERT OR REPLACE INTO bundles
                (cid, collection_id, bundle_json, summary_hash, sample_count)
                VALUES (?, ?, ?, ?, ?)
            """, (
                cid, collection_id, bundle.model_dump_json(),
                bundle.verification.summary_sha256,
                bundle.samples_summary.sample_count
            ))
            conn.commit()
    
    def get_bundle_by_cid(self, cid: str) -> Optional[GasMemoryBundle]:
        """Get bundle by CID."""
        with self._get_conn() as conn:
            row = conn.execute(
                "SELECT bundle_json FROM bundles WHERE cid = ?",
                (cid,)
            ).fetchone()
            
            if row:
                return GasMemoryBundle(**json.loads(row['bundle_json']))
            return None
    
    def save_commit(self, commit_hash: str, data: Dict):
        """Save commit record."""
        with self._get_conn() as conn:
            conn.execute("""
                INSERT OR REPLACE INTO commits
                (commit_hash, previous_hash, chain_id, task, llm_model, llm_output,
                 chain_data, fee_context, memory_refs, ipfs_cid)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                commit_hash,
                data.get('previous_hash'),
                data.get('chain_id'),
                data.get('task'),
                data.get('llm', {}).get('model'),
                json.dumps(data.get('llm', {}).get('output')),
                json.dumps(data.get('chain_data')),
                json.dumps(data.get('fee_context')),
                json.dumps(data.get('memory_refs')),
                data.get('ipfs_cid')
            ))
            conn.commit()
    
    def get_commit(self, commit_hash: str) -> Optional[Dict]:
        """Get commit record."""
        with self._get_conn() as conn:
            row = conn.execute(
                "SELECT * FROM commits WHERE commit_hash = ?",
                (commit_hash,)
            ).fetchone()
            
            if row:
                return dict(row)
            return None
    
    def save_outcome(self, outcome_hash: str, decision_hash: str, 
                    signature: str, landed: bool, success: bool,
                    latency_slots: int, compute_units: int, 
                    actual_fee: int, outcome_data: Dict):
        """Save outcome record."""
        with self._get_conn() as conn:
            conn.execute("""
                INSERT OR REPLACE INTO outcomes
                (outcome_hash, decision_hash, signature, landed, success,
                 confirmation_latency_slots, compute_units_consumed, actual_fee_lamports,
                 outcome_json, verified)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                outcome_hash, decision_hash, signature, landed, success,
                latency_slots, compute_units, actual_fee,
                json.dumps(outcome_data), False  # Will be verified via RPC
            ))
            conn.commit()
    
    def verify_sample_signatures(self, collection_id: str, rpc_client) -> int:
        """Verify sample signatures exist on-chain."""
        with self._get_conn() as conn:
            rows = conn.execute(
                "SELECT signature FROM samples WHERE collection_id = ? AND verified = FALSE",
                (collection_id,)
            ).fetchall()
            
            verified_count = 0
            for row in rows:
                signature = row['signature']
                # Would call RPC to verify signature exists
                # For now, mark as verified if signature format is valid
                if len(signature) > 10:  # Basic validation
                    conn.execute(
                        "UPDATE samples SET verified = TRUE WHERE signature = ?",
                        (signature,)
                    )
                    verified_count += 1
            
            conn.commit()
            return verified_count
    
    def save_arbitrage_opportunity(self, opportunity) -> bool:
        """Save arbitrage opportunity to database."""
        try:
            with self._get_conn() as conn:
                quotes_json = json.dumps([
                    {
                        "dex": q.dex,
                        "price": q.price,
                        "amount_in": q.amount_in,
                        "amount_out": q.amount_out,
                        "latency_ms": q.latency_ms
                    }
                    for q in opportunity.quotes
                ])
                
                conn.execute("""
                    INSERT OR REPLACE INTO arbitrage_opportunities
                    (scan_id, token_pair, spread_bps, best_bid_dex, best_ask_dex,
                     quotes_json, artifact_id, ipfs_cid)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    opportunity.scan_id,
                    opportunity.token_pair,
                    opportunity.spread_bps,
                    opportunity.best_bid_dex,
                    opportunity.best_ask_dex,
                    quotes_json,
                    opportunity.artifact_id,
                    opportunity.ipfs_cid
                ))
                conn.commit()
                return True
        except Exception as e:
            print(f"[DB] Error saving arbitrage opportunity: {e}")
            return False
    
    def get_arbitrage_opportunities(self, min_spread_bps: int = 0, 
                                     limit: int = 100) -> List[Dict]:
        """Get recent arbitrage opportunities."""
        with self._get_conn() as conn:
            rows = conn.execute("""
                SELECT * FROM arbitrage_opportunities
                WHERE spread_bps >= ?
                ORDER BY created_at DESC
                LIMIT ?
            """, (min_spread_bps, limit)).fetchall()
            
            return [dict(row) for row in rows]


# Global instance
_db: Optional[DatabaseService] = None


def get_db() -> DatabaseService:
    """Get or create database instance."""
    global _db
    if _db is None:
        _db = DatabaseService()
    return _db
