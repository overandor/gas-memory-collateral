"""
Analytical Interpreter for Gas Memory Collateral
Replaces decorative LLM with deterministic analytical engine.
"""
import json
import hashlib
from typing import List
from datetime import datetime

from app.models.schemas import (
    FeeSample, SamplesSummary, LLMInterpretation,
    LLMPolicy, FeeCurves, GasMemoryBundle,
    TransactionScope, ChainInfo, VerificationInfo, CollateralLogic
)
from app.services.analytical_engine import AnalyticalEngine


class AnalyticalInterpreter:
    """
    Analytical interpreter using deterministic scoring models.
    Replaces LLM with mathematical analysis for consistent, explainable results.
    """

    def __init__(self):
        self.engine = AnalyticalEngine()
        self.provider = "analytical_engine_v1.0"
        self.model_name = "deterministic_scoring_model"

    async def interpret_fee_memory(
        self,
        samples: List[FeeSample],
        tx_family: str,
        chain: str,
        time_window: str
    ) -> LLMInterpretation:
        """
        Generate analytical interpretation of fee memory data.

        Args:
            samples: List of fee samples
            tx_family: Transaction family
            chain: Blockchain network
            time_window: Time window analyzed

        Returns:
            LLMInterpretation with analytical insights
        """
        if not samples:
            return self._create_empty_interpretation()

        # Calculate execution score
        score = self.engine.calculate_execution_score(samples)

        # Generate interpretation
        interpretation = self.engine.create_interpretation(samples, score)

        return interpretation

    def _create_empty_interpretation(self) -> LLMInterpretation:
        """Create interpretation for empty dataset."""
        return LLMInterpretation(
            model=self.model_name,
            recommended_policy=LLMPolicy(
                cheap="p50",
                balanced="p75", 
                urgent="p90"
            ),
            reason="Insufficient data for analysis",
            confidence_score=0.0,
            risk_assessment="unknown",
            anomalies_detected=["No samples available"]
        )

    async def create_gas_memory_bundle(
        self,
        samples: List[FeeSample],
        tx_family: str,
        chain: str,
        time_window: str,
        program_ids: List[str] = None
    ) -> GasMemoryBundle:
        """
        Create complete gas memory bundle with analytical interpretation.

        Args:
            samples: List of fee samples
            tx_family: Transaction family
            chain: Blockchain network
            time_window: Time window
            program_ids: Program IDs filtered

        Returns:
            Complete GasMemoryBundle
        """
        if program_ids is None:
            program_ids = []

        # Create samples summary
        summary = self._create_samples_summary(samples)

        # Generate fee curves
        normal_curve = self.engine.generate_fee_curves(samples)
        fee_curves = FeeCurves(
            normal=normal_curve,
            congested=None,  # Could be calculated from congestion periods
            extreme=None     # Could be calculated from extreme periods
        )

        # Generate analytical interpretation
        interpretation = await self.interpret_fee_memory(samples, tx_family, chain, time_window)

        # Create bundle
        bundle = GasMemoryBundle(
            type="gas_memory_collateral_bundle",
            version="1.0",
            created_at=datetime.utcnow(),
            chain=ChainInfo(name=chain, network="mainnet-beta"),
            scope=TransactionScope(
                tx_family=tx_family,
                program_ids=program_ids,
                time_window=time_window
            ),
            claim=self._generate_claim(summary, interpretation),
            samples_summary=summary,
            fee_curve=fee_curves,
            verification=VerificationInfo(
                source="solana_rpc",
                methods=["getTransaction", "getSignatureStatuses", "getRecentPrioritizationFees"],
                dataset_sha256=self._calculate_samples_hash(samples),
                summary_sha256=self._calculate_summary_hash(interpretation),
                verification_timestamp=datetime.utcnow()
            ),
            llm_interpretation=interpretation,
            collateral_logic=CollateralLogic(
                collateral_type="informational_collateral",
                backs="future_execution_fee_estimates",
                reduces_uncertainty=True,
                legal_financial_collateral=False
            )
        )

        return bundle

    def _create_samples_summary(self, samples: List[FeeSample]) -> SamplesSummary:
        """Create statistical summary of samples."""
        if not samples:
            return SamplesSummary(
                sample_count=0,
                success_rate=0.0,
                median_latency_slots=0.0,
                p50_micro_lamports_per_cu=0,
                p75_micro_lamports_per_cu=0,
                p90_micro_lamports_per_cu=0,
                min_micro_lamports_per_cu=0,
                max_micro_lamports_per_cu=0
            )

        # Filter successful samples for fee calculations
        successful_samples = [s for s in samples if s.success]
        
        # Calculate metrics
        sample_count = len(samples)
        success_rate = len(successful_samples) / sample_count if sample_count > 0 else 0.0

        # Latency metrics
        latencies = [s.confirmation_latency_slots for s in successful_samples]
        median_latency = sorted(latencies)[len(latencies) // 2] if latencies else 0.0

        # Fee per compute unit metrics
        fees_per_cu = []
        for s in successful_samples:
            if s.compute_units_consumed > 0:
                fee_per_cu = s.total_fee_lamports / s.compute_units_consumed
                fees_per_cu.append(fee_per_cu)

        if fees_per_cu:
            fees_per_cu.sort()
            n = len(fees_per_cu)
            p50 = fees_per_cu[int(n * 0.5)]
            p75 = fees_per_cu[int(n * 0.75)]
            p90 = fees_per_cu[int(n * 0.9)]
            min_fee = min(fees_per_cu)
            max_fee = max(fees_per_cu)
        else:
            p50 = p75 = p90 = min_fee = max_fee = 0

        return SamplesSummary(
            sample_count=sample_count,
            success_rate=success_rate,
            median_latency_slots=median_latency,
            p50_micro_lamports_per_cu=int(p50),
            p75_micro_lamports_per_cu=int(p75),
            p90_micro_lamports_per_cu=int(p90),
            min_micro_lamports_per_cu=int(min_fee),
            max_micro_lamports_per_cu=int(max_fee)
        )

    def _generate_claim(self, summary: SamplesSummary, interpretation: LLMInterpretation) -> str:
        """Generate analytical claim about the fee data."""
        if summary.sample_count == 0:
            return "No data available for analysis."

        # Create claim based on actual metrics
        claim_parts = []

        # Success rate claim
        claim_parts.append(f"For {summary.sample_count:,} samples")
        claim_parts.append(f"success rate of {summary.success_rate:.1%}")

        # Fee claim
        if summary.p75_micro_lamports_per_cu > 0:
            claim_parts.append(f"p75 fee of {summary.p75_micro_lamports_per_cu:,} µL/CU")

        # Latency claim
        if summary.median_latency_slots > 0:
            claim_parts.append(f"median {summary.median_latency_slots:.1f} slots")

        # Risk assessment
        if interpretation.risk_assessment:
            risk_level = interpretation.risk_assessment.replace("_risk", "")
            claim_parts.append(f"{risk_level} risk profile")

        return " ".join(claim_parts) + "."

    def _calculate_samples_hash(self, samples: List[FeeSample]) -> str:
        """Calculate SHA256 hash of samples data."""
        samples_data = json.dumps([s.model_dump() for s in samples], sort_keys=True)
        return hashlib.sha256(samples_data.encode()).hexdigest()

    def _calculate_summary_hash(self, interpretation: LLMInterpretation) -> str:
        """Calculate SHA256 hash of interpretation."""
        summary_data = json.dumps(interpretation.model_dump(), sort_keys=True)
        return hashlib.sha256(summary_data.encode()).hexdigest()

    async def close(self):
        """Cleanup resources (no-op for analytical engine)."""
        pass

# Factory function for backward compatibility
def get_interpreter() -> AnalyticalInterpreter:
    """Get analytical interpreter instance."""
    return AnalyticalInterpreter()
