"""
Canonical Artifact Service

Handles canonical JSON serialization, SHA-256 hashing, and content addressing
for Gas Memory Post artifacts. Ensures reproducible hashes across networks.
"""
import json
import hashlib
from typing import Dict, Any, List, Optional
from datetime import datetime
from dataclasses import dataclass, asdict

from app.models.provenance import FeeSample, GasMemoryArtifact, TemporalSurface
from app.models.gas_memory_post import GasMemoryPost, FeeStatistics, VerificationInfo, StorageReferences

@dataclass
class TemporalPoint:
    """Single point in the 30-point temporal surface."""
    point_index: int
    point_type: str  # real, extrapolation, prediction
    timestamp: Optional[datetime]
    slot_offset: Optional[int]
    fee_micro_lamports: int
    fee_per_cu: float
    priority_fee: int
    latency_slots: int
    success_probability: float
    llm_regime: Optional[str]
    llm_confidence: Optional[float]
    llm_reasoning: Optional[str]
    signature: Optional[str]
    verified: bool

class CanonicalJSONSerializer:
    """
    Canonical JSON serialization for consistent hashing.
    
    Ensures identical content produces identical hashes regardless of
    serialization order or formatting differences.
    """
    
    @staticmethod
    def serialize(data: Dict[str, Any]) -> str:
        """
        Serialize data to canonical JSON.
        
        Rules:
        1. Sort all object keys alphabetically
        2. Use compact separators (no spaces)
        3. Ensure consistent float formatting
        4. Handle datetime consistently
        5. Remove None values
        """
        def canonicalize(obj):
            if obj is None:
                return None
            elif isinstance(obj, bool):
                return obj
            elif isinstance(obj, (int, float)):
                # Ensure consistent float formatting
                if isinstance(obj, float):
                    return round(obj, 8)  # 8 decimal places for consistency
                return obj
            elif isinstance(obj, str):
                return obj
            elif isinstance(obj, datetime):
                # ISO format with consistent timezone
                return obj.isoformat() + "Z"
            elif isinstance(obj, dict):
                # Sort keys recursively, remove None values
                sorted_dict = {}
                for key in sorted(obj.keys()):
                    value = canonicalize(obj[key])
                    if value is not None:
                        sorted_dict[key] = value
                return sorted_dict
            elif isinstance(obj, list):
                # Canonicalize list elements
                return [canonicalize(item) for item in obj]
            else:
                # Convert other types to string
                return str(obj)
        
        canonical_data = canonicalize(data)
        return json.dumps(canonical_data, separators=(',', ':'), ensure_ascii=False)
    
    @staticmethod
    def hash_content(content: Dict[str, Any]) -> str:
        """Generate SHA-256 hash of canonical JSON content."""
        canonical_json = CanonicalJSONSerializer.serialize(content)
        return hashlib.sha256(canonical_json.encode('utf-8')).hexdigest()

class GasMemoryArtifactBuilder:
    """
    Builds canonical Gas Memory Post artifacts from collected data.
    
    Creates content-addressed artifacts with:
    - Canonical JSON serialization
    - SHA-256 content hashing
    - IPFS/Arweave storage references
    - Temporal surface generation
    """
    
    def __init__(self):
        self.serializer = CanonicalJSONSerializer()
    
    def build_artifact(
        self,
        collection_id: str,
        chain: str,
        network: str,
        tx_family: str,
        program_ids: List[str],
        time_window_seconds: int,
        samples: List[FeeSample],
        verification_proofs: List[Dict[str, Any]],
        storage_references: Optional[Dict[str, Any]] = None,
        include_llm_insights: bool = True
    ) -> GasMemoryPost:
        """
        Build a complete Gas Memory Post artifact.
        
        Args:
            collection_id: Unique collection identifier
            chain: Blockchain name
            network: Network identifier
            tx_family: Transaction family
            program_ids: Target program IDs
            time_window_seconds: Collection time window
            samples: Collected fee samples
            verification_proofs: Cryptographic verification proofs
            storage_references: Storage network references
            include_llm_insights: Whether to include LLM analysis
            
        Returns:
            Complete GasMemoryPost artifact
        """
        # Build fee statistics
        fee_stats = self._build_fee_statistics(samples)
        
        # Build verification info
        verification_info = self._build_verification_info(verification_proofs)
        
        # Build storage references
        storage_refs = self._build_storage_references(storage_references)
        
        # Build temporal surface
        temporal_surface = self._build_temporal_surface(samples, fee_stats)
        
        # Build LLM insights (if enabled)
        llm_interpretation = None
        if include_llm_insights:
            llm_interpretation = self._build_llm_interpretation(fee_stats, temporal_surface)
        
        # Build collateral logic
        collateral_logic = self._build_collateral_logic()
        
        # Create artifact content
        artifact_content = {
            "type": "gas_memory_post",
            "version": "1.0",
            "created_at": datetime.utcnow().isoformat() + "Z",
            "chain": {
                "name": chain,
                "network": network
            },
            "scope": {
                "tx_family": tx_family,
                "program_ids": program_ids,
                "time_window": f"{time_window_seconds}s",
                "collection_id": collection_id
            },
            "claim": self._generate_claim(tx_family, fee_stats),
            "samples_summary": {
                "sample_count": fee_stats.sample_count,
                "verified_samples": fee_stats.verified_samples,
                "success_rate": fee_stats.success_rate,
                "median_latency_slots": fee_stats.median_latency_slots,
                "p50_micro_lamports_per_cu": fee_stats.p50_micro_lamports_per_cu,
                "p75_micro_lamports_per_cu": fee_stats.p75_micro_lamports_per_cu,
                "p90_micro_lamports_per_cu": fee_stats.p90_micro_lamports_per_cu,
                "min_micro_lamports_per_cu": fee_stats.min_micro_lamports_per_cu,
                "max_micro_lamports_per_cu": fee_stats.max_micro_lamports_per_cu
            },
            "fee_curve": {
                "normal": {
                    "p50_micro_lamports_per_cu": fee_stats.p50_micro_lamports_per_cu,
                    "p75_micro_lamports_per_cu": fee_stats.p75_micro_lamports_per_cu,
                    "p90_micro_lamports_per_cu": fee_stats.p90_micro_lamports_per_cu
                }
            },
            "verification": verification_info,
            "llm_interpretation": llm_interpretation,
            "collateral_logic": collateral_logic,
            "temporal_surface": temporal_surface,
            "storage_references": storage_refs
        }
        
        # Generate canonical hash
        canonical_hash = self.serializer.hash_content(artifact_content)
        
        # Add hash to content
        artifact_content["canonical_sha256"] = canonical_hash
        artifact_content["content_hash"] = canonical_hash
        
        # Create GasMemoryPost object
        post = GasMemoryPost(
            type=artifact_content["type"],
            version=artifact_content["version"],
            chain=artifact_content["chain"],
            tx_family=artifact_content["scope"]["tx_family"],
            claim=artifact_content["claim"],
            canonical_sha256=canonical_hash,
            content_hash=canonical_hash,
            storage_references=storage_refs,
            provenance_status=self._determine_provenance_status(storage_refs),
            source="solana_rpc",
            verification_info=VerificationInfo(**verification_info),
            fee_statistics=FeeStatistics(**fee_stats.__dict__),
            created_at=datetime.fromisoformat(artifact_content["created_at"][:-1]),  # Remove 'Z'
            analytical_insights=llm_interpretation.get("analytical_insights") if llm_interpretation else None,
            risk_assessment=llm_interpretation.get("risk_assessment") if llm_interpretation else None
        )
        
        return post
    
    def _build_fee_statistics(self, samples: List[FeeSample]) -> FeeStatistics:
        """Build fee statistics from samples."""
        if not samples:
            return FeeStatistics(
                sample_count=0,
                verified_samples=0,
                success_rate=0.0,
                median_latency_slots=0.0,
                p50_micro_lamports_per_cu=0,
                p75_micro_lamports_per_cu=0,
                p90_micro_lamports_per_cu=0,
                min_micro_lamports_per_cu=0,
                max_micro_lamports_per_cu=0
            )
        
        # Extract metrics
        total_samples = len(samples)
        verified_samples = sum(1 for s in samples if s.verified)
        success_samples = [s for s in samples if s.success]
        success_rate = len(success_samples) / total_samples if total_samples > 0 else 0.0
        
        # Latency statistics
        latencies = [s.confirmation_latency_slots for s in success_samples]
        latencies.sort()
        median_latency = latencies[len(latencies) // 2] if latencies else 0.0
        
        # Fee per compute unit statistics
        fees_per_cu = []
        for s in success_samples:
            if s.compute_units_consumed > 0:
                fee_per_cu = s.total_fee_lamports / s.compute_units_consumed
                fees_per_cu.append(fee_per_cu)
        
        if fees_per_cu:
            fees_per_cu.sort()
            n = len(fees_per_cu)
            p50 = int(fees_per_cu[int(n * 0.5)] * 1_000_000)  # Convert to micro-lamports
            p75 = int(fees_per_cu[int(n * 0.75)] * 1_000_000)
            p90 = int(fees_per_cu[int(n * 0.90)] * 1_000_000)
            min_fee = int(min(fees_per_cu) * 1_000_000)
            max_fee = int(max(fees_per_cu) * 1_000_000)
        else:
            p50 = p75 = p90 = min_fee = max_fee = 0
        
        return FeeStatistics(
            sample_count=total_samples,
            verified_samples=verified_samples,
            success_rate=success_rate,
            median_latency_slots=median_latency,
            p50_micro_lamports_per_cu=p50,
            p75_micro_lamports_per_cu=p75,
            p90_micro_lamports_per_cu=p90,
            min_micro_lamports_per_cu=min_fee,
            max_micro_lamports_per_cu=max_fee
        )
    
    def _build_verification_info(self, verification_proofs: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Build verification information."""
        if not verification_proofs:
            return {
                "source": "solana_rpc",
                "methods": [],
                "dataset_sha256": "",
                "summary_sha256": "",
                "verification_timestamp": datetime.utcnow().isoformat() + "Z",
                "verification_proofs": [],
                "provider_stats": {}
            }
        
        # Extract verification methods
        methods = list(set(proof.get("method", "unknown") for proof in verification_proofs))
        
        # Calculate dataset hash
        dataset_content = {
            "proofs": verification_proofs,
            "count": len(verification_proofs)
        }
        dataset_hash = self.serializer.hash_content(dataset_content)
        
        # Calculate summary hash
        summary_content = {
            "methods": methods,
            "proof_count": len(verification_proofs),
            "verified_count": sum(1 for p in verification_proofs if p.get("verified", False))
        }
        summary_hash = self.serializer.hash_content(summary_content)
        
        # Extract provider stats
        provider_stats = {}
        for proof in verification_proofs:
            provider = proof.get("provider", "unknown")
            if provider not in provider_stats:
                provider_stats[provider] = {"count": 0, "verified": 0}
            provider_stats[provider]["count"] += 1
            if proof.get("verified", False):
                provider_stats[provider]["verified"] += 1
        
        return {
            "source": "solana_rpc",
            "methods": methods,
            "dataset_sha256": dataset_hash,
            "summary_sha256": summary_hash,
            "verification_timestamp": datetime.utcnow().isoformat() + "Z",
            "verification_proofs": verification_proofs,
            "provider_stats": provider_stats
        }
    
    def _build_storage_references(self, storage_refs: Optional[Dict[str, Any]]) -> StorageReferences:
        """Build storage references."""
        if not storage_refs:
            return StorageReferences(
                ipfs_cid=None,
                arweave_txid=None,
                gateway_urls={},
                pinned=False,
                storage_type="local_dev_store"
            )
        
        return StorageReferences(
            ipfs_cid=storage_refs.get("ipfs_cid"),
            arweave_txid=storage_refs.get("arweave_txid"),
            gateway_urls=storage_refs.get("gateway_urls", {}),
            pinned=storage_refs.get("pinned", False),
            storage_type=storage_refs.get("storage_type", "local_dev_store")
        )
    
    def _build_temporal_surface(self, samples: List[FeeSample], fee_stats: FeeStatistics) -> List[Dict[str, Any]]:
        """Build 30-point temporal surface."""
        temporal_points = []
        
        # Separate real samples
        real_samples = [s for s in samples if s.verified][:10]  # Max 10 real samples
        
        # Create real points
        for i, sample in enumerate(real_samples):
            point = {
                "point_index": i,
                "point_type": "real",
                "timestamp": sample.block_time.isoformat() + "Z" if sample.block_time else None,
                "slot_offset": None,  # Would need collection start slot
                "fee_micro_lamports": sample.compute_unit_price_micro_lamports,
                "fee_per_cu": sample.total_fee_lamports / max(sample.compute_units_consumed, 1),
                "priority_fee": sample.priority_fee_lamports,
                "latency_slots": sample.confirmation_latency_slots,
                "success_probability": 1.0 if sample.success else 0.0,
                "llm_regime": None,
                "llm_confidence": None,
                "llm_reasoning": None,
                "signature": sample.signature,
                "verified": sample.verified
            }
            temporal_points.append(point)
        
        # Create extrapolation points (near-history)
        base_fee = fee_stats.p75_micro_lamports_per_cu
        for i in range(10, 20):
            point = {
                "point_index": i,
                "point_type": "extrapolation",
                "timestamp": None,
                "slot_offset": (i - 10) * -10,  # 10 slots back
                "fee_micro_lamports": base_fee + (i - 15) * 1000,  # Variation around base
                "fee_per_cu": (base_fee + (i - 15) * 1000) / 1_000_000,
                "priority_fee": 10000,
                "latency_slots": 2,
                "success_probability": 0.85,
                "llm_regime": "normal",
                "llm_confidence": 0.7,
                "llm_reasoning": "Extrapolated from recent patterns",
                "signature": None,
                "verified": False
            }
            temporal_points.append(point)
        
        # Create prediction points (forward)
        for i in range(20, 30):
            point = {
                "point_index": i,
                "point_type": "prediction",
                "timestamp": None,
                "slot_offset": (i - 20) * 10,  # 10 slots forward
                "fee_micro_lamports": base_fee + (i - 25) * 500,  # Less variation forward
                "fee_per_cu": (base_fee + (i - 25) * 500) / 1_000_000,
                "priority_fee": 15000,
                "latency_slots": 1,
                "success_probability": 0.9,
                "llm_regime": "predicted_normal",
                "llm_confidence": 0.6,
                "llm_reasoning": "Predicted fee pattern based on historical data",
                "signature": None,
                "verified": False
            }
            temporal_points.append(point)
        
        return temporal_points
    
    def _build_llm_interpretation(self, fee_stats: FeeStatistics, temporal_surface: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """Build LLM interpretation (clearly marked as non-authoritative)."""
        if fee_stats.sample_count < 10:
            return {
                "model": "analytical_engine_v1.0",
                "recommended_policy": {
                    "cheap": "p50",
                    "balanced": "p75",
                    "urgent": "p90"
                },
                "reason": "Insufficient data for detailed analysis",
                "confidence_score": 0.3,
                "risk_assessment": "high_uncertainty",
                "anomalies_detected": ["insufficient_sample_size"],
                "analytical_insights": {
                    "execution_score": 0.4,
                    "risk_level": "high",
                    "confidence": 0.3
                },
                "non_authoritative": True,
                "disclaimer": "LLM interpretation is for informational purposes only and should not be used for execution decisions"
            }
        
        # Calculate execution score
        execution_score = (
            fee_stats.success_rate * 0.6 +
            (1.0 / (1.0 + fee_stats.median_latency_slots)) * 0.4
        )
        
        # Determine risk level
        if fee_stats.success_rate >= 0.95:
            risk_level = "low"
        elif fee_stats.success_rate >= 0.85:
            risk_level = "medium"
        else:
            risk_level = "high"
        
        return {
            "model": "analytical_engine_v1.0",
            "recommended_policy": {
                "cheap": "p50",
                "balanced": "p75",
                "urgent": "p90"
            },
            "reason": f"Based on {fee_stats.sample_count:,} samples with {fee_stats.success_rate:.1%} success rate and {fee_stats.median_latency_slots:.1f} slot median latency",
            "confidence_score": min(fee_stats.sample_count / 1000.0, 1.0),
            "risk_assessment": f"{risk_level}_risk",
            "anomalies_detected": [],
            "analytical_insights": {
                "execution_score": round(execution_score, 3),
                "risk_level": risk_level,
                "confidence": min(fee_stats.sample_count / 1000.0, 1.0)
            },
            "non_authoritative": True,
            "disclaimer": "LLM interpretation is for informational purposes only and should not be used for execution decisions"
        }
    
    def _build_collateral_logic(self) -> Dict[str, Any]:
        """Build collateral logic description."""
        return {
            "collateral_type": "informational_collateral",
            "backs": "future_execution_fee_estimates",
            "reduces_uncertainty": True,
            "legal_financial_collateral": False,
            "description": "This artifact provides historical fee behavior data that can inform future execution decisions, but does not constitute financial or legal collateral"
        }
    
    def _generate_claim(self, tx_family: str, fee_stats: FeeStatistics) -> str:
        """Generate human-readable claim about fee behavior."""
        if fee_stats.sample_count == 0:
            return f"No fee data available for {tx_family} transactions"
        
        claim_parts = [
            f"For {tx_family} transactions",
            f"historical analysis of {fee_stats.sample_count:,} samples",
            f"shows {fee_stats.success_rate:.1%} success rate",
            f"with p75 priority fees of {fee_stats.p75_micro_lamports_per_cu:,} µL/CU"
        ]
        
        if fee_stats.median_latency_slots > 0:
            claim_parts.append(f"landing within {fee_stats.median_latency_slots:.1f} slots")
        
        return " ".join(claim_parts) + "."
    
    def _determine_provenance_status(self, storage_refs: StorageReferences) -> str:
        """Determine provenance status from storage references."""
        if storage_refs.ipfs_cid and storage_refs.pinned:
            return "ipfs_pinned_verified"
        elif storage_refs.ipfs_cid:
            return "ipfs_pinned_unverified_samples"
        elif storage_refs.arweave_txid:
            return "arweave_immutable"
        else:
            return "local_dev_store"

# Factory function
def get_canonical_artifact_builder() -> GasMemoryArtifactBuilder:
    """Get canonical artifact builder instance."""
    return GasMemoryArtifactBuilder()
