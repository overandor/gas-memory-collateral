"""
Fee Estimation Service
Recommend optimal gas/priority fees based on history
"""

import random
from typing import Dict, Any, Optional


def recommend_fee(history_cid: Optional[str], target_confidence: float = 0.9) -> Dict[str, Any]:
    """
    Recommend fee based on historical samples.
    
    In production:
    1. Retrieve history from IPFS (history_cid)
    2. Analyze distribution
    3. Recommend percentile-based fee
    """
    # Demo: Generate realistic recommendation
    base = 0.000005  # 5000 lamports base
    
    # Higher confidence = higher fee recommendation
    if target_confidence >= 0.95:
        priority_multiplier = 2.5
    elif target_confidence >= 0.9:
        priority_multiplier = 1.8
    else:
        priority_multiplier = 1.2
    
    priority = 0.00005 * priority_multiplier * (1 + random.random() * 0.2)
    total = base + priority
    
    return {
        "fee": {
            "base_fee_sol": round(base, 9),
            "priority_fee_sol": round(priority, 9),
            "total_recommended_sol": round(total, 9),
            "confidence_interval": [round(total * 0.9, 9), round(total * 1.1, 9)]
        },
        "confidence": target_confidence,
        "samples": random.randint(50, 200),
        "strategy": "percentile_90" if target_confidence >= 0.9 else "percentile_75"
    }


def estimate_execution_cost(instruction_count: int, priority_level: str) -> float:
    """
    Estimate total execution cost for a transaction.
    
    Rough Solana costs:
    - Base: 5000 lamports
    - Per CU: ~0.000001 SOL (at 50 microLamports/CU priority)
    """
    base = 0.000005  # SOL
    
    priority_rates = {
        "low": 0.000001,
        "medium": 0.00001,
        "high": 0.0001
    }
    
    cu_cost = instruction_count * priority_rates.get(priority_level, 0.00001)
    return round(base + cu_cost, 9)
