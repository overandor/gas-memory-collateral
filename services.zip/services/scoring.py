"""
Execution Scoring System
Converts fee memory into actionable execution scores
"""
from typing import Dict, Optional
from dataclasses import dataclass
from datetime import datetime

@dataclass
class ExecutionScore:
    """Score representing execution quality."""
    overall_score: float  # 0-1
    success_rate_weight: float
    latency_efficiency_weight: float
    fee_efficiency_weight: float
    timestamp: datetime
    
    # Component scores
    success_rate_score: float
    latency_score: float
    fee_efficiency_score: float
    
    # Raw metrics
    sample_count: int
    success_rate: float
    median_latency_slots: float
    p50_fee: int
    p75_fee: int
    p90_fee: int


class ExecutionScorer:
    """Score execution bundles for quality assessment."""
    
    # Weights for scoring (tunable)
    WEIGHTS = {
        "success_rate": 0.4,      # 40% - did transactions land?
        "latency": 0.3,           # 30% - how fast?
        "fee_efficiency": 0.3     # 30% - cost-effective?
    }
    
    # Benchmarks (Solana mainnet)
    BENCHMARKS = {
        "target_latency_slots": 2.0,      # Target: 2 slots
        "max_acceptable_latency": 10.0,   # Penalty after 10 slots
        "target_fee_micro_lamports": 50000,  # 0.00005 SOL per CU
        "cheap_threshold": 20000,         # Under this = excellent
    }
    
    def calculate_score(
        self,
        samples_summary: Dict,
        fee_curve: Dict,
        tx_family: str,
        time_window: str
    ) -> ExecutionScore:
        """
        Calculate execution score from bundle data.
        
        Formula:
        score = (success_rate * 0.4) + (latency_score * 0.3) + (fee_score * 0.3)
        """
        # Extract metrics
        sample_count = samples_summary.get("sample_count", 0)
        success_rate = samples_summary.get("success_rate", 0.0)
        median_latency = samples_summary.get("median_latency_slots", 10.0)
        
        p50_fee = fee_curve.get("normal", {}).get("p50_micro_lamports_per_cu", 0)
        p75_fee = fee_curve.get("normal", {}).get("p75_micro_lamports_per_cu", 0)
        p90_fee = fee_curve.get("normal", {}).get("p90_micro_lamports_per_cu", 0)
        
        # Component 1: Success rate (direct)
        success_score = success_rate
        
        # Component 2: Latency efficiency
        # Score = 1.0 at target, decays after max_acceptable
        if median_latency <= self.BENCHMARKS["target_latency_slots"]:
            latency_score = 1.0
        elif median_latency >= self.BENCHMARKS["max_acceptable_latency"]:
            latency_score = 0.0
        else:
            # Linear decay between target and max
            range_size = self.BENCHMARKS["max_acceptable_latency"] - self.BENCHMARKS["target_latency_slots"]
            excess = median_latency - self.BENCHMARKS["target_latency_slots"]
            latency_score = 1.0 - (excess / range_size)
        
        # Component 3: Fee efficiency
        # Lower fees = higher score (inverse relationship)
        target_fee = self.BENCHMARKS["target_fee_micro_lamports"]
        if p50_fee <= self.BENCHMARKS["cheap_threshold"]:
            fee_score = 1.0  # Excellent
        elif p50_fee <= target_fee:
            fee_score = 0.8  # Good
        else:
            # Decay for high fees
            # Score = target / actual (capped at 0.1 minimum)
            ratio = target_fee / p50_fee
            fee_score = max(0.1, ratio)
        
        # Weighted total
        overall = (
            success_score * self.WEIGHTS["success_rate"] +
            latency_score * self.WEIGHTS["latency"] +
            fee_score * self.WEIGHTS["fee_efficiency"]
        )
        
        return ExecutionScore(
            overall_score=round(overall, 3),
            success_rate_weight=self.WEIGHTS["success_rate"],
            latency_efficiency_weight=self.WEIGHTS["latency"],
            fee_efficiency_weight=self.WEIGHTS["fee_efficiency"],
            timestamp=datetime.utcnow(),
            success_rate_score=round(success_score, 3),
            latency_score=round(latency_score, 3),
            fee_efficiency_score=round(fee_score, 3),
            sample_count=sample_count,
            success_rate=round(success_rate, 3),
            median_latency_slots=median_latency,
            p50_fee=p50_fee,
            p75_fee=p75_fee,
            p90_fee=p90_fee
        )
    
    def get_grade(self, score: float) -> str:
        """Convert numeric score to letter grade."""
        if score >= 0.9:
            return "A+"
        elif score >= 0.8:
            return "A"
        elif score >= 0.7:
            return "B"
        elif score >= 0.6:
            return "C"
        elif score >= 0.5:
            return "D"
        else:
            return "F"
    
    def get_recommendation(self, score: ExecutionScore) -> str:
        """Get human-readable recommendation."""
        grade = self.get_grade(score.overall_score)
        
        if score.overall_score >= 0.8:
            return f"Grade {grade}: Excellent execution conditions. Use BALANCED or CHEAP policy."
        elif score.overall_score >= 0.6:
            return f"Grade {grade}: Good conditions. Use BALANCED policy for reliability."
        elif score.overall_score >= 0.4:
            return f"Grade {grade}: Fair conditions. Consider URGENT policy during congestion."
        else:
            return f"Grade {grade}: Poor conditions. Use URGENT policy, expect delays."


# Global scorer
_scorer: Optional[ExecutionScorer] = None


def get_scorer() -> ExecutionScorer:
    """Get or create scorer instance."""
    global _scorer
    if _scorer is None:
        _scorer = ExecutionScorer()
    return _scorer
