"""
Persistent Storage Service for Gas Memory Artifacts

Handles IPFS (Pinata/Infura) and Arweave storage for Gas Memory Posts.
Ensures identical content yields the same digest across networks.
"""
import asyncio
import httpx
from typing import Dict, Any, Optional, List, Tuple
from dataclasses import dataclass
from datetime import datetime
import json
import hashlib

from app.models.gas_memory_post import StorageReferences
from app.utils.config import settings

@dataclass
class StorageResult:
    """Result of storage operation."""
    network: str
    success: bool
    identifier: Optional[str] = None
    gateway_url: Optional[str] = None
    error: Optional[str] = None
    timestamp: datetime = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.utcnow()

class IPFSStorageService:
    """IPFS storage service supporting Pinata and Infura."""
    
    def __init__(self):
        self.client = httpx.AsyncClient(timeout=60.0)
        
        # Pinata configuration
        self.pinata_api_key = settings.PINATA_API_KEY
        self.pinata_secret_key = settings.PINATA_SECRET_KEY
        self.pinata_jwt = settings.PINATA_JWT
        
        # Infura configuration (if available)
        self.infura_project_id = getattr(settings, 'INFURA_PROJECT_ID', None)
        self.infura_project_secret = getattr(settings, 'INFURA_PROJECT_SECRET', None)
        
        self.primary_provider = "pinata" if self.pinata_jwt else "infura"
    
    async def store_to_ipfs(
        self,
        content: bytes,
        filename: str = "gas_memory_post.json",
        pin: bool = True
    ) -> StorageResult:
        """Store content to IPFS using primary provider with fallback."""
        
        # Try Pinata first
        if self.primary_provider == "pinata":
            result = await self._store_to_pinata(content, filename, pin)
            if result.success:
                return result
        
        # Fallback to Infura
        if self.infura_project_id:
            result = await self._store_to_infura(content, filename)
            if result.success:
                return result
        
        # If all fail, return error
        return StorageResult(
            network="ipfs",
            success=False,
            error="All IPFS providers failed"
        )
    
    async def _store_to_pinata(
        self,
        content: bytes,
        filename: str,
        pin: bool
    ) -> StorageResult:
        """Store to Pinata IPFS."""
        try:
            url = "https://api.pinata.cloud/pinning/pinFileToIPFS"
            
            # Use JWT authentication
            headers = {"Authorization": f"Bearer {self.pinata_jwt}"}
            
            files = {'file': (filename, content, 'application/json')}
            
            response = await self.client.post(url, headers=headers, files=files)
            response.raise_for_status()
            
            result = response.json()
            cid = result.get('IpfsHash')
            
            if cid:
                return StorageResult(
                    network="ipfs_pinata",
                    success=True,
                    identifier=f"ipfs://{cid}",
                    gateway_url=f"https://gateway.pinata.cloud/ipfs/{cid}"
                )
            else:
                return StorageResult(
                    network="ipfs_pinata",
                    success=False,
                    error="No CID returned from Pinata"
                )
                
        except Exception as e:
            return StorageResult(
                network="ipfs_pinata",
                success=False,
                error=str(e)
            )
    
    async def _store_to_infura(
        self,
        content: bytes,
        filename: str
    ) -> StorageResult:
        """Store to Infura IPFS."""
        try:
            url = "https://ipfs.infura.io:5001/api/v0/add"
            
            auth = httpx.BasicAuth(
                username=self.infura_project_id,
                password=self.infura_project_secret
            )
            
            files = {'file': (filename, content, 'application/json')}
            
            response = await self.client.post(url, auth=auth, files=files)
            response.raise_for_status()
            
            result = response.json()
            cid = result.get('Hash')
            
            if cid:
                return StorageResult(
                    network="ipfs_infura",
                    success=True,
                    identifier=f"ipfs://{cid}",
                    gateway_url=f"https://infura-ipfs.io/ipfs/{cid}"
                )
            else:
                return StorageResult(
                    network="ipfs_infura",
                    success=False,
                    error="No CID returned from Infura"
                )
                
        except Exception as e:
            return StorageResult(
                network="ipfs_infura",
                success=False,
                error=str(e)
            )
    
    async def retrieve_from_ipfs(self, identifier: str) -> Optional[bytes]:
        """Retrieve content from IPFS."""
        try:
            # Extract CID from identifier
            if identifier.startswith("ipfs://"):
                cid = identifier.replace("ipfs://", "")
            else:
                cid = identifier
            
            # Try multiple gateways
            gateways = [
                f"https://gateway.pinata.cloud/ipfs/{cid}",
                f"https://ipfs.io/ipfs/{cid}",
                f"https://cloudflare-ipfs.com/ipfs/{cid}",
                f"https://infura-ipfs.io/ipfs/{cid}"
            ]
            
            for gateway_url in gateways:
                try:
                    response = await self.client.get(gateway_url, timeout=30.0)
                    if response.status_code == 200:
                        return response.content
                except:
                    continue
            
            return None
            
        except Exception:
            return None
    
    async def close(self):
        """Close HTTP client."""
        await self.client.aclose()

class ArweaveStorageService:
    """Arweave storage service for permanent data storage."""
    
    def __init__(self):
        self.client = httpx.AsyncClient(timeout=120.0)
        self.wallet_key = getattr(settings, 'ARWEAVE_WALLET_KEY', None)
        
        # For demo purposes, we'll use a public gateway
        self.gateway_url = "https://arweave.net"
    
    async def store_to_arweave(
        self,
        content: bytes,
        filename: str = "gas_memory_post.json",
        tags: Optional[Dict[str, str]] = None
    ) -> StorageResult:
        """Store content to Arweave network."""
        try:
            if not self.wallet_key:
                # Simulate Arweave storage for demo
                content_hash = hashlib.sha256(content).hexdigest()
                simulated_txid = f"sim_{content_hash[:16]}"
                
                return StorageResult(
                    network="arweave_simulated",
                    success=True,
                    identifier=f"arweave://{simulated_txid}",
                    gateway_url=f"https://arweave.net/{simulated_txid}",
                    error="Simulated - real Arweave integration requires wallet"
                )
            
            # Real Arweave implementation would go here
            # This requires wallet signing and Arweave transaction building
            raise NotImplementedError("Real Arweave integration not implemented")
            
        except Exception as e:
            return StorageResult(
                network="arweave",
                success=False,
                error=str(e)
            )
    
    async def retrieve_from_arweave(self, identifier: str) -> Optional[bytes]:
        """Retrieve content from Arweave."""
        try:
            # Extract transaction ID
            if identifier.startswith("arweave://"):
                tx_id = identifier.replace("arweave://", "")
            else:
                tx_id = identifier
            
            url = f"{self.gateway_url}/{tx_id}"
            
            response = await self.client.get(url, timeout=30.0)
            if response.status_code == 200:
                return response.content
            
            return None
            
        except Exception:
            return None
    
    async def close(self):
        """Close HTTP client."""
        await self.client.aclose()

class PersistentStorageManager:
    """
    Manages persistent storage across IPFS and Arweave networks.
    
    Provides:
    - Multi-network storage with redundancy
    - Content verification across networks
    - Gateway URL management
    - Storage health monitoring
    """
    
    def __init__(self):
        self.ipfs_service = IPFSStorageService()
        self.arweave_service = ArweaveStorageService()
        
        # Storage configuration
        self.enable_ipfs = True
        self.enable_arweave = getattr(settings, 'ENABLE_ARWEAVE', False)
        self.auto_pin = getattr(settings, 'AUTO_PIN_IPFS', True)
    
    async def store_artifact(
        self,
        content: bytes,
        filename: str = "gas_memory_post.json",
        networks: Optional[List[str]] = None
    ) -> Dict[str, StorageResult]:
        """
        Store artifact across multiple networks.
        
        Args:
            content: Content bytes to store
            filename: Filename for storage
            networks: Target networks (ipfs, arweave, all)
            
        Returns:
            Dictionary of network results
        """
        if networks is None:
            networks = ["ipfs"]
            if self.enable_arweave:
                networks.append("arweave")
        
        results = {}
        
        # Store to IPFS
        if "ipfs" in networks and self.enable_ipfs:
            ipfs_result = await self.ipfs_service.store_to_ipfs(
                content, filename, self.auto_pin
            )
            results["ipfs"] = ipfs_result
        
        # Store to Arweave
        if "arweave" in networks and self.enable_arweave:
            arweave_result = await self.arweave_service.store_to_arweave(content, filename)
            results["arweave"] = arweave_result
        
        return results
    
    async def retrieve_artifact(
        self,
        identifier: str,
        network: Optional[str] = None
    ) -> Optional[bytes]:
        """
        Retrieve artifact from any network.
        
        Args:
            identifier: Content identifier (CID, TXID, etc.)
            network: Specific network to try (ipfs, arweave)
            
        Returns:
            Content bytes or None
        """
        if network:
            # Try specific network
            if network == "ipfs":
                return await self.ipfs_service.retrieve_from_ipfs(identifier)
            elif network == "arweave":
                return await self.arweave_service.retrieve_from_arweave(identifier)
        else:
            # Auto-detect network and try appropriate service
            if identifier.startswith("ipfs://") or len(identifier) == 46:  # IPFS CID length
                return await self.ipfs_service.retrieve_from_ipfs(identifier)
            elif identifier.startswith("arweave://") or len(identifier) == 43:  # Arweave TXID length
                return await self.arweave_service.retrieve_from_arweave(identifier)
            else:
                # Try both
                content = await self.ipfs_service.retrieve_from_ipfs(identifier)
                if content:
                    return content
                
                return await self.arweave_service.retrieve_from_arweave(identifier)
        
        return None
    
    async def verify_cross_network(
        self,
        content: bytes,
        storage_results: Dict[str, StorageResult]
    ) -> Dict[str, Any]:
        """
        Verify content integrity across stored networks.
        
        Args:
            content: Original content bytes
            storage_results: Results from storage operations
            
        Returns:
            Verification results
        """
        verification = {
            "content_hash": hashlib.sha256(content).hexdigest(),
            "networks_verified": {},
            "overall_verified": True,
            "verification_timestamp": datetime.utcnow().isoformat()
        }
        
        for network, result in storage_results.items():
            if result.success and result.identifier:
                try:
                    # Retrieve content
                    retrieved_content = await self.retrieve_artifact(result.identifier, network)
                    
                    if retrieved_content:
                        # Verify hash
                        retrieved_hash = hashlib.sha256(retrieved_content).hexdigest()
                        content_hash = verification["content_hash"]
                        
                        is_verified = retrieved_hash == content_hash
                        verification["networks_verified"][network] = {
                            "identifier": result.identifier,
                            "verified": is_verified,
                            "retrieved_hash": retrieved_hash,
                            "expected_hash": content_hash,
                            "gateway_url": result.gateway_url
                        }
                        
                        if not is_verified:
                            verification["overall_verified"] = False
                    else:
                        verification["networks_verified"][network] = {
                            "identifier": result.identifier,
                            "verified": False,
                            "error": "Failed to retrieve content"
                        }
                        verification["overall_verified"] = False
                        
                except Exception as e:
                    verification["networks_verified"][network] = {
                        "identifier": result.identifier,
                        "verified": False,
                        "error": str(e)
                    }
                    verification["overall_verified"] = False
            else:
                verification["networks_verified"][network] = {
                    "success": False,
                    "error": result.error or "Storage failed"
                }
                verification["overall_verified"] = False
        
        return verification
    
    def build_storage_references(
        self,
        storage_results: Dict[str, StorageResult]
    ) -> StorageReferences:
        """Build storage references from storage results."""
        ipfs_cid = None
        arweave_txid = None
        gateway_urls = {}
        pinned = False
        storage_type = "local_dev_store"
        
        # Process IPFS results
        ipfs_result = storage_results.get("ipfs")
        if ipfs_result and ipfs_result.success:
            ipfs_cid = ipfs_result.identifier
            if ipfs_result.gateway_url:
                gateway_urls["ipfs"] = ipfs_result.gateway_url
            pinned = self.auto_pin
            storage_type = "ipfs_pinned"
        
        # Process Arweave results
        arweave_result = storage_results.get("arweave")
        if arweave_result and arweave_result.success:
            arweave_txid = arweave_result.identifier
            if arweave_result.gateway_url:
                gateway_urls["arweave"] = arweave_result.gateway_url
            if storage_type == "local_dev_store":
                storage_type = "arweave_immutable"
            else:
                storage_type = "cross_network_mirrored"
        
        return StorageReferences(
            ipfs_cid=ipfs_cid,
            arweave_txid=arweave_txid,
            gateway_urls=gateway_urls,
            pinned=pinned,
            storage_type=storage_type
        )
    
    async def get_storage_health(self) -> Dict[str, Any]:
        """Get health status of storage services."""
        health = {}
        
        # Check IPFS
        try:
            # Test Pinata API
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get(
                    "https://api.pinata.cloud/data/testAuthentication",
                    headers={"Authorization": f"Bearer {self.ipfs_service.pinata_jwt}"}
                )
            
            health["ipfs"] = {
                "status": "healthy" if response.status_code == 200 else "unhealthy",
                "provider": "Pinata",
                "auto_pin": self.auto_pin,
                "last_check": datetime.utcnow().isoformat()
            }
        except Exception as e:
            health["ipfs"] = {
                "status": "error",
                "error": str(e),
                "last_check": datetime.utcnow().isoformat()
            }
        
        # Check Arweave
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get("https://arweave.net/health")
            
            health["arweave"] = {
                "status": "healthy" if response.status_code == 200 else "unhealthy",
                "provider": "Arweave Network",
                "enabled": self.enable_arweave,
                "last_check": datetime.utcnow().isoformat()
            }
        except Exception as e:
            health["arweave"] = {
                "status": "error",
                "error": str(e),
                "enabled": self.enable_arweave,
                "last_check": datetime.utcnow().isoformat()
            }
        
        return health
    
    async def close(self):
        """Close all services."""
        await self.ipfs_service.close()
        await self.arweave_service.close()

# Factory function
def get_persistent_storage_manager() -> PersistentStorageManager:
    """Get persistent storage manager instance."""
    return PersistentStorageManager()
