"""
IPFS Storage Service for Gas Memory Collateral
Handles storing and retrieving memory bundles from IPFS.
"""
import json
import hashlib
from typing import Optional, Any, Union
from datetime import datetime
import httpx

from app.models.schemas import GasMemoryBundle, IPFSStoreResponse
from app.utils.config import settings


class IPFSStorageService:
    """
    Service for storing and retrieving gas memory bundles on IPFS.
    Supports: local node, Pinata, Infura
    """
    
    def __init__(self):
        self.provider = settings.IPFS_PROVIDER
        self.api_url = settings.IPFS_API_URL
        self.gateway_url = settings.IPFS_GATEWAY
        self.timeout = settings.IPFS_TIMEOUT
        self.client = httpx.AsyncClient(timeout=self.timeout)
        
        # Pinata credentials
        self.pinata_api_key = settings.PINATA_API_KEY
        self.pinata_secret_key = settings.PINATA_SECRET_KEY
        self.pinata_jwt = settings.PINATA_JWT
        
        # Infura credentials
        self.infura_project_id = settings.INFURA_PROJECT_ID
        self.infura_project_secret = settings.INFURA_PROJECT_SECRET
        
    async def store_bundle(
        self, 
        bundle: GasMemoryBundle,
        pin: bool = True
    ) -> IPFSStoreResponse:
        """
        Store a gas memory bundle on IPFS.
        
        Args:
            bundle: The GasMemoryBundle to store
            pin: Whether to pin the content
            
        Returns:
            IPFSStoreResponse with CID and metadata
        """
        # Serialize bundle to canonical JSON
        bundle_json = self._canonical_json(bundle)
        bundle_bytes = bundle_json.encode('utf-8')
        
        # Calculate hash
        bundle_hash = hashlib.sha256(bundle_bytes).hexdigest()
        
        # Store on IPFS
        try:
            cid = await self._add_to_ipfs(bundle_bytes, pin)
            
            # Determine if this is real IPFS or local fallback
            is_real_ipfs = cid.startswith("ipfs://Qm") or cid.startswith("ipfs://bafy")
            storage_type = "real_ipfs" if is_real_ipfs else "local_dev_store"
            
            # Build gateway URL (remove ipfs:// prefix for gateway)
            gateway_cid = cid.replace("ipfs://", "") if cid.startswith("ipfs://") else cid
            gateway_url = f"{self.gateway_url}{gateway_cid}" if is_real_ipfs else None
            
            return IPFSStoreResponse(
                ok=True,
                cid=cid,
                ipfs_gateway_url=gateway_url,
                bundle_hash=bundle_hash,
                pinned=pin and is_real_ipfs,
                size_bytes=len(bundle_bytes),
                provider=self.provider if is_real_ipfs else "fallback",
                storage_type=storage_type,
                is_real_ipfs=is_real_ipfs,
                not_ipfs=not is_real_ipfs
            )
            
        except Exception:
            # Fallback: return local hash if IPFS fails
            local_cid = f"local://{bundle_hash}"
            return IPFSStoreResponse(
                ok=False,
                cid=local_cid,
                ipfs_gateway_url=None,
                bundle_hash=bundle_hash,
                pinned=False,
                size_bytes=len(bundle_bytes),
                provider="fallback",
                storage_type="local_dev_store",
                is_real_ipfs=False,
                not_ipfs=True
            )
    
    async def _add_to_ipfs(
        self, 
        data: bytes, 
        pin: bool = True
    ) -> str:
        """
        Add data to IPFS via configured provider.
        
        Returns:
            CID string (Qm... for real IPFS, local:// for fallback)
        """
        if self.provider == "pinata" and (self.pinata_jwt or self.pinata_api_key):
            return await self._add_to_pinata(data)
        elif self.provider == "infura" and self.infura_project_id:
            return await self._add_to_infura(data)
        else:
            # Local IPFS node or fallback
            return await self._add_to_local_ipfs(data, pin)
    
    async def _add_to_pinata(self, data: bytes) -> str:
        """
        Add data to IPFS via Pinata API.
        Supports both JWT and API Key + Secret authentication.
        Returns real ipfs:// CID.
        """
        url = "https://api.pinata.cloud/pinning/pinFileToIPFS"
        
        # Use JWT if available, otherwise use API Key + Secret
        if self.pinata_jwt:
            headers = {
                "Authorization": f"Bearer {self.pinata_jwt}"
            }
        else:
            headers = {
                "pinata_api_key": self.pinata_api_key,
                "pinata_secret_api_key": self.pinata_secret_key
            }
        
        files = {
            'file': ('bundle.json', data, 'application/json')
        }
        
        response = await self.client.post(
            url,
            headers=headers,
            files=files,
            timeout=60.0
        )
        
        response.raise_for_status()
        result = response.json()
        
        cid = result.get('IpfsHash', '')
        if cid:
            return f"ipfs://{cid}"
        return ""
    
    async def _add_to_infura(self, data: bytes) -> str:
        """
        Add data to IPFS via Infura API.
        Returns real ipfs:// CID.
        """
        url = "https://ipfs.infura.io:5001/api/v0/add"
        
        auth = httpx.BasicAuth(
            username=self.infura_project_id,
            password=self.infura_project_secret
        )
        
        files = {'file': ('bundle.json', data, 'application/json')}
        
        response = await self.client.post(
            url,
            auth=auth,
            files=files,
            timeout=60.0
        )
        
        response.raise_for_status()
        result = response.json()
        
        cid = result.get('Hash', '')
        if cid:
            return f"ipfs://{cid}"
        return ""
    
    async def _add_to_local_ipfs(self, data: bytes, pin: bool = True) -> str:
        """
        Add data to local IPFS node.
        Falls back to local:// hash if node unavailable.
        """
        try:
            files = {'file': ('bundle.json', data, 'application/json')}
            
            params = {}
            if pin:
                params['pin'] = 'true'
            
            response = await self.client.post(
                f"{self.api_url}/api/v0/add",
                params=params,
                files=files,
                timeout=10.0
            )
            
            if response.status_code == 200:
                result = response.json()
                cid = result.get('Hash', '')
                if cid:
                    return f"ipfs://{cid}"
        except httpx.RequestError:
            pass
        
        # Fallback: local hash only
        local_hash = hashlib.sha256(data).hexdigest()
        return f"local://{local_hash}"
    
    async def retrieve_bundle(self, cid: str) -> Optional[GasMemoryBundle]:
        """
        Retrieve a bundle from IPFS by CID.
        
        Args:
            cid: IPFS CID
            
        Returns:
            GasMemoryBundle if found, None otherwise
        """
        try:
            # Try gateway first
            response = await self.client.get(
                f"{self.gateway_url}{cid}",
                timeout=self.timeout
            )
            
            if response.status_code == 200:
                data = response.json()
                return GasMemoryBundle(**data)
            
            # Fallback to local API if available
            response = await self.client.post(
                f"{self.api_url}/api/v0/cat",
                params={'arg': cid}
            )
            
            if response.status_code == 200:
                data = response.json()
                return GasMemoryBundle(**data)
                
        except Exception:
            pass
        
        return None
    
    async def pin_cid(self, cid: str) -> bool:
        """
        Pin a CID to ensure persistence.
        
        Args:
            cid: CID to pin
            
        Returns:
            True if pinned successfully
        """
        try:
            response = await self.client.post(
                f"{self.api_url}/api/v0/pin/add",
                params={'arg': cid}
            )
            return response.status_code == 200
        except httpx.RequestError:
            return False
    
    def _canonical_json(self, obj: Any) -> str:
        """
        Create canonical JSON representation for consistent hashing.
        Sorts keys and handles datetime serialization.
        """
        def serialize(o):
            if isinstance(o, datetime):
                return o.isoformat()
            elif isinstance(o, dict):
                return {k: serialize(v) for k, v in sorted(o.items())}
            elif isinstance(o, list):
                return [serialize(i) for i in o]
            return o
        
        return json.dumps(serialize(obj.model_dump()), separators=(',', ':'), ensure_ascii=False)
    
    def calculate_cid(self, data: Union[str, bytes]) -> str:
        """
        Calculate IPFS-compatible CID (simplified - uses SHA-256).
        In production, use proper multihash encoding.
        """
        if isinstance(data, str):
            data = data.encode('utf-8')
        
        # Simplified CID calculation
        # Real implementation would use multicodec + multihash
        hash_bytes = hashlib.sha256(data).digest()
        
        # Base58 encoding (simplified - just return hex)
        return f"bafy{hash_bytes[:20].hex()}"
    
    async def check_health(self) -> bool:
        """Check if IPFS node is accessible."""
        try:
            response = await self.client.post(
                f"{self.api_url}/api/v0/id",
                timeout=5
            )
            return response.status_code == 200
        except httpx.RequestError:
            return False
    
    async def close(self):
        """Close HTTP client."""
        await self.client.aclose()


# Global instance
_storage: Optional[IPFSStorageService] = None


async def get_ipfs_storage() -> IPFSStorageService:
    """Get or create IPFS storage instance."""
    global _storage
    if _storage is None:
        _storage = IPFSStorageService()
    return _storage
