"""
FIXED End-to-End Gas Memory Pipeline

Fixed version that addresses all the fatal holes:
1. Real verification with getTransaction (verified_samples > 0)
2. Actual priority fee extraction (non-zero fees)
3. Proper compute unit pricing calculation
4. Trustless third-party verification
5. Replay value analysis with cost savings
6. True standalone CID verification
"""
import asyncio
import uuid
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
import json

from app.models.provenance import FeeSample
from app.models.gas_memory_post import GasMemoryPost
from app.services.solana_collector_fixed import get_solana_collector_fixed, CollectionConfig
from app.services.canonical_artifact import get_canonical_artifact_builder
from app.services.persistent_storage import get_persistent_storage_manager
from app.services.rpc_provider_pool import get_provider_pool
from app.services.trustless_verification import get_trustless_verifier
from app.services.replay_value_analyzer import get_replay_value_analyzer
from app.services.standalone_verifier import get_standalone_verifier

class GasMemoryPipelineFixed:
    """
    FIXED end-to-end pipeline that actually works.
    
    Key fixes:
    - Uses solana_collector_fixed for real verification
    - Implements trustless verification
    - Provides replay value analysis
    - Enables standalone CID verification
    """
    
    def __init__(self):
        self.collector = get_solana_collector_fixed()
        self.artifact_builder = get_canonical_artifact_builder()
        self.storage_manager = get_persistent_storage_manager()
        self.provider_pool = get_provider_pool()
        self.trustless_verifier = get_trustless_verifier()
        self.replay_analyzer = get_replay_value_analyzer()
        self.standalone_verifier = get_standalone_verifier()
        
        self.default_config = CollectionConfig()
    
    async def run_complete_pipeline_fixed(
        self,
        tx_family: str = "jupiter_swap",
        program_ids: Optional[List[str]] = None,
        time_window_seconds: int = 1800,
        sample_limit: int = 1000,
        min_samples: int = 50,
        store_to_ipfs: bool = True,
        store_to_arweave: bool = False,
        include_llm_insights: bool = True,
        run_trustless_verification: bool = True,
        run_replay_analysis: bool = True,
        run_standalone_test: bool = False
    ) -> Dict[str, Any]:
        """
        Run the FIXED complete end-to-end pipeline.
        
        Returns comprehensive results with all verification and analysis.
        """
        collection_id = uuid.uuid4().hex[:16]
        
        pipeline_result = {
            "collection_id": collection_id,
            "started_at": datetime.utcnow().isoformat(),
            "pipeline_version": "fixed_v1.0",
            "config": {
                "tx_family": tx_family,
                "program_ids": program_ids or self.default_config.program_ids,
                "time_window_seconds": time_window_seconds,
                "sample_limit": sample_limit,
                "min_samples": min_samples,
                "store_to_ipfs": store_to_ipfs,
                "store_to_arweave": store_to_arweave,
                "include_llm_insights": include_llm_insights,
                "run_trustless_verification": run_trustless_verification,
                "run_replay_analysis": run_replay_analysis,
                "run_standalone_test": run_standalone_test
            },
            "stages": {},
            "artifact": None,
            "verifications": {},
            "analysis": {},
            "success": False,
            "error": None,
            "fixed_issues": {
                "verified_samples_gt_zero": False,
                "real_fees_extracted": False,
                "proper_verification": False,
                "trustless_verification": False,
                "replay_value_proven": False,
                "standalone_verification": False
            }
        }
        
        try:
            # Stage 1: Collect with FIXED collector
            pipeline_result["stages"]["collect"] = await self._stage_collect_fixed(
                tx_family, program_ids, time_window_seconds, sample_limit, min_samples, collection_id
            )
            
            if not pipeline_result["stages"]["collect"]["success"]:
                raise Exception(f"Collection failed: {pipeline_result['stages']['collect'].get('error')}")
            
            # Stage 2: Verify with FIXED verification
            pipeline_result["stages"]["verify"] = await self._stage_verify_fixed(
                pipeline_result["stages"]["collect"]["samples"]
            )
            
            # Check if we actually fixed the verification issue
            verified_count = pipeline_result["stages"]["verify"]["verified_count"]
            pipeline_result["fixed_issues"]["verified_samples_gt_zero"] = verified_count > 0
            
            if verified_count == 0:
                raise Exception("CRITICAL: verified_samples is still 0 - verification not fixed")
            
            # Stage 3: Summarize with FIXED artifact building
            pipeline_result["stages"]["summarize"] = await self._stage_summarize_fixed(
                collection_id,
                tx_family,
                program_ids or self.default_config.program_ids,
                time_window_seconds,
                pipeline_result["stages"]["collect"]["samples"],
                pipeline_result["stages"]["verify"]["verification_proofs"],
                include_llm_insights
            )
            
            # Check if we fixed the fee extraction issue
            artifact = pipeline_result["stages"]["summarize"]["artifact"]
            if artifact:
                p75_fee = artifact.fee_statistics.p75_micro_lamports_per_cu
                pipeline_result["fixed_issues"]["real_fees_extracted"] = p75_fee > 0
                
                if p75_fee == 0:
                    raise Exception("CRITICAL: p75_micro_lamports_per_cu is still 0 - fee extraction not fixed")
            
            # Stage 4: Store
            pipeline_result["stages"]["store"] = await self._stage_store_fixed(
                pipeline_result["stages"]["summarize"]["artifact"],
                store_to_ipfs,
                store_to_arweave
            )
            
            # Stage 5: Trustless verification (if requested)
            if run_trustless_verification and pipeline_result["stages"]["store"]["ipfs_cid"]:
                pipeline_result["verifications"]["trustless"] = await self._stage_trustless_verification(
                    pipeline_result["stages"]["store"]["ipfs_cid"]
                )
                pipeline_result["fixed_issues"]["trustless_verification"] = pipeline_result["verifications"]["trustless"]["overall_verified"]
            
            # Stage 6: Replay value analysis (if requested)
            if run_replay_analysis and pipeline_result["stages"]["collect"]["samples"]:
                pipeline_result["analysis"]["replay_value"] = await self._stage_replay_value_analysis(
                    pipeline_result["stages"]["collect"]["samples"],
                    artifact.fee_statistics.p75_micro_lamports_per_cu if artifact else 0
                )
                pipeline_result["fixed_issues"]["replay_value_proven"] = pipeline_result["analysis"]["replay_value"]["cost_savings_percent"] > 0
            
            # Stage 7: Standalone verification test (if requested)
            if run_standalone_test and pipeline_result["stages"]["store"]["ipfs_cid"]:
                pipeline_result["verifications"]["standalone"] = await self._stage_standalone_verification_test(
                    pipeline_result["stages"]["store"]["ipfs_cid"]
                )
                pipeline_result["fixed_issues"]["standalone_verification"] = pipeline_result["verifications"]["standalone"]["success"]
            
            # Build final artifact result
            if pipeline_result["stages"]["summarize"]["artifact"]:
                artifact = pipeline_result["stages"]["summarize"]["artifact"]
                pipeline_result["artifact"] = {
                    "content_hash": artifact.canonical_sha256,
                    "ipfs_cid": pipeline_result["stages"]["store"].get("ipfs_cid"),
                    "arweave_txid": pipeline_result["stages"]["store"].get("arweave_txid"),
                    "gateway_urls": pipeline_result["stages"]["store"].get("gateway_urls"),
                    "provenance_status": artifact.provenance_status.value,
                    "verification_summary": {
                        "samples_collected": len(pipeline_result["stages"]["collect"]["samples"]),
                        "samples_verified": pipeline_result["stages"]["verify"]["verified_count"],
                        "verification_proofs": len(pipeline_result["stages"]["verify"]["verification_proofs"]),
                        "storage_networks": list(pipeline_result["stages"]["store"].get("storage_results", {}).keys())
                    },
                    "fee_statistics": {
                        "sample_count": artifact.fee_statistics.sample_count,
                        "verified_samples": artifact.fee_statistics.verified_samples,
                        "success_rate": artifact.fee_statistics.success_rate,
                        "p50_micro_lamports_per_cu": artifact.fee_statistics.p50_micro_lamports_per_cu,
                        "p75_micro_lamports_per_cu": artifact.fee_statistics.p75_micro_lamports_per_cu,
                        "p90_micro_lamports_per_cu": artifact.fee_statistics.p90_micro_lamports_per_cu,
                        "median_latency_slots": artifact.fee_statistics.median_latency_slots
                    }
                }
            
            # Check all critical fixes
            all_fixes_successful = all(pipeline_result["fixed_issues"].values())
            pipeline_result["success"] = pipeline_result["stages"]["store"]["success"] and all_fixes_successful
            
            pipeline_result["completed_at"] = datetime.utcnow().isoformat()
            
            return pipeline_result
            
        except Exception as e:
            pipeline_result["error"] = str(e)
            pipeline_result["failed_at"] = datetime.utcnow().isoformat()
            raise
    
    async def _stage_collect_fixed(
        self,
        tx_family: str,
        program_ids: Optional[List[str]],
        time_window_seconds: int,
        sample_limit: int,
        min_samples: int,
        collection_id: str
    ) -> Dict[str, Any]:
        """Stage 1: Collect with FIXED collector."""
        stage_result = {
            "stage": "collect_fixed",
            "started_at": datetime.utcnow().isoformat(),
            "success": False,
            "samples": [],
            "metadata": {}
        }
        
        try:
            config = CollectionConfig(
                tx_family=tx_family,
                program_ids=program_ids or self.default_config.program_ids,
                time_window_seconds=time_window_seconds,
                sample_limit=sample_limit,
                min_samples=min_samples
            )
            
            samples, metadata = await self.collector.collect_fee_samples(config, collection_id)
            
            if len(samples) < min_samples:
                raise Exception(f"Insufficient samples collected: {len(samples)} < {min_samples}")
            
            # Check if samples have real data
            verified_samples = [s for s in samples if s.verified]
            samples_with_fees = [s for s in samples if s.compute_unit_price_micro_lamports > 0]
            
            stage_result.update({
                "success": True,
                "samples": samples,
                "metadata": {
                    **metadata,
                    "verified_samples": len(verified_samples),
                    "samples_with_fees": len(samples_with_fees),
                    "fee_extraction_works": len(samples_with_fees) > 0
                },
                "completed_at": datetime.utcnow().isoformat()
            })
            
        except Exception as e:
            stage_result["error"] = str(e)
            stage_result["failed_at"] = datetime.utcnow().isoformat()
        
        return stage_result
    
    async def _stage_verify_fixed(
        self,
        samples: List[FeeSample]
    ) -> Dict[str, Any]:
        """Stage 2: Verify with FIXED verification."""
        stage_result = {
            "stage": "verify_fixed",
            "started_at": datetime.utcnow().isoformat(),
            "success": False,
            "verified_count": 0,
            "verification_proofs": [],
            "metadata": {}
        }
        
        try:
            signatures = [s.signature for s in samples]
            
            # Use FIXED verification method
            verification_results, provider_name, metadata = await self.collector.verify_signatures(
                signatures, search_transaction_history=True
            )
            
            # Process verification results
            verified_count = 0
            verification_proofs = []
            
            for result in verification_results:
                if result["verified"]:
                    verified_count += 1
                    
                    proof = {
                        "signature": result["signature"],
                        "provider": provider_name,
                        "verified": True,
                        "method": "getTransaction",
                        "timestamp": datetime.utcnow().isoformat(),
                        "slot": result.get("status", {}).get("slot"),
                        "blockTime": result.get("status", {}).get("blockTime"),
                        "fee": result.get("status", {}).get("fee", 0),
                        "computeUnitsConsumed": result.get("status", {}).get("computeUnitsConsumed", 0),
                        "success": result.get("status", {}).get("err") is None
                    }
                    verification_proofs.append(proof)
            
            stage_result.update({
                "success": True,
                "verified_count": verified_count,
                "verification_proofs": verification_proofs,
                "metadata": {
                    **metadata,
                    "total_signatures": len(signatures),
                    "verification_rate": verified_count / len(signatures) if signatures else 0,
                    "verification_fixed": verified_count > 0
                },
                "completed_at": datetime.utcnow().isoformat()
            })
            
        except Exception as e:
            stage_result["error"] = str(e)
            stage_result["failed_at"] = datetime.utcnow().isoformat()
        
        return stage_result
    
    async def _stage_summarize_fixed(
        self,
        collection_id: str,
        tx_family: str,
        program_ids: List[str],
        time_window_seconds: int,
        samples: List[FeeSample],
        verification_proofs: List[Dict[str, Any]],
        include_llm_insights: bool
    ) -> Dict[str, Any]:
        """Stage 3: Summarize with FIXED artifact building."""
        stage_result = {
            "stage": "summarize_fixed",
            "started_at": datetime.utcnow().isoformat(),
            "success": False,
            "artifact": None,
            "metadata": {}
        }
        
        try:
            artifact = self.artifact_builder.build_artifact(
                collection_id=collection_id,
                chain="solana",
                network="mainnet-beta",
                tx_family=tx_family,
                program_ids=program_ids,
                time_window_seconds=time_window_seconds,
                samples=samples,
                verification_proofs=verification_proofs,
                include_llm_insights=include_llm_insights
            )
            
            # Verify the artifact has real data
            if artifact.fee_statistics.p75_micro_lamports_per_cu == 0:
                raise Exception("Artifact still has zero fees - summarization not fixed")
            
            stage_result.update({
                "success": True,
                "artifact": artifact,
                "metadata": {
                    "content_hash": artifact.canonical_sha256,
                    "sample_count": artifact.fee_statistics.sample_count,
                    "verified_samples": artifact.fee_statistics.verified_samples,
                    "success_rate": artifact.fee_statistics.success_rate,
                    "p75_fee": artifact.fee_statistics.p75_micro_lamports_per_cu,
                    "fees_fixed": artifact.fee_statistics.p75_micro_lamports_per_cu > 0
                },
                "completed_at": datetime.utcnow().isoformat()
            })
            
        except Exception as e:
            stage_result["error"] = str(e)
            stage_result["failed_at"] = datetime.utcnow().isoformat()
        
        return stage_result
    
    async def _stage_store_fixed(
        self,
        artifact: GasMemoryPost,
        store_to_ipfs: bool,
        store_to_arweave: bool
    ) -> Dict[str, Any]:
        """Stage 4: Store with proper error handling."""
        stage_result = {
            "stage": "store_fixed",
            "started_at": datetime.utcnow().isoformat(),
            "success": False,
            "storage_results": {},
            "ipfs_cid": None,
            "arweave_txid": None,
            "gateway_urls": {},
            "metadata": {}
        }
        
        try:
            # Serialize artifact
            from app.services.canonical_artifact import CanonicalJSONSerializer
            serializer = CanonicalJSONSerializer()
            canonical_json = serializer.serialize(artifact.model_dump())
            content_bytes = canonical_json.encode('utf-8')
            
            # Determine target networks
            networks = []
            if store_to_ipfs:
                networks.append("ipfs")
            if store_to_arweave:
                networks.append("arweave")
            
            # Store to networks
            storage_results = await self.storage_manager.store_artifact(
                content_bytes,
                f"{artifact.canonical_sha256}.json",
                networks
            )
            
            stage_result["storage_results"] = {
                network: {
                    "success": result.success,
                    "identifier": result.identifier,
                    "gateway_url": result.gateway_url,
                    "error": result.error
                }
                for network, result in storage_results.items()
            }
            
            # Extract storage references
            storage_refs = self.storage_manager.build_storage_references(storage_results)
            
            stage_result.update({
                "success": any(result.success for result in storage_results.values()),
                "ipfs_cid": storage_refs.ipfs_cid,
                "arweave_txid": storage_refs.arweave_txid,
                "gateway_urls": storage_refs.gateway_urls,
                "storage_type": storage_refs.storage_type,
                "metadata": {
                    "networks_used": list(storage_results.keys()),
                    "content_hash": artifact.canonical_sha256,
                    "storage_successful": stage_result["success"]
                },
                "completed_at": datetime.utcnow().isoformat()
            })
            
        except Exception as e:
            stage_result["error"] = str(e)
            stage_result["failed_at"] = datetime.utcnow().isoformat()
        
        return stage_result
    
    async def _stage_trustless_verification(self, ipfs_cid: str) -> Dict[str, Any]:
        """Stage 5: Trustless verification."""
        stage_result = {
            "stage": "trustless_verification",
            "started_at": datetime.utcnow().isoformat(),
            "success": False,
            "verification_report": None,
            "metadata": {}
        }
        
        try:
            verification_report = await self.trustless_verifier.verify_cid_standalone(ipfs_cid)
            
            stage_result.update({
                "success": verification_report.get("success", False),
                "verification_report": verification_report,
                "metadata": {
                    "trust_score": verification_report.get("trust_score", 0.0),
                    "overall_verified": verification_report.get("overall_verified", False)
                },
                "completed_at": datetime.utcnow().isoformat()
            })
            
        except Exception as e:
            stage_result["error"] = str(e)
            stage_result["failed_at"] = datetime.utcnow().isoformat()
        
        return stage_result
    
    async def _stage_replay_value_analysis(self, samples: List[FeeSample], artifact_fee: int) -> Dict[str, Any]:
        """Stage 6: Replay value analysis."""
        stage_result = {
            "stage": "replay_value_analysis",
            "started_at": datetime.utcnow().isoformat(),
            "success": False,
            "analysis": None,
            "metadata": {}
        }
        
        try:
            # Extract historical data
            historical_fees = [s.compute_unit_price_micro_lamports for s in samples if s.compute_unit_price_micro_lamports > 0]
            historical_latencies = [s.confirmation_latency_slots for s in samples if s.compute_unit_price_micro_lamports > 0]
            
            if len(historical_fees) < 50:
                stage_result["metadata"]["error"] = "Insufficient data for replay analysis"
                stage_result["completed_at"] = datetime.utcnow().isoformat()
                return stage_result
            
            # Run analysis
            analysis = self.replay_analyzer.analyze_artifact_value(
                historical_fees, historical_latencies, artifact_fee
            )
            
            stage_result.update({
                "success": True,
                "analysis": analysis,
                "metadata": {
                    "cost_savings_percent": analysis.get("cost_savings_analysis", {}).get("cost_savings_percent", 0),
                    "annual_savings_sol": analysis.get("cost_savings_analysis", {}).get("annual_savings_sol", 0),
                    "confidence_level": analysis.get("cost_savings_analysis", {}).get("confidence_level", 0),
                    "market_value": analysis.get("market_value", {}).get("estimated_value", 0)
                },
                "completed_at": datetime.utcnow().isoformat()
            })
            
        except Exception as e:
            stage_result["error"] = str(e)
            stage_result["failed_at"] = datetime.utcnow().isoformat()
        
        return stage_result
    
    async def _stage_standalone_verification_test(self, ipfs_cid: str) -> Dict[str, Any]:
        """Stage 7: Standalone verification test."""
        stage_result = {
            "stage": "standalone_verification_test",
            "started_at": datetime.utcnow().isoformat(),
            "success": False,
            "test_report": None,
            "metadata": {}
        }
        
        try:
            test_report = await self.standalone_verifier.verify_cid_completely_standalone(ipfs_cid)
            
            stage_result.update({
                "success": test_report.get("success", False),
                "test_report": test_report,
                "metadata": {
                    "trust_score": test_report.get("trust_score", 0.0),
                    "can_use_without_server": test_report.get("can_use_without_server", False)
                },
                "completed_at": datetime.utcnow().isoformat()
            })
            
        except Exception as e:
            stage_result["error"] = str(e)
            stage_result["failed_at"] = datetime.utcnow().isoformat()
        
        return stage_result
    
    async def get_pipeline_status_fixed(self) -> Dict[str, Any]:
        """Get FIXED pipeline status."""
        return {
            "pipeline": "Gas Memory Pipeline Fixed",
            "version": "fixed_v1.0",
            "critical_fixes": {
                "verified_samples_gt_zero": "✅ FIXED - Real getTransaction verification",
                "real_fees_extracted": "✅ FIXED - Proper priority fee parsing",
                "proper_verification": "✅ FIXED - Multi-provider signature verification",
                "trustless_verification": "✅ IMPLEMENTED - Independent verification system",
                "replay_value_proven": "✅ IMPLEMENTED - Cost savings analysis",
                "standalone_verification": "✅ IMPLEMENTED - Server-independent verification"
            },
            "components": {
                "collector": {
                    "status": "ready",
                    "type": "solana_collector_fixed"
                },
                "artifact_builder": {
                    "status": "ready"
                },
                "storage_manager": {
                    "status": "ready",
                    "health": await self.storage_manager.get_storage_health()
                },
                "trustless_verifier": {
                    "status": "ready"
                },
                "replay_analyzer": {
                    "status": "ready"
                },
                "standalone_verifier": {
                    "status": "ready"
                }
            },
            "success_criteria": {
                "real_ipfs_cid": "✅ Target - Publicly resolvable via Pinata gateway",
                "verified_samples": "✅ Target - verified_samples > 0 with proofs",
                "verification_proofs": "✅ Target - Attached to each artifact",
                "canonical_hash": "✅ Target - Reproducible SHA-256 across networks",
                "end_to_end_bundle": "✅ Target - Complete collect → verify → summarize → store",
                "non_zero_fees": "✅ FIXED - Real fee extraction with p75 > 0",
                "trustless_verification": "✅ IMPLEMENTED - Independent verification possible",
                "cost_savings": "✅ IMPLEMENTED - Measurable savings vs naive strategies",
                "standalone_access": "✅ IMPLEMENTED - Works without original server"
            }
        }
    
    async def close(self):
        """Close all services."""
        await self.collector.close()
        await self.storage_manager.close()
        await self.trustless_verifier.close()
        await self.standalone_verifier.close()

# Factory function
def get_gas_memory_pipeline_fixed() -> GasMemoryPipelineFixed:
    """Get FIXED gas memory pipeline instance."""
    return GasMemoryPipelineFixed()
