"""
Solana Transaction Signer Service
Handles keypair management and transaction signing.
Uses environment variables for secure key storage (NEVER log or expose).
"""
import base64
import json
from typing import Optional, Dict, Any, List
import os

try:
    from solders.keypair import Keypair
    from solders.transaction import VersionedTransaction
    from solders.message import MessageV0
    from solders.instruction import Instruction
    from solders.pubkey import Pubkey
    from solders.system_program import transfer, TransferParams
    SOLDERS_AVAILABLE = True
except ImportError:
    SOLDERS_AVAILABLE = False
    print("[Signer] Warning: solders not available. Install with: pip install solders")


class SolanaSigner:
    """
    Secure transaction signer.
    
    Loads keypair from environment variable (never from code or logs).
    Signs transactions for arbitrage execution.
    """
    
    def __init__(self, private_key_env_var: str = "SOLANA_PRIVATE_KEY"):
        self.private_key_env_var = private_key_env_var
        self._keypair: Optional[Any] = None
        self._pubkey: Optional[str] = None
        
        if SOLDERS_AVAILABLE:
            self._load_keypair()
    
    def _load_keypair(self) -> bool:
        """Load keypair from environment variable."""
        try:
            private_key_b64 = os.getenv(self.private_key_env_var)
            
            if not private_key_b64:
                print(f"[Signer] No private key found in {self.private_key_env_var}")
                return False
            
            # Decode base64 private key
            private_key_bytes = base64.b64decode(private_key_b64)
            
            # Create keypair
            self._keypair = Keypair.from_bytes(private_key_bytes)
            self._pubkey = str(self._keypair.pubkey())
            
            print(f"[Signer] Loaded keypair: {self._pubkey[:8]}...{self._pubkey[-4:]}")
            return True
            
        except Exception as e:
            print(f"[Signer] Error loading keypair: {e}")
            return False
    
    @property
    def pubkey(self) -> Optional[str]:
        """Return public key (safe to expose)."""
        return self._pubkey
    
    @property
    def is_ready(self) -> bool:
        """Check if signer is ready to sign."""
        return self._keypair is not None and SOLDERS_AVAILABLE
    
    def create_transfer_instruction(
        self,
        to_pubkey: str,
        lamports: int
    ) -> Optional[Instruction]:
        """Create SOL transfer instruction."""
        if not self.is_ready:
            return None
        
        try:
            return transfer(
                TransferParams(
                    from_pubkey=self._keypair.pubkey(),
                    to_pubkey=Pubkey.from_string(to_pubkey),
                    lamports=lamports
                )
            )
        except Exception as e:
            print(f"[Signer] Error creating transfer: {e}")
            return None
    
    def sign_transaction(
        self,
        instructions: List[Instruction],
        recent_blockhash: str,
        additional_signers: Optional[List[Any]] = None
    ) -> Optional[bytes]:
        """
        Sign transaction with all required signers.
        
        Returns serialized transaction bytes ready for submission.
        """
        if not self.is_ready:
            print("[Signer] Signer not ready - no keypair loaded")
            return None
        
        try:
            # Build message
            message = MessageV0.try_compile(
                payer=self._keypair.pubkey(),
                instructions=instructions,
                address_lookup_table_accounts=[],  # No LUT for simplicity
                recent_blockhash=recent_blockhash
            )
            
            # Create transaction
            tx = VersionedTransaction(message, [self._keypair])
            
            # Serialize
            serialized = bytes(tx)
            
            print(f"[Signer] Signed tx: {len(serialized)} bytes")
            return serialized
            
        except Exception as e:
            print(f"[Signer] Signing error: {e}")
            return None
    
    def sign_and_encode(
        self,
        instructions: List[Instruction],
        recent_blockhash: str
    ) -> Optional[str]:
        """
        Sign and return base64-encoded transaction.
        
        This is the format needed for RPC submission.
        """
        serialized = self.sign_transaction(instructions, recent_blockhash)
        if serialized:
            return base64.b64encode(serialized).decode('utf-8')
        return None
    
    def verify_signature(self, signature: str, message: bytes) -> bool:
        """Verify a signature (for receipt validation)."""
        if not self.is_ready:
            return False
        
        try:
            # Parse signature
            sig_bytes = base64.b64decode(signature)
            # Verify using solders
            from solders.signature import Signature
            sig = Signature(sig_bytes)
            return sig.verify(self._keypair.pubkey(), message)
        except Exception as e:
            print(f"[Signer] Verification error: {e}")
            return False


# Singleton
_signer: Optional[SolanaSigner] = None


def get_signer(private_key_env_var: str = "SOLANA_PRIVATE_KEY") -> SolanaSigner:
    """Get signer singleton."""
    global _signer
    if _signer is None:
        _signer = SolanaSigner(private_key_env_var)
    return _signer


def check_signer_status() -> Dict[str, Any]:
    """Check if signer is configured and ready."""
    signer = get_signer()
    
    return {
        "solders_available": SOLDERS_AVAILABLE,
        "keypair_loaded": signer.is_ready,
        "pubkey": signer.pubkey,
        "env_var_set": os.getenv("SOLANA_PRIVATE_KEY") is not None
    }
