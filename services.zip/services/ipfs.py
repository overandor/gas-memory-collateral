"""
IPFS Storage Service
Pinata integration for permanent storage
"""

import os
import json
from typing import Dict, Any, Optional
import hashlib

# Pinata config from env
PINATA_JWT = os.getenv("PINATA_JWT", "")
PINATA_API_URL = "https://api.pinata.cloud/pinning/pinJSONToIPFS"


def is_configured() -> bool:
    """Check if Pinata is configured"""
    return bool(PINATA_JWT)


def store_bundle(data: Dict[str, Any], metadata: Optional[Dict[str, Any]] = None) -> str:
    """
    Store data bundle on IPFS via Pinata.
    
    Returns CID (Content Identifier)
    """
    if not PINATA_JWT:
        # Demo mode: return mock CID
        content = json.dumps({"data": data, "metadata": metadata}, sort_keys=True)
        mock_cid = "Qm" + hashlib.sha256(content.encode()).hexdigest()[:44]
        return mock_cid
    
    # Production: Pin to Pinata
    # import requests
    # payload = {"pinataContent": data, "pinataMetadata": metadata or {}}
    # headers = {"Authorization": f"Bearer {PINATA_JWT}"}
    # resp = requests.post(PINATA_API_URL, json=payload, headers=headers)
    # return resp.json()["IpfsHash"]
    
    # For now, return mock
    content = json.dumps({"data": data, "metadata": metadata}, sort_keys=True)
    mock_cid = "Qm" + hashlib.sha256(content.encode()).hexdigest()[:44]
    return mock_cid


def retrieve_bundle(cid: str) -> Dict[str, Any]:
    """
    Retrieve bundle from IPFS.
    
    In production: Fetch from gateway
    """
    # Demo: return empty (would fetch from gateway)
    raise Exception(f"CID {cid} not found in demo mode. Set PINATA_JWT for real storage.")


def get_gateway_url(cid: str) -> str:
    """Get public gateway URL for CID"""
    return f"https://gateway.pinata.cloud/ipfs/{cid}"
