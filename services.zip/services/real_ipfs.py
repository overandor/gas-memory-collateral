"""
Real IPFS Storage

No more fake storage. Real IPFS with add, pin, verify retrieval.
Fails loudly if anything goes wrong.
"""
import os
import json
import hashlib
from typing import Dict, Any, Optional, List
from datetime import datetime
import httpx
import asyncio

class RealIPFSStorage:
    """
    Real IPFS storage with no fallbacks.
    
    Either it works correctly, or it fails loudly.
    No silent local storage, no fake CIDs.
    """
    
    def __init__(self):
        self.client = httpx.AsyncClient(timeout=60.0)
        
        # Load configuration
        self.ipfs_api_url = os.getenv("IPFS_API_URL", "http://localhost:5001")
        self.pinata_api_key = os.getenv("PINATA_API_KEY")
        self.pinata_secret_key = os.getenv("PINATA_SECRET_KEY")
        self.pinata_jwt = os.getenv("PINATA_JWT")
        
        # Verify configuration
        self._verify_config()
    
    def _verify_config(self):
        """Verify IPFS configuration is complete."""
        if not self.ipfs_api_url:
            raise Exception("IPFS_API_URL not configured")
        
        # At least one storage method must be available
        if not (self.pinata_api_key and self.pinata_secret_key and self.pinata_jwt):
            print("Warning: Pinata not configured - using local IPFS node only")
    
    async def add_to_ipfs(self, content: bytes, filename: str) -> Dict[str, Any]:
        """
        Add content to IPFS and get real CID.
        
        Args:
            content: Content to add
            filename: Filename for the content
            
        Returns:
            Dictionary with CID and metadata
            
        Raises:
            Exception: If IPFS add fails
        """
        try:
            # Try local IPFS node first
            local_result = await self._add_to_local_ipfs(content, filename)
            if local_result:
                return local_result
            
            # Fallback to Pinata if local fails
            if self.pinata_jwt:
                pinata_result = await self._add_to_pinata(content, filename)
                return pinata_result
            
            raise Exception("Both local IPFS and Pinata failed")
            
        except Exception as e:
            raise Exception(f"IPFS add failed: {str(e)}")
    
    async def _add_to_local_ipfs(self, content: bytes, filename: str) -> Optional[Dict[str, Any]]:
        """Add content to local IPFS node."""
        try:
            files = {
                'file': (filename, content, 'application/json')
            }
            
            response = await self.client.post(
                f"{self.ipfs_api_url}/api/v0/add",
                files=files,
                params={'pin': 'true', 'hash': 'sha2-256'}
            )
            
            if response.status_code != 200:
                return None
            
            result = response.json()
            
            if 'Hash' not in result:
                return None
            
            return {
                "cid": result['Hash'],
                "size": result.get('Size', len(content)),
                "provider": "local_ipfs",
                "pinned": result.get('Pinned', False)
            }
            
        except Exception as e:
            print(f"Local IPFS add failed: {str(e)}")
            return None
    
    async def _add_to_pinata(self, content: bytes, filename: str) -> Dict[str, Any]:
        """Add content to Pinata."""
        if not (self.pinata_api_key and self.pinata_secret_key and self.pinata_jwt):
            raise Exception("Pinata credentials not configured")
        
        try:
            files = {
                'file': (filename, content, 'application/json')
            }
            
            # Pinata metadata
            pinata_metadata = {
                "name": f"gas-memory-{filename}",
                "keyvalues": {
                    "type": "gas-memory-artifact",
                    "created_at": datetime.utcnow().isoformat(),
                    "version": "1.0"
                }
            }
            
            headers = {
                'pinata_api_key': self.pinata_api_key,
                'pinata_secret_key': self.pinata_secret_key,
                'Authorization': f'Bearer {self.pinata_jwt}'
            }
            
            response = await self.client.post(
                "https://api.pinata.cloud/pinning/pinFileToIPFS",
                files=files,
                data={'pinataMetadata': json.dumps(pinata_metadata)},
                headers=headers
            )
            
            if response.status_code != 200:
                raise Exception(f"Pinata API error: {response.status_code} - {response.text}")
            
            result = response.json()
            
            if 'IpfsHash' not in result:
                raise Exception("Pinata response missing IpfsHash")
            
            return {
                "cid": result['IpfsHash'],
                "size": result.get('PinSize', len(content)),
                "provider": "pinata",
                "pinned": True,
                "pinata_id": result.get('id')
            }
            
        except Exception as e:
            raise Exception(f"Pinata add failed: {str(e)}")
    
    async def pin_cid(self, cid: str) -> bool:
        """
        Pin a CID to ensure persistence.
        
        Args:
            cid: CID to pin
            
        Returns:
            True if pinning successful
            
        Raises:
            Exception: If pinning fails
        """
        try:
            # Try local IPFS pin
            local_pinned = await self._pin_local_cid(cid)
            if local_pinned:
                return True
            
            # Try Pinata pin
            if self.pinata_jwt:
                pinata_pinned = await self._pin_pinata_cid(cid)
                return pinata_pinned
            
            raise Exception("Both local and Pinata pinning failed")
            
        except Exception as e:
            raise Exception(f"IPFS pin failed: {str(e)}")
    
    async def _pin_local_cid(self, cid: str) -> bool:
        """Pin CID on local IPFS node."""
        try:
            response = await self.client.post(
                f"{self.ipfs_api_url}/api/v0/pin/add",
                params={'arg': cid}
            )
            
            return response.status_code == 200
            
        except Exception as e:
            print(f"Local IPFS pin failed: {str(e)}")
            return False
    
    async def _pin_pinata_cid(self, cid: str) -> bool:
        """Pin CID on Pinata."""
        if not self.pinata_jwt:
            return False
        
        try:
            headers = {
                'Authorization': f'Bearer {self.pinata_jwt}',
                'Content-Type': 'application/json'
            }
            
            payload = {
                "hashToPin": cid,
                "pinataMetadata": {
                    "name": f"gas-memory-{cid}",
                    "keyvalues": {
                        "type": "gas-memory-artifact",
                        "pinned_at": datetime.utcnow().isoformat()
                    }
                }
            }
            
            response = await self.client.post(
                "https://api.pinata.cloud/pinning/pinFileToIPFS",
                json=payload,
                headers=headers
            )
            
            return response.status_code == 200
            
        except Exception as e:
            print(f"Pinata pin failed: {str(e)}")
            return False
    
    async def retrieve_cid(self, cid: str) -> bytes:
        """
        Retrieve content by CID with verification.
        
        Args:
            cid: CID to retrieve
            
        Returns:
            Content bytes
            
        Raises:
            Exception: If retrieval fails
        """
        try:
            # Try multiple gateways for retrieval
            gateways = [
                f"{self.ipfs_api_url}/api/v0/cat?arg={cid}",
                f"https://ipfs.io/ipfs/{cid}",
                f"https://gateway.pinata.cloud/ipfs/{cid}",
                f"https://cloudflare-ipfs.com/ipfs/{cid}"
            ]
            
            for gateway_url in gateways:
                try:
                    response = await self.client.get(gateway_url, timeout=30.0)
                    
                    if response.status_code == 200:
                        content = response.content
                        
                        # Verify content is not empty
                        if len(content) == 0:
                            continue
                        
                        # Verify content is valid JSON (for our artifacts)
                        try:
                            json.loads(content.decode('utf-8'))
                        except json.JSONDecodeError:
                            continue
                        
                        print(f"Retrieved {len(content)} bytes from {gateway_url}")
                        return content
                        
                except Exception as e:
                    print(f"Gateway {gateway_url} failed: {str(e)}")
                    continue
            
            raise Exception(f"Failed to retrieve CID {cid} from any gateway")
            
        except Exception as e:
            raise Exception(f"IPFS retrieval failed: {str(e)}")
    
    async def verify_cid_integrity(self, cid: str, expected_hash: str) -> Dict[str, Any]:
        """
        Verify CID integrity against expected hash.
        
        Args:
            cid: CID to verify
            expected_hash: Expected SHA-256 hash
            
        Returns:
            Verification result
            
        Raises:
            Exception: If verification fails
        """
        try:
            content = await self.retrieve_cid(cid)
            calculated_hash = hashlib.sha256(content).hexdigest()
            
            return {
                "cid": cid,
                "expected_hash": expected_hash,
                "calculated_hash": calculated_hash,
                "matches": calculated_hash == expected_hash,
                "content_size": len(content),
                "verified_at": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            raise Exception(f"CID verification failed: {str(e)}")
    
    async def store_artifact_real(self, artifact_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Store artifact with real IPFS and verification.
        
        Args:
            artifact_data: Artifact data to store
            
        Returns:
            Storage result with real CID
            
        Raises:
            Exception: If any step fails
        """
        try:
            # Convert to canonical JSON
            canonical_json = json.dumps(artifact_data, sort_keys=True, separators=(',', ':'))
            content_bytes = canonical_json.encode('utf-8')
            
            # Calculate expected hash
            expected_hash = hashlib.sha256(content_bytes).hexdigest()
            
            # Add to IPFS
            add_result = await self.add_to_ipfs(content_bytes, f"{expected_hash}.json")
            cid = add_result["cid"]
            
            # Pin the CID
            pin_success = await self.pin_cid(cid)
            if not pin_success:
                print("Warning: CID pinning failed")
            
            # Verify integrity
            verification = await self.verify_cid_integrity(cid, expected_hash)
            if not verification["matches"]:
                raise Exception(f"Hash mismatch after storage: expected {expected_hash}, got {verification['calculated_hash']}")
            
            return {
                "success": True,
                "cid": cid,
                "expected_hash": expected_hash,
                "verified_hash": verification["calculated_hash"],
                "content_size": len(content_bytes),
                "provider": add_result["provider"],
                "pinned": add_result.get("pinned", False),
                "gateway_urls": [
                    f"https://ipfs.io/ipfs/{cid}",
                    f"https://gateway.pinata.cloud/ipfs/{cid}",
                    f"https://cloudflare-ipfs.com/ipfs/{cid}"
                ],
                "stored_at": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            raise Exception(f"Real IPFS storage failed: {str(e)}")
    
    async def get_ipfs_health(self) -> Dict[str, Any]:
        """Check IPFS node health."""
        health = {
            "local_ipfs": False,
            "pinata_configured": bool(self.pinata_jwt),
            "test_cid": None,
            "test_result": None
        }
        
        try:
            # Test local IPFS
            response = await self.client.post(
                f"{self.ipfs_api_url}/api/v0/version"
            )
            
            if response.status_code == 200:
                health["local_ipfs"] = True
                version_info = response.json()
                health["local_version"] = version_info.get("Version")
            
            # Test with small content
            test_content = json.dumps({
                "test": True,
                "timestamp": datetime.utcnow().isoformat()
            }).encode('utf-8')
            
            test_result = await self.add_to_ipfs(test_content, "health-check.json")
            health["test_cid"] = test_result["cid"]
            health["test_result"] = "passed"
            
            # Cleanup test
            try:
                await self.client.post(
                    f"{self.ipfs_api_url}/api/v0/pin/rm",
                    params={'arg': test_result["cid"]}
                )
            except:
                pass
                
        except Exception as e:
            health["test_result"] = f"failed: {str(e)}"
        
        return health
    
    async def close(self):
        """Close HTTP client."""
        await self.client.aclose()

# Factory function
def get_real_ipfs_storage() -> RealIPFSStorage:
    """Get real IPFS storage instance."""
    return RealIPFSStorage()
